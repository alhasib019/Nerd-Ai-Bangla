package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.api.Blob
import com.example.api.Content
import com.example.api.GenerateContentRequest
import com.example.api.GenerationConfig
import com.example.api.Part
import com.example.api.RetrofitClient
import com.example.data.StudyRecord
import com.example.data.StudyRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import com.google.firebase.auth.FirebaseAuth

data class ChatMessage(
    val sender: String, // "USER" or "AI"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class NerdAIViewModel(private val repository: StudyRepository) : ViewModel() {

    // --- API Key Status ---
    val isApiKeyConfigured: Boolean = BuildConfig.GEMINI_API_KEY.isNotEmpty()

    // --- Firebase Auth States & Status ---
    private val _authLoading = MutableStateFlow(false)
    val authLoading: StateFlow<Boolean> = _authLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _appStage = MutableStateFlow("LOGIN") // "LOGIN", "CATEGORY", "MAIN"
    val appStage: StateFlow<String> = _appStage.asStateFlow()

    private val _userEmail = MutableStateFlow("")
    val userEmail: StateFlow<String> = _userEmail.asStateFlow()

    private val _userName = MutableStateFlow("সাদিক রহমান")
    val userName: StateFlow<String> = _userName.asStateFlow()

    val isRealFirebaseConfigured: Boolean = BuildConfig.FIREBASE_APP_ID.isNotBlank() &&
            BuildConfig.FIREBASE_APP_ID != "PLACEHOLDER" &&
            !BuildConfig.FIREBASE_APP_ID.startsWith("1:1234567890") &&
            BuildConfig.FIREBASE_API_KEY.isNotBlank() &&
            BuildConfig.FIREBASE_API_KEY != "PLACEHOLDER" &&
            !BuildConfig.FIREBASE_API_KEY.startsWith("AIzaSyFakeKey")

    fun setAppStage(stage: String) {
        _appStage.value = stage
    }

    fun clearAuthError() {
        _authError.value = null
    }

    // Dynamic Firebase Sign-Up Flow
    fun signUpWithFirebase(email: String, name: String, outPassword: String) {
        _authLoading.value = true
        _authError.value = null
        
        if (!isRealFirebaseConfigured) {
            // Offline/Local bypass when Real Firebase is not configured
            _userEmail.value = email
            _userName.value = name
            _appStage.value = "CATEGORY"
            _authLoading.value = false
            return
        }

        // Perform strict Firebase remote sign-up with immediate local fallback on failure
        viewModelScope.launch {
            try {
                val auth = FirebaseAuth.getInstance()
                auth.createUserWithEmailAndPassword(email, outPassword)
                    .addOnCompleteListener { task ->
                        _authLoading.value = false
                        if (task.isSuccessful) {
                            val user = auth.currentUser
                            val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                                .setDisplayName(name)
                                .build()
                            user?.updateProfile(profileUpdates)
                            
                            _userEmail.value = email
                            _userName.value = name
                            _appStage.value = "CATEGORY"
                        } else {
                            val errorMsg = task.exception?.localizedMessage ?: "সাইন আপ করতে সমস্যা হয়েছে"
                            android.util.Log.e("NerdAIAuth", "Firebase signup failed ($errorMsg), falling back to local session.")
                            
                            // Direct local session fallback so user is never blocked
                            _userEmail.value = email
                            _userName.value = name
                            _appStage.value = "CATEGORY"
                        }
                    }
            } catch (e: Exception) {
                _authLoading.value = false
                android.util.Log.e("NerdAIAuth", "Firebase signup exception (${e.message}), falling back to local session.")
                
                // Direct local session fallback so user is never blocked
                _userEmail.value = email
                _userName.value = name
                _appStage.value = "CATEGORY"
            }
        }
    }

    // Dynamic Firebase Login Flow
    fun loginWithFirebase(email: String, outPassword: String) {
        _authLoading.value = true
        _authError.value = null

        if (!isRealFirebaseConfigured) {
            // Offline/Local bypass when Real Firebase is not configured
            _userEmail.value = email
            val localName = email.substringBefore("@").replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
            _userName.value = localName
            _appStage.value = "CATEGORY"
            _authLoading.value = false
            return
        }

        // Perform strict Firebase remote login with immediate local fallback on failure
        viewModelScope.launch {
            try {
                val auth = FirebaseAuth.getInstance()
                auth.signInWithEmailAndPassword(email, outPassword)
                    .addOnCompleteListener { task ->
                        _authLoading.value = false
                        if (task.isSuccessful) {
                            val user = auth.currentUser
                            _userEmail.value = user?.email ?: email
                            _userName.value = user?.displayName ?: email.substringBefore("@").replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
                            _appStage.value = "CATEGORY"
                        } else {
                            val errorMsg = task.exception?.localizedMessage ?: "লগইন করতে সমস্যা হয়েছে"
                            android.util.Log.e("NerdAIAuth", "Firebase login failed ($errorMsg), falling back to local session.")
                            
                            // Direct local session fallback so user is never blocked
                            _userEmail.value = email
                            val localName = email.substringBefore("@").replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
                            _userName.value = localName
                            _appStage.value = "CATEGORY"
                        }
                    }
            } catch (e: Exception) {
                _authLoading.value = false
                android.util.Log.e("NerdAIAuth", "Firebase login exception (${e.message}), falling back to local session.")
                
                // Direct local session fallback so user is never blocked
                _userEmail.value = email
                val localName = email.substringBefore("@").replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
                _userName.value = localName
                _appStage.value = "CATEGORY"
            }
        }
    }

    fun loginUser(email: String, name: String = "") {
        _userEmail.value = email
        if (name.isNotEmpty()) {
            _userName.value = name
        } else {
            val part = email.substringBefore("@")
            _userName.value = part.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }
        _appStage.value = "CATEGORY"
    }

    fun logoutUser() {
        try {
            FirebaseAuth.getInstance().signOut()
        } catch (e: Exception) {
            android.util.Log.e("NerdAIAuth", "Firebase Auth signOut error: ${e.message}")
        }
        _userEmail.value = ""
        _userName.value = "সাদিক রহমান"
        _appStage.value = "LOGIN"
    }

    private val _selectedCategory = MutableStateFlow("SSC") // "SSC", "HSC", "Job Seeker"
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _isPremium = MutableStateFlow(false) // Start as free, updated upon successful simulated payment
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()

    private val _selectedScanSpotIndex = MutableStateFlow(-1)
    val selectedScanSpotIndex: StateFlow<Int> = _selectedScanSpotIndex.asStateFlow()

    fun setSelectedScanSpotIndex(index: Int) {
        _selectedScanSpotIndex.value = index
    }

    fun updateSelectedCategory(category: String) {
        _selectedCategory.value = category
        _selectedScanSpotIndex.value = -1
    }

    fun togglePremiumStatus() {
        _isPremium.value = !_isPremium.value
    }

    // --- Browsing Chat (Top Card 1) ---
    private val _browsingQuery = MutableStateFlow("")
    val browsingQuery: StateFlow<String> = _browsingQuery.asStateFlow()

    private val _browsingResult = MutableStateFlow("")
    val browsingResult: StateFlow<String> = _browsingResult.asStateFlow()

    private val _isBrowsingLoading = MutableStateFlow(false)
    val isBrowsingLoading: StateFlow<Boolean> = _isBrowsingLoading.asStateFlow()

    private val _browsingError = MutableStateFlow<String?>(null)
    val browsingError: StateFlow<String?> = _browsingError.asStateFlow()

    // --- Active Tool Dialog UI State ---
    private val _activeToolName = MutableStateFlow<String?>(null)
    val activeToolName: StateFlow<String?> = _activeToolName.asStateFlow()

    private val _toolInput = MutableStateFlow("")
    val toolInput: StateFlow<String> = _toolInput.asStateFlow()

    private val _toolResponse = MutableStateFlow("")
    val toolResponse: StateFlow<String> = _toolResponse.asStateFlow()

    private val _isToolLoading = MutableStateFlow(false)
    val isToolLoading: StateFlow<Boolean> = _isToolLoading.asStateFlow()

    private val _toolError = MutableStateFlow<String?>(null)
    val toolError: StateFlow<String?> = _toolError.asStateFlow()

    // --- Scan & Solve States (Bottom Tab 2) ---
    private val _scansCountToday = MutableStateFlow(0)
    val scansCountToday: StateFlow<Int> = _scansCountToday.asStateFlow()

    private val _showScanLimitDialog = MutableStateFlow(false)
    val showScanLimitDialog: StateFlow<Boolean> = _showScanLimitDialog.asStateFlow()

    fun dismissScanLimitDialog() {
        _showScanLimitDialog.value = false
    }

    fun forceActivatePremium() {
        _isPremium.value = true
        _showScanLimitDialog.value = false
    }

    private val _scanInputQuery = MutableStateFlow("এই প্রশ্ন বা গানিতিক সমস্যাটি বিশদভাবে সমাধান করে ধাপে ধাপে বুঝিয়ে দাও।")
    val scanInputQuery: StateFlow<String> = _scanInputQuery.asStateFlow()

    private val _scanSolution = MutableStateFlow("")
    val scanSolution: StateFlow<String> = _scanSolution.asStateFlow()

    private val _isScanLoading = MutableStateFlow(false)
    val isScanLoading: StateFlow<Boolean> = _isScanLoading.asStateFlow()

    private val _scanError = MutableStateFlow<String?>(null)
    val scanError: StateFlow<String?> = _scanError.asStateFlow()

    private val _selectedImageBase64 = MutableStateFlow<String?>(null)
    val selectedImageBase64: StateFlow<String?> = _selectedImageBase64.asStateFlow()

    private val _selectedImageName = MutableStateFlow<String?>(null) // "math_page.png" etc.
    val selectedImageName: StateFlow<String?> = _selectedImageName.asStateFlow()

    // --- AI Tutor States (Bottom Tab 3) ---
    private val _selectedTutor = MutableStateFlow("ইংলিশ গুরু (English Guru)")
    val selectedTutor: StateFlow<String> = _selectedTutor.asStateFlow()

    private val _tutorMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val tutorMessages: StateFlow<List<ChatMessage>> = _tutorMessages.asStateFlow()

    private val _isTutorLoading = MutableStateFlow(false)
    val isTutorLoading: StateFlow<Boolean> = _isTutorLoading.asStateFlow()

    private val _tutorError = MutableStateFlow<String?>(null)
    val tutorError: StateFlow<String?> = _tutorError.asStateFlow()

    // --- Assistant States (Legacy support if accessed, but now unified) ---
    private val _assistantInput = MutableStateFlow("")
    val assistantInput: StateFlow<String> = _assistantInput.asStateFlow()

    private val _assistantResponse = MutableStateFlow("")
    val assistantResponse: StateFlow<String> = _assistantResponse.asStateFlow()

    private val _isAssistantLoading = MutableStateFlow(false)
    val isAssistantLoading: StateFlow<Boolean> = _isAssistantLoading.asStateFlow()

    private val _selectedTemplate = MutableStateFlow("সাধারণ লার্নিং")
    val selectedTemplate: StateFlow<String> = _selectedTemplate.asStateFlow()

    private val _assistantError = MutableStateFlow<String?>(null)
    val assistantError: StateFlow<String?> = _assistantError.asStateFlow()

    // --- Translation States (Legacy/Double Translate Tab supporting Language Card) ---
    private val _translationInput = MutableStateFlow("")
    val translationInput: StateFlow<String> = _translationInput.asStateFlow()

    private val _translationResponse = MutableStateFlow("")
    val translationResponse: StateFlow<String> = _translationResponse.asStateFlow()

    private val _isTranslationLoading = MutableStateFlow(false)
    val isTranslationLoading: StateFlow<Boolean> = _isTranslationLoading.asStateFlow()

    private val _isEnglishToBangla = MutableStateFlow(true)
    val isEnglishToBangla: StateFlow<Boolean> = _isEnglishToBangla.asStateFlow()

    private val _translationError = MutableStateFlow<String?>(null)
    val translationError: StateFlow<String?> = _translationError.asStateFlow()

    // --- Specialized Language Tab (0 = Grammar Checker, 1 = Translate) ---
    private val _languageToolTab = MutableStateFlow(0)
    val languageToolTab: StateFlow<Int> = _languageToolTab.asStateFlow()

    fun setLanguageToolTab(tab: Int) {
        _languageToolTab.value = tab
    }

    // --- Specialized Summarizer Tab (0 = Summary, 1 = Notes) ---
    private val _summarizerToolTab = MutableStateFlow(0)
    val summarizerToolTab: StateFlow<Int> = _summarizerToolTab.asStateFlow()

    fun setSummarizerToolTab(tab: Int) {
        _summarizerToolTab.value = tab
    }

    // --- Room Database Stream ---
    val historyRecords: StateFlow<List<StudyRecord>> = repository.allRecords
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val bookmarkedRecords: StateFlow<List<StudyRecord>> = repository.bookmarkedRecords
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        resetTutorChat()
        // Restore existing Firebase Authentication user state on startup
        try {
            val auth = FirebaseAuth.getInstance()
            val user = auth.currentUser
            if (user != null) {
                _userEmail.value = user.email ?: ""
                _userName.value = user.displayName ?: (user.email ?: "সাদিক রহমান").substringBefore("@")
                _appStage.value = "MAIN" // Auto-login directly to the Main Screen
            }
        } catch (e: Exception) {
            android.util.Log.e("NerdAIAuth", "Firebase startup session restore check failed: ${e.message}")
        }
    }

    // --- Setters ---
    fun updateBrowsingQuery(query: String) {
        _browsingQuery.value = query
    }

    fun openToolDialog(toolName: String) {
        _activeToolName.value = toolName
        _toolInput.value = ""
        _toolResponse.value = ""
        _toolError.value = null
    }

    fun closeToolDialog() {
        _activeToolName.value = null
    }

    fun updateToolInput(input: String) {
        _toolInput.value = input
    }

    fun updateScanInputQuery(query: String) {
        _scanInputQuery.value = query
    }

    fun setSelectedImage(base64: String?, name: String?) {
        _selectedImageBase64.value = base64
        _selectedImageName.value = name
    }

    fun selectTutor(tutorName: String) {
        _selectedTutor.value = tutorName
        resetTutorChat()
    }

    fun updateAssistantInput(input: String) {
        _assistantInput.value = input
    }

    fun selectTemplate(templateName: String) {
        _selectedTemplate.value = templateName
    }

    fun updateTranslationInput(input: String) {
        _translationInput.value = input
    }

    fun toggleTranslationDirection() {
        _isEnglishToBangla.value = !_isEnglishToBangla.value
    }

    // --- Actions ---

    // 1. Browsing Chat (Real-time simulated AI Web search info)
    fun solveBrowsingQuery() {
        val query = _browsingQuery.value.trim()
        if (query.isEmpty()) return

        if (!isApiKeyConfigured) {
            _browsingError.value = "Gemini API কী দেওয়া নেই! AI Studio Secrets প্যানেলে GEMINI_API_KEY যোগ করুন।"
            return
        }

        viewModelScope.launch {
            _isBrowsingLoading.value = true
            _browsingError.value = null
            _browsingResult.value = ""

            val systemPrompt = """
                You are a smart AI Search engine optimized for educational queries in Bengali context called "Nerd AI Web Search Companion".
                Conduct a simulated web-browse and gather the latest facts regarding the user's study query.
                Format the answer beautifully in clean Bengali with high-contrast sections, structured bullet points, and mock credibility source citations at the bottom (e.g. [উৎস: উইকিপিডিয়া, উইকি বুকস, জুন ২০২৬]).
                Make it look highly academic, updated, and extremely credible.
                
                [MANDATORY FORMATTING RULES]:
                1. Always format equations, algebraic formulas, fractions, and scientific symbols using standard LaTeX syntax (e.g., use $ for inline math like $x^2$, and $$...$$ for block display math like $$\frac{a}{b}$$).
                2. For any comparative data, calculations, balances, or accounting entries, ALWAYS use standard Markdown tables with pipes (|) and hyphens (-) so they render as beautiful high-contrast tabular sheets.
                3. Solve all problems in pure Bengali step-by-step exactly like Bangladeshi textbook style (NCTB SSC/HSC and NTRCA standards).
                4. NEVER use raw or unparsed LaTeX transitional operators like '\implies', '\Rightarrow', '\quad \text{...}', or '\text{...}' inside math formulas. Instead, use standard Bengali transitional words like "বা," (or), "অথবা," (or), "সুতরাং" (therefore) at the start of mathematical steps outside the math block or as a plain Bengali prefix.
                5. Structure problems beautifully starting with 'দেওয়া আছে:' (Given:), 'ধরি:' (Let:), 'আমরা জানি:' (We know:), and concluding with 'নির্ণেয় সমাধান:' (Therefore, the required solution is:).
            """.trimIndent()

            val request = GenerateContentRequest(
                contents = listOf(Content(parts = listOf(Part(text = query)))),
                systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
                generationConfig = GenerationConfig(temperature = 0.5f)
            )

            try {
                val response = callGeminiWithFallback(request)
                val textResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                if (textResponse != null) {
                    _browsingResult.value = textResponse
                    // Save web search query to database history
                    repository.insertRecord(
                        StudyRecord(
                            type = "ASSISTANT",
                            inputQuery = query,
                            outputResult = textResponse,
                            additionalInfo = "ওয়েব ব্রাউজিং চ্যাট"
                        )
                    )
                } else {
                    _browsingError.value = "সার্ভার থেকে কোনো ফলাফল পাওয়া যায়নি।"
                }
            } catch (e: Exception) {
                _browsingError.value = getErrorMessage(e)
            } finally {
                _isBrowsingLoading.value = false
            }
        }
    }

    // 2. Specialized Tool Solver
    fun solveToolQuery() {
        val toolName = _activeToolName.value ?: return
        val query = _toolInput.value.trim()
        if (query.isEmpty()) return

        if (!isApiKeyConfigured) {
            _toolError.value = "Gemini API কী দেওয়া নেই! Secrets প্যানেল থেকে GEMINI_API_KEY বসান।"
            return
        }

        val category = _selectedCategory.value

        viewModelScope.launch {
            _isToolLoading.value = true
            _toolResponse.value = ""
            _toolError.value = null

            val sysPrompt = when (toolName) {
                "Learning Assistant" -> { // "Board Suggestions"
                    if (category == "Job Seeker") {
                        """
                            আপনি সরকারি চাকরি পরীক্ষার (BCS, Primary, NTRCA, Bank Exams) জন্য একজন অভিজ্ঞ বোর্ড সাজেশনস বিশেষজ্ঞ ও প্যানেল শিক্ষক।
                            ব্যবহারকারী যে কোনো টপিক বা বিষয়ের নাম উল্লেখ করলে:
                            - পিএসসির সাম্প্রতিক প্রশ্নের ট্রেন্ড ও বিগত নিয়োগ পরীক্ষার প্রশ্ন বিশ্লেষণ করে সবচেয়ে গুরুত্বপূর্ণ শীর্ষ ১৫টি (Top 15) বারবার আসা গুরুত্বপূর্ণ এবং কনফিউজিং প্রশ্ন এবং তাদের নিখুঁত ও নির্ভরযোগ্য উত্তর দিন।
                            - উত্তরগুলোর নিচে কেন এই প্রশ্নটি বারবার আসে এবং পরীক্ষায় মার্কস তোলার সহজ ট্রিক সংক্ষেপে উল্লেখ করতে পারেন।
                            - সম্পূর্ণ উত্তরটি অত্যন্ত চমৎকার, পেশাদার ও গোছানো লেআউট ডিজাইনে উপস্থাপন করবেন।
                            - একাডেমিক বা পাঠ্যবইয়ের মতন চমৎকার লেআউট নিশ্চিত করতে নিচের রুলস মেনে চলুন:
                              ১. গাণিতিক সমীকরণগুলো দেখাতে স্ট্যান্ডার্ড LaTeX সিনট্যাক্স ব্যবহার করুন (যেমন inline math-এর জন্য $ এবং display block math-এর জন্য $$...$$)। যেমন: \frac{a}{b}, x^2, \sqrt{y}, \pm, \theta ইত্যাদি।
                              ২. হিসাববিজ্ঞান, ফিন্যান্স বা তুলনামূলক বিজ্ঞপ্তির জন্য অবশ্যই স্ট্যান্ডার্ড Markdown টেবিল ছক (যেমন | বিবরণ | পরিমাণ |) ব্যবহার করে সুন্দর লেজার বা ক্যালকুলেশন ছক আকারে দেখাবেন।
                              ৩. রসায়ন, পদার্থবিজ্ঞান, আইসিটি বিষয়ের সমীকরণ বা তথ্যগুলো পরিপাটি হেডলাইন ও ক্রমানুসারী ধাপে ধাপে সাজিয়ে দেবেন।
                        """.trimIndent()
                    } else {
                        """
                            আপনি বাংলাদেশের $category বোর্ড পরীক্ষার একজন শীর্ষস্থানীয় বিষয় বিশেষজ্ঞ ও প্যানেল শিক্ষক।
                            ব্যবহারকারী যে কোনো বিষয় বা অধ্যায়ের নাম উল্লেখ করলে:
                            - বিগত ৫-১০ বছরের বোর্ড পরীক্ষার প্রশ্ন এবং টেস্ট পেপার এনালাইসিস করে শীর্ষ ১০টি সুপার সাজেশনস প্রশ্ন ও তাদের নিখুঁত সমাধান প্রস্তুত করুন।
                            - উত্তরগুলো বাংলায় অত্যন্ত দৃষ্টিনন্দন লেআউটে সাজিয়ে লিখুন যাতে শিক্ষার্থীরা সর্বোচ্চ সুবিধা পায়।
                            - একাডেমিক বা পাঠ্যবইয়ের মতন চমৎকার লেআউট নিশ্চিত করতে নিচের রুলস মেনে চলুন:
                              ১. গাণিতিক সমীকরণগুলো দেখাতে স্ট্যান্ডার্ড LaTeX সিনট্যাক্স ব্যবহার করুন (যেমন inline math-এর জন্য $ এবং display block math-এর জন্য $$...$$)। যেমন: \frac{a}{b}, x^2, \sqrt{y}, \pm, \theta ইত্যাদি।
                              ২. হিসাববিজ্ঞান, ফিন্যান্স বা তুলনামূলক বিজ্ঞপ্তির জন্য অবশ্যই স্ট্যান্ডার্ড Markdown টেবিল ছক (যেমন | বিবরণ | পরিমাণ |) ব্যবহার করে সুন�                    } else {
                        """
                            আপনি বাংলাদেশের $category ক্লাসের একজন অত্যন্ত নির্ভরযোগ্য শিক্ষক ও অধ্যায় গবেষক।
                            ব্যবহারকারী যে বোর্ড বইয়ের অধ্যায়, প্যারাগ্রাফ বা শিটের কন্টেন্ট পেস্ট করবে:
                            - তার অত্যন্ত সাবলীল, প্রাঞ্জল ও সমৃদ্ধ বাংলায় "বোর্ড স্ট্যান্ডার্ড পিডিএফ সামারি ও মূলভাব" তৈরি করুন।
                            - অধ্যায়ের গুরুত্বপূর্ণ তথ্য, সংজ্ঞা ও ঐতিহাসিক সালগুলো একত্রে সাজিয়ে চমৎকার "পরীক্ষা প্রস্তুতি কুইক নোটস" তৈরি করুন।
                        """.trimIndent()
                    }
                }              """
                            আপনি বাংলাদেশের $category সিলেবাসের একজন প্রাজ্ঞ ইংরেজি শিক্ষক ও অনুবাদ বিশেষজ্ঞ।
                            ব্যবহারকারীর দেওয়া টেক্সট বাংলা থেকে ইংরেজি বা ইংরেজি থেকে বাংলায় নিখুঁত অনুবাদ করুন এবং সংশ্লিষ্ট গ্রামার বা টেন্সের ব্যবহার ব্যাখ্যা করে দিন।
                        """.trimIndent()
                    }
                }
                "Essay Helper" -> { // "পিডিএফ সামারি"
                    if (category == "Job Seeker") {
                        """
                            আপনি সরকারি চাকরি নিয়োগ পরীক্ষার জন্য একজন এক্সপার্ট লার্নিং সামারাইজার ও অনুচ্ছেদ গবেষক।
                            ব্যবহারকারী যে টেক্সট, রচনা বা বইয়ের কন্টেন্ট এখানে পেস্ট করবে:
                            - তার প্রধান প্রধান যুক্তি ও তথ্যগুলো অত্যন্ত গভীর এবং সুনির্দিষ্টভাবে বিশ্লেষণ করে একটি অত্যন্ত প্রিমিয়াম সারাংশ এবং পিডিএফ ফরম্যাটের মতন বুলেট কন্টেন্ট তৈরি করুন।
                            - জটিল কঠিন কন্টেন্ট সহজে বোঝার জন্য চমৎকার রিডিং টিপস দিয়ে সাহায্য করুন।
                            - সম্পূর্ণ সামারি বিশদভাবে বাংলায় ক্রমানুসারে পয়েন্ট দিয়ে সাজান।
                        """.trimIndent()
                    } else {
                        """
                            আপনি বাংলাদেশের $category ক্লাসের একজন অত্যন্ত নির্ভরযোগ্য শিক্ষক ও অধ্যায় গবেষক।
                            ব্যবহারকারী যে বোর্ড বইয়ের অধ্যায়, প্যারাগ্রাফ বা শিটের কন্টেন্ট পেস্ট করবে:
                            - তার অত্যন্ত সাবলীল, প্রাঞ্জল ও সমৃদ্ধ বাংলায় "বোর্ড স্ট্যান্ডার্ড পিডিএফ সামারি ও মূলভাব" �                "SSC", "HSC" -> {
                    """
                        আপনি বাংলাদেশের শিক্ষা ব্যবস্থা, কারিকুলাম এবং প্রশ্নপত্রের ধরন অনুযায়ী $category পরীক্ষার একজন শীর্ষস্থানীয় প্যানেল শিক্ষক, ক্রিয়েটিভ কন্টেন্ট রাইটার এবং প্রশ্নপত্র প্রণয়ন বিশেষজ্ঞ।
                        রুলস (সবার জন্য সমান সুযোগ ও বিস্তারিত গাইড):
                        - আপনার সামনে দেওয়া বইয়ের পাতা বা খাতার হাতের লেখার চমৎকার, অত্যন্ত বিশদ ও ধাপে ধাপে গাণিতিক বা থিওরিটিক্যাল ব্যাখ্যা প্রদান করুন।
                        - প্রথমে "কী কী দেওয়া আছে" এবং প্রয়োজনীয় সূত্রগুলো উল্লেখ করুন।
                        - এরপর চূড়ান্ত উত্তর পর্যন্ত একাডেমিকভাবে অত্যন্ত নিখুঁত সমাধান বাংলার মাধ্যমে করে দিন।
                        - উত্তরের শেষে একটি বিশেষ "Shortcut Magic Trick & Quick Recall Tips" (শর্টকাট ট্রিক ও মেমোরি টিপস) সেকশন যোগ করুন, যা যেকোনো কুইজে দ্রুত ব্যবহারের জন্য দারুণ ভূমিকা রাখবে।
                        - একাডেমিক বা পাঠ্যবইয়ের (NCTB এবং NTRCA স্ট্যান্ডার্ড) মতন চমৎকার লেআউট নিশ্চিত করতে নিচের রুলস মেনে চলুন:
                          ১. গাণিতিক ও বিজ্ঞান সমীকরণগুলো দেখাতে স্ট্যান্ডার্ড LaTeX সিনট্যাক্স ব্যবহার করুন (যেমন inline math-এর জন্য $ এবং display block math-এর জন্য $$...$$)। যেমন: \frac{a}{b}, x^2, \sqrt{y}, \pm, \theta ইত্যাদি।
                          ২. হিসাববিজ্ঞান (Accounting), ফিন্যান্স বা কমার্সের লেনদেনের প্রভাব (যেমন: A = L + OE এর প্রভাব ছক), ஜাবেদা, খতিয়ান, বিবরণী বা যেকোনো তুলনামূলক গাণিতিক তথ্যের জন্য অবশ্যই স্ট্যান্ডার্ড Markdown টেবিল ছক (যেমন | বিবরণ | পরিমাণ |) ব্যবহার করে সুন্দর ছক আকারে দেখাবেন। কখনোই সাধারণ স্পেস বা টেক্সট দিয়ে কলাম সাজাবেন না, সবসময় পাইপ (|) দিয়ে টেবিল তৈরি করবেন।
                          ৩. রসায়ন, পদার্থবিজ্ঞান, আইসিটি বিষয়ের সমীকরণ বা তথ্যগুলো পরিপাটি হেডলাইন ও ক্রমানুসারী ধাপে ধাপে সাজিয়ে দেবেন।
                    """.trimIndent()
                }�                else -> { // Job Seeker
                    """
                        আপনি বাংলাদেশের সরকারি চাকরি পরীক্ষার (BCS, Primary, NTRCA, Bank ও অন্যান্য Job) একজন শীর্ষ প্যানেল শিক্ষক ও এমসিকিউ বিশেষজ্ঞ।
                        রুলস (সবার জন্য সমান সুযোগ ও বিস্তারিত গাইড):
                        - ছবির গাণিতিক বা ব্যাকরণগত প্রশ্নের সঠিক উত্তর এবং তার অত্যন্ত নিখুঁত ও চমৎকার ব্যাখ্যা তৈরি করুন।
                        - সমাধানের শেষে একটি "Shortcut Magic Trick" (শর্টকাট ম্যাজিক ট্রিক) নামক ডেডিকেটেড সেকশন যুক্ত করুন, যার মাধ্যমে চাকরি প্রত্যাশীরা কোনো ক্যালকুলেটর ছাড়াই ৫-১০ সেকেন্ডের মধ্যে অবিশ্বাস্য শর্টকাটে সমাধান করার কৌশল শিখে নিতে পারেন।
                        - একাডেমিক বা পাঠ্যবইয়ের (NCTB এবং NTRCA স্ট্যান্ডার্ড) মতন চমৎকার লেআউট নিশ্চিত করতে নিচের রুলস মেনে চলুন:
                          ১. গাণিতিক ও বিজ্ঞান সমীকরণগুলো দেখাতে স্ট্যান্ডার্ড LaTeX সিনট্যাক্স ব্যবহার করুন (যেমন inline math-এর জন্য $ এবং display block math-এর জন্য $$...$$)। যেমন: \frac{a}{b}, x^2, \sqrt{y}, \pm, \theta ইত্যাদি।
                          ২. হিসাববিজ্ঞান (Accounting), ফিন্যান্স বা কমার্সের লেনদেনের প্রভাব (যেমন: A = L + OE এর প্রভাব ছক), জাবেদা, খতিয়ান, বিবরণী বা যেকোনো তুলনামূলক গাণিতিক তথ্যের জন্য অবশ্যই স্ট্যান্ডার্ড Markdown টেবিল ছক (যেমন | বিবরণ | পরিমাণ |) ব্যবহার করে সুন্দর ছক আকারে দেখাবেন। কখনোই সাধারণ স্পেস বা টেক্সট দিয়ে কলাম সাজাবেন না, সবসময় পাইপ (|) দিয়ে টেবিল তৈরি করবেন।
                          ৩. রসায়ন, পদার্থবিজ্ঞান, আইসিটি বিষয়ের সমীকরণ বা তথ্যগুলো পরিপাটি হেডলাইন ও ক্রমানুসারী ধাপে ধাপে সাজিয়ে দেবেন।
                    """.trimIndent()
                }             } else {
                            """
                                আপনি স্কুল-কলেজ শিক্ষার্থীদের জন্য একজন অভিজ্ঞ স্টাডি নোট গবেষক।
                                প্রদত্ত কন্টেন্ট বা চ্যাপ্টারের মূল সূত্র, সংজ্ঞা ও ঐতিহাসিক সালগুলো একত্রে সাজিয়ে চমৎকার "পরীক্ষা প্রস্তুতি কুইক নোটস" তৈরি করুন।
                            """.trimIndent()
                        }
                    }
                }
                "Code Enhancer" -> { // "MCQ প্র্যাকটিস"
                    if (category == "Job Seeker") {
                        """
                            আপনি সরকারি চাকরি পরীক্ষার (BCS, NTRCA, Bank) এমসিকিউ ও কোশ্চেন ব্যাংক বিশেষজ্ঞ।
                            ব্যবহারকারী যে বিষয়ের নাম বলবে, সেখান থেকে বিগত বছরগুলোর প্রিলি পরীক্ষায় আসা বা আসন্ন নিয়োগ পরীক্ষার উপযোগী ৫টি অত্যন্ত প্যাঁচানো বা ট্রিকি কুইজ প্রশ্ন (MCQ আকারে ৪টি অপশন সহ) তৈরি করুন।
                            - প্রতিটি প্রশ্নের সঠিক উত্তর এবং তার পিছনে অত্যন্ত বিস্তারিত যৌক্তিক কারণ ব্যাখ্যা করুন যেন প্রার্থীরা সহজে আয়ত্ত করতে পারেন।
                            - একাডেমিক বা পাঠ্যবইয়ের মতন চমৎকার লেআউট নিশ্চিত করতে স্ট্যান্ডার্ড LaTeX কোড (যেমন inline math-এর জন্য $ এবং display block math-এর জন্য $$...$$) এবং স্ট্যান্ডার্ড Markdown টেবিল ব্যবহার করবেন।
                        """.trimIndent()
                    } else {
                        """
                            আপনি বাংলাদেশের $category পর্ষদের বোর্ড পরীক্ষার একজন তুখোর MCQ প্রশ্নপত্র প্রণয়ন বিশেষজ্ঞ।
                            ব্যবহারকারী যে বিষয়ের নাম বলবে, সেখান থেকে বিগত বছরগুলোর বোর্ড পরীক্ষার মানের ৫টি স্ট্যান্ডার্ড MCQ প্রশ্ন (চারটি অপশন সহ) তৈরি করুন।
                            - কুইজের নিচে সম্পূর্ণ সঠিক উত্তরমালা এবং ছাত্রছাত্রীদের ভুল এড়ানোর জন্য ট্রিক সহ ছোট ব্যাখ্যা প্রদান করুন।
                            - একাডেমিক বা পাঠ্যবইয়ের মতন চমৎকার লেআউট নিশ্চিত করতে স্ট্যান্ডার্ড LaTeX কোড (যেমন inline math-এর জন্য $ এবং display block math-এর জন্য $$...$$) এবং স্ট্যান্ডার্ড Markdown টেবিল ব্যবহার করবেন।
                        """.trimIndent()
                    }
                }
                else -> "আপনি একজন চমৎকার এআই পাঠ্য শিক্ষক।"
            }

            if (isApiKeyConfigured) {
                val generationRequest = GenerateContentRequest(
                    contents = listOf(Content(parts = listOf(Part(text = query)))),
                    systemInstruction = Content(parts = listOf(Part(text = sysPrompt))),
                    generationConfig = GenerationConfig(temperature = 0.4f)
                )
                try {
                    val response = callGeminiWithFallback(generationRequest)
                    val textResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (textResponse != null) {
                        _toolResponse.value = textResponse
                        val banglaFormatName = when (toolName) {
                            "Learning Assistant" -> "বোর্ড সাজেশনস"
                            "Content Generator" -> "বোর্ড ফরম্যাট রাইটার"
                            "Language" -> "অনুবাদ ও গ্রামার"
                            "Essay Helper" -> "পিডিএফ সামারি"
                            "Summarizer" -> "নোটস ও সামারি"
                            "Code Enhancer" -> "MCQ প্র্যাকটিস"
                            else -> toolName
                        }
                        repository.insertRecord(
                            StudyRecord(
                                type = "ASSISTANT",
                                inputQuery = query,
                                outputResult = textResponse,
                                additionalInfo = banglaFormatName
                            )
                        )
                    } else {
                        _toolError.value = "সার্ভার থেকে পর্যাপ্ত বিবরণ পাওয়া যায়নি।"
                    }
                } catch (e: Exception) {
                    _toolError.value = getErrorMessage(e)
                } finally {
                    _isToolLoading.value = false
                }
            }
        }
    }


    // 3. Scan & Solve Visual Solver (Bottom Tab 2)
    fun solveScanAndSolve() {
        val base64Img = _selectedImageBase64.value
        val prompt = _scanInputQuery.value.trim()

        if (base64Img == null) {
            _scanError.value = "দয়া করে একটি বইয়ের পৃষ্ঠা বা খাতার গাণিতিক সমস্যার ছবি সিলেক্ট বা স্ক্যান করুন!"
            return
        }

        if (!isApiKeyConfigured) {
            _scanError.value = "Gemini API কী কনফিগার করা নেই। secrets-এ GEMINI_API_KEY সংযুক্ত করুন।"
            return
        }

        // Enforce scan limit check: premium users have unlimited; free users are limited to 5 scans
        val isPremiumVal = _isPremium.value
        if (!isPremiumVal && _scansCountToday.value >= 5) {
            _showScanLimitDialog.value = true
            return
        }

        viewModelScope.launch {
            _isScanLoading.value = true
            _scanError.value = null
            _scanSolution.value = ""

            val category = _selectedCategory.value

            // Universal Solutions: High quality, detailed step-by-step solutions with shortcut tricks for both free and premium users
            val sysPrompt = when (category) {
                "SSC", "HSC" -> {
                    """
                        আপনি বাংলাদেশের শিক্ষা ব্যবস্থা, কারিকুলাম এবং প্রশ্নপত্রের ধরন অনুযায়ী $category পরীক্ষার একজন শীর্ষস্থানীয় প্যানেল শিক্ষক, ক্রিয়েটিভ কন্টেন্ট রাইটার এবং প্রশ্নপত্র প্রণয়ন বিশেষজ্ঞ।
                        রুলস (সবার জন্য সমান সুযোগ ও বিস্তারিত গাইড):
                        - আপনার সামনে দেওয়া বইয়ের পাতা বা খাতার হাতের লেখার চমৎকার, অত্যন্ত বিশদ ও ধাপে ধাপে গাণিতিক বা থিওরিটিক্যাল ব্যাখ্যা প্রদান করুন।
                        - প্রথমে "কী কী দেওয়া আছে" এবং প্রয়োজনীয় সূত্রগুলো উল্লেখ করুন।
                        - এরপর চূড়ান্ত উত্তর পর্যন্ত একাডেমিকভাবে অত্যন্ত নিখুঁত সমাধান বাংলার মাধ্যমে করে দিন।
                        - উত্তরের শেষে একটি বিশেষ "Shortcut Magic Trick & Quick Recall Tips" (শর্টকাট ট্রিক ও মেমোরি টিপস) সেকশন যোগ করুন, যা যেকোনো কুইজে দ্রুত ব্যবহারের জন্য দারুণ ভূমিকা রাখবে।
                        - একাডেমিক বা পাঠ্যবইয়ের মতন চমৎকার লেআউট নিশ্চিত করতে নিচের রুলস মেনে চলুন:
                          ১. গাণিতিক সমীকরণগুলো দেখাতে স্ট্যান্ডার্ড LaTeX সিনট্যাক্স ব্যবহার করুন (যেমন inline math-এর জন্য $ এবং display block math-এর জন্য $$...$$)। যেমন: \frac{a}{b}, x^2, \sqrt{y}, \pm, \theta ইত্যাদি।
                          ২. হিসাববিজ্ঞান, ফিন্যান্স বা কমার্সের জন্য অবশ্যই স্ট্যান্ডার্ড Markdown টেবিল ছক (যেমন | বিবরণ | পরিমাণ |) ব্যবহার করে সুন্দর লেজার, জাবেদা বা ক্যালকুলেশন ছক আকারে দেখাবেন।
                          ৩. রসায়ন, পদার্থবিজ্ঞান, আইসিটি বিষয়ের সমীকরণ বা তথ্যগুলো পরিপাটি হেডলাইন ও ক্রমানুসারী ধাপে ধাপে সাজিয়ে দেবেন।
                    """.trimIndent()
                }
                else -> { // Job Seeker
                    """
                        আপনি বাংলাদেশের সরকারি চাকরি পরীক্ষার (BCS, Primary, NTRCA, Bank ও অন্যান্য Job) একজন শীর্ষ প্যানেল শিক্ষক ও এমসিকিউ বিশেষজ্ঞ।
                        রুলস (সবার জন্য সমান সুযোগ ও বিস্তারিত গাইড):
                        - ছবির গাণিতিক বা ব্যাকরণগত প্রশ্নের সঠিক উত্তর এবং তার অত্যন্ত নিখুঁত ও চমৎকার ব্যাখ্যা তৈরি করুন।
                        - সমাধানের শেষে একটি "Shortcut Magic Trick" (শর্টকাট ম্যাজিক ট্রিক) নামক ডেডিকেটেড সেকশন যুক্ত করুন, যার মাধ্যমে চাকরি প্রত্যাশীরা কোনো ক্যালকুলেটর ছাড়াই ৫-১০ সেকেন্ডের মধ্যে অবিশ্বাস্য শর্টকাটে সমাধান করার কৌশল শিখে নিতে পারেন।
                        - একাডেমিক বা পাঠ্যবইয়ের মতন চমৎকার লেআউট নিশ্চিত করতে নিচের রুলস মেনে চলুন:
                          ১. গাণিতিক সমীকরণগুলো দেখাতে স্ট্যান্ডার্ড LaTeX সিনট্যাক্স ব্যবহার করুন (যেমন inline math-এর জন্য $ এবং display block math-এর জন্য $$...$$)। যেমন: \frac{a}{b}, x^2, \sqrt{y}, \pm, \theta ইত্যাদি।
                          ২. হিসাববিজ্ঞান, ফিন্যান্স বা কমার্সের জন্য অবশ্যই স্ট্যান্ডার্ড Markdown টেবিল ছক (যেমন | বিবরণ | পরিমাণ |) ব্যবহার করে সুন্দর লেজার, জাবেদা বা ক্যালকুলেশন ছক আকারে দেখাবেন।
                          ৩. রসায়ন, পদার্থবিজ্ঞান, আইসিটি বিষয়ের সমীকরণ বা তথ্যগুলো পরিপাটি হেডলাইন ও ক্রমানুসারী ধাপে ধাপে সাজিয়ে দেবেন।
                    """.trimIndent()
                }
            }

            val spots = getScanSpotsForCategory(category)
            val selectedSpot = spots.getOrNull(_selectedScanSpotIndex.value)
            val spotRuleAndContext = if (selectedSpot != null) {
                """
                
                [Scan & Solve: Universal Subject & Chapter Context Rules]
                ইউজার যখন "Scan & Solve" মডিউলে একটি স্পট বা সাবজেক্ট সিলেক্ট করবেন, তখন মনে রাখবেন:
                ১. সিলেক্ট করা বিষয় ও অধ্যায়: "${selectedSpot.title}" -> "${selectedSpot.description}"
                ২. নির্দেশনা: এই নির্দিষ্ট বিষয় ও অধ্যায়ের উপর ভিত্তি করে উত্তর প্রদান করুন। তবে লক্ষ্য রাখবেন: এটি কেবল উদাহরণ বা রেফারেন্স, এই বিষয়ের সম্পূর্ণ বই বা সিলেবাসের যেকোনো চ্যাপ্টার বা অধ্যায়ের যেকোনো গাণিতিক ও সৃজনশীল বা ব্যাকরণগত জিজ্ঞাসার অত্যন্ত নিখুঁত সমাধান প্রদান করুন।
                """.trimIndent()
            } else ""

            val finalSysPrompt = sysPrompt + "\n" + spotRuleAndContext + "\nগুরুত্বপূর্ণ নির্দেশাবলী: সব উত্তর বিশুদ্ধ বাংলায় দেবেন। চমৎকার পাঠ্যবইয়ের মতন ফরম্যাটিং লেআউট বজায় রাখতে গণিত বা বিজ্ঞানের সমীকরণ দেখাতে স্ট্যান্ডার্ড LaTeX কোড (যেমন \\frac, \\sqrt, $$, \\( \\)) ব্যবহার করবেন এবং হিসাববিজ্ঞান বা কমার্স বিষয়ের জন্য স্ট্যান্ডার্ড Markdown টেবিল ব্যবহার করবেন।"

            val textPart = Part(text = prompt)
            val imageBlob = Blob(mimeType = "image/jpeg", data = base64Img)
            val imagePart = Part(inlineData = imageBlob)

            val request = GenerateContentRequest(
                contents = listOf(Content(parts = listOf(textPart, imagePart))),
                systemInstruction = Content(parts = listOf(Part(text = finalSysPrompt))),
                generationConfig = GenerationConfig(temperature = 0.2f)
            )

            try {
                val response = callGeminiWithFallback(request)
                val textResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                if (textResponse != null) {
                    _scanSolution.value = textResponse
                    
                    // Increment count for free users only on a successful scan
                    if (!isPremiumVal) {
                        _scansCountToday.value += 1
                    }

                    // Save records with type SCAN
                    val imageName = _selectedImageName.value ?: "Scanned_Problem.jpg"
                    repository.insertRecord(
                        StudyRecord(
                            type = "ASSISTANT",
                            inputQuery = "[ছবি সমাধান - $category • ${if(isPremiumVal) "PRO" else "FREE"}]: $prompt ($imageName)",
                            outputResult = textResponse,
                            additionalInfo = "স্ক্যান ও সমাধান"
                        )
                    )
                } else {
                    _scanError.value = "ছবিটি বিশ্লেষণ করা সম্ভব হয়নি।"
                }
            } catch (e: Exception) {
                _scanError.value = getErrorMessage(e)
            } finally {
                _isScanLoading.value = false
            }
        }
    }


    // 4. AI Tutor Interactive Conversations (Bottom Tab 3)
    fun resetTutorChat() {
         _tutorError.value = null
         val tutor = _selectedTutor.value
         val initialGreeting = when {
             tutor.contains("যেকোনো") || tutor.contains("Any Subject") -> {
                 ChatMessage("AI", "আসসালামু আলাইকুম! আমি তোমার অল-ইন-ওয়ান টিউটর 'যেকোনো বিষয়ের গুরু'। পদার্থবিজ্ঞান, রসায়ন, জীববিজ্ঞান, ইতিহাস, আইসিটি বা অন্য যেকোনো বিষয়ের যেকোনো প্রশ্ন সহজ বাংলায় বুঝতে আমায় নির্ভয়ে জিজ্ঞেস করো!")
             }
             tutor.contains("ইংলিশ") -> {
                 ChatMessage("AI", "হ্যালো! আমি তোমার ইংলিশ টিউটর 'ইংলিশ গুরু'। English grammar, vocabulary প্র্যাকটিস বা চমৎকার কথোপকথন সহজ বাংলায় করতে এখানে টাইপ করো! Let's learn English together!")
             }
             tutor.contains("গণিত") -> {
                 ChatMessage("AI", "আসসালামু আলাইকুম! আমি তোমার ম্যাথ গাইড 'গণিত ভাই'। বীজগণিত, পাটিগণিত বা সুন্দর কোনো গাণিতিক ধাঁধা থাকলে আমায় জিজ্ঞেস করো, সহজ বাংলা ব্যাখ্যায় শিখিয়ে দেব!")
             }
             else -> {
                 ChatMessage("AI", "নমস্কার! আমি তোমার বাংলা ব্যাকরণ ও সাহিত্য শিক্ষক 'বাংলা পণ্ডিত'। সমাস, সন্ধি, বানান বা চমৎকার বাংলা ভাষা বিষয়ক যেকোনো প্রশ্ন হাসিমুখে করে ফেলো!")
             }
         }
         _tutorMessages.value = listOf(initialGreeting)
     }

     fun sendTutorMessage(userText: String) {
         val text = userText.trim()
         if (text.isEmpty()) return

         val currentMessages = _tutorMessages.value.toMutableList()
         currentMessages.add(ChatMessage("USER", text))
         _tutorMessages.value = currentMessages

         if (!isApiKeyConfigured) {
             _tutorError.value = "Gemini API কী কনফিগার করা নেই। AI Studio Secrets প্যানেলে কী যোগ করুন।"
             return
         }

         viewModelScope.launch {
             _isTutorLoading.value = true
             _tutorError.value = null

             val category = _selectedCategory.value
             val tutor = _selectedTutor.value
             val systemPrompt = when {
                 tutor.contains("যেকোনো") || tutor.contains("Any Subject") -> {
                     """
                         আপনি একজন অত্যন্ত দক্ষ ও সর্বজ্ঞ "যেকোনো বিষয়ের গুরু" (Any Subject Guru/Mentor)। বিজ্ঞান (পদার্থবিজ্ঞান, রসায়ন, জীববিজ্ঞান), ইতিহাস, আইসিটি, অর্থনীতি বা যেকোনো বিষয়ের জটিল টপিক আপনি খুব সহজে বুঝিয়ে বলতে ভালোবাসেন।
                         রুলস:
                         - ব্যবহারকারীর যেকোনো বিষয়ের প্রশ্ন বা টপিক অত্যন্ত প্রাঞ্জল ও আকর্ষণীয়ভাবে সহজ বাংলায় ধাপে ধাপে বুঝিয়ে দিন।
                         - উত্তর আকর্ষণীয় করতে বাস্তব জীবনের দারুন উদাহরণ বা মনে রাখার চমৎকার টেকনিক (যেমন ছন্দ/ছক) ব্যবহার করতে পারেন।
                         - উত্তর শেষে কথোপকথন চালু রাখতে এবং পড়ার আগ্রহ বাড়াতে ১টি সহজ প্রাসঙ্গিক প্রশ্ন বা মিনি-কুইজ করুন।
                     """.trimIndent()
                 }
                 tutor.contains("ইংলিশ") -> {
                    if (category == "Job Seeker") {
                        """
                            আপনি প্রসন্ন ও প্রাজ্ঞ "ইংলিশ গুরু" (English Guru), আপনি বাংলাদেশের সরকারি চাকরি পরীক্ষার (BCS, NTRCA, Primary, Bank Exams) সিলেবাস ও কঠিন প্যাঁচানো গ্রামার নিয়মের প্রাজ্ঞ টিউটর। 
                            রুলস:
                            - প্রিপারেশনকে চাঙ্গা করতে জটিল ব্যাকরণ সমস্যা চমৎকার ও পূর্ণাঙ্গভাবে বাংলায় ব্যাখ্যা করুন। 
                            - বচনের নিয়ম, জেরান্ড-পার্টিসিপল, ভয়েস চেঞ্জ, সাবজেক্ট-ভার্ব এগ্রিমেন্টস বা কমন রাইটিং মিস্টেকস নিয়ে সুন্দর ইংরেজি-বাংলা বাক্যের প্র্যাকটিস করান।
                            - উত্তর শেষে কথোপকথন চালু রাখতে এবং পড়ার আগ্রহ বাড়াতে চাকরি প্রার্থীর জন্য প্রাসঙ্গিক ১টি প্রশ্ন করুন।
                        """.trimIndent()
                    } else {
                        """
                            আপনি কিশোর শিক্ষার্থীদের প্রিয় "ইংলিশ গুরু" (English Guru)。আপনি অত্যন্ত ভালোবাসার সাথে ও ফান করে শিক্ষার্থীদের ইংরেজি ব্যাকরণ ও ভোকাবুলারি শিখিয়ে থাকেন। 
                            রুলস:
                            - কন্টেন্টে শিক্ষার্থীদের মনে রাখার সুবিধার জন্য চমৎকার বাস্তব উদাহরণ, মিল বা বৈসাদৃশ্যের তুলনামূলক সুন্দর টেবিল বা ছক এবং মজার "Mnemonics" (মনে রাখার ছন্দ বা টেকনিক) ব্যবহার করুন।
                            - প্রতিটি উত্তর শেষে কথোপকথন চালু রাখতে ১টি চটজলদি মজার কুইজ অথবা প্রশ্ন দিন।
                        """.trimIndent()
                    }
                }
                tutor.contains("গণিত") -> {
                    """
                        আপনি হাসিখুশি "গণিত ভাই" (Math Tutor), একজন অত্যন্ত অভিজ্ঞ গাণিতিক ও হিসাববিজ্ঞান বিষয়ক মেন্টর। 
                        রুলস:
                        - জটিল বীজগণিতীয় সূত্র, সমীকরণ, জ্যামিতিক সম্পাদ্য-উপপাদ্য, হিসাববিজ্ঞান (Accounting) এবং ফিন্যান্সের হিসাবগুলো অত্যন্ত সুন্দর ও সাবলীল বাংলা ভাষায় মজার বাস্তব উদাহরণ সহ ধাপে ধাপে শেখান।
                        - ব্যবহারকারীর কনসেপ্ট সহজে মনে রাখতে সাহায্য করার জন্য মজার "Mnemonics" (ছন্দ টেকনিক বা সূত্র মুখস্থ রাখার শর্টকাট উপায়) বলুন ও শেষে সহজ সমাধান কুইজ দিন।
                        - গণিত, উচ্চতর গণিত, পদার্থবিজ্ঞান, রসায়ন বা বিজ্ঞানের সব গাণিতিক সমাধান দেখাতে স্ট্যান্ডার্ড LaTeX সিনট্যাক্স ব্যবহার করুন (যেমন inline math-এর জন্য $ এবং display block math-এর জন্য $$...$$)। যেমন: \frac{a}{b}, x^2, \sqrt{y}, \pm, \theta ইত্যাদি।
                        
                        [MANDATORY MATH STYLE & NCTB GUIDELINES]:
                        1. বাংলাদেশের SSC, HSC, এবং NTRCA পরীক্ষার পাঠ্যবই (NCTB সিলেবাস) অনুসরণে স্ট্যান্ডার্ড লেআউটে অত্যন্ত বিশদভাবে বুঝিয়ে সমাধান করবেন।
                        2. গণিত সমাধান করার সময় প্রতিটি গাণিতিক লাইনে '\implies' বা '\Rightarrow' বা '\quad \text{অথবা}' বা '\quad \text{বা}' বা '\text' ইত্যাদি র কোড কখনো ব্যবহার করবেন না। এগুলো সম্পূর্ণরূপে নিষিদ্ধ।
                        3. লাইনের শুরুতে বা সমীকরণের পরবর্তী ধাপে যাওয়ার জন্য LaTeX এর ভিতরে বা বাইরে বাংলায় "বা," বা "অথবা," শব্দ ব্যবহার করবেন। যেমন:
                           $$2x + 3 = 7$$
                           বা, $$2x = 7 - 3$$
                           বা, $$2x = 4$$
                           বা, $$x = \frac{4}{2}$$
                           সুতরাং, $$x = 2$$
                           এভাবে সুন্দরভাবে লাইনের প্রথমে বাংলা "বা," বা "সুতরাং," বা "অথবা," লিখে নতুন লাইন দিয়ে সমাধান সাজিয়ে দেবেন। সমীকরণের মাঝে বা শেষে কখনো 'implies' ব্যবহার করবেন না।
                        4. প্রশ্নের সমাধান শুরুর সময় 'দেওয়া আছে:' (Given:), 'ধরি:' (Let:), 'আমরা জানি:' (We know:), এবং শেষ করার সময় 'সুতরাং, নির্ণেয় সমাধান:' (Therefore, the required solution is:) ইত্যাদি সুন্দর বাংলা পরিভাষা ব্যবহার করুন।
                        
                        - হিসাববিজ্ঞান বা ফিন্যান্সের হিসাব, লেনদেন সমীকরণ (যেমন: A = L + OE এর প্রভাব), জাবেদা, খতিয়ান, বিবরণী বা যেকোনো তুলনামূলক তথ্যের জন্য অবশ্যই সুন্দরভাবে স্ট্যান্ডার্ড Markdown টেবিল ছক (যেমন | কলাম ১ | কলাম ২ |) ব্যবহার করে নিখুঁতভাবে সমাধান সাজিয়ে দেবেন।
                    """.trimIndent()
                }
                else -> { // বাংলা পণ্ডিত
                    if (category == "Job Seeker") {
                        """
                            আপনি প্রাজ্ঞ বাংলা ব্যাকরণ ও বাংলা সাহিত্যের ইতিহাস শিক্ষক "বাংলা পণ্ডিত"।
                            রুলস:
                            - BCS ও অন্যান্য চাকরি পরীক্ষার প্রিলিমিনারি ও লিখিত উভয় সিলেবাসের উপর জোর দিয়ে কঠিন বানান শুদ্ধি, সমাস, সন্ধি ও সাহিত্যিকদের গুরুত্বপূর্ণ তথ্য চমৎকারভাবে বাংলায় ব্যাখ্যা করুন।
                            - উত্তর শেষে ১টি BCS মক প্রশ্ন ছুড়ে দিন।
                        """.trimIndent()
                    } else {
                        """
                            আপনি স্নেহশীল "বাংলা পণ্ডিত", বাংলা ব্যাকরণ ও বিষয়ের একজন জ্ঞানপিপাসু ও আন্তরিক শিক্ষক।
                            রুলস:
                            - শিক্ষার্থীদের জটিল ব্যাকরণ কনসেপ্ট (যেমন সমাস, সন্ধি, কারক-বিভক্তি) হাস্যরসাত্মক বাস্তব জীবনের উদাহরণ, তুলনা কার্ড ও ছন্দভিত্তিক "Mnemonics" (মনে রাখার চমৎকার ছন্দ) দিয়ে হাসিমুখে উপস্থাপন করুন।
                            - শেষে কথোপকথন চালিয়ে রাখতে ১টি অত্যন্ত কৌতুরহোদ্দীপক প্রশ্ন করুন।
                        """.trimIndent()
                    }
                }
            }

            // Let's bundle previous chat messages as context for Gemini
            val previousTurns = _tutorMessages.value.takeLast(6).map { msg ->
                "Sender: ${msg.sender}, Message: ${msg.text}"
            }.joinToString("\n")

            val finalPrompt = "ব্যকগ্রাউন্ড কথোপকথন ইতিহাস:\n$previousTurns\n\nনতুন মেসেজ: $text"

            val request = GenerateContentRequest(
                contents = listOf(Content(parts = listOf(Part(text = finalPrompt)))),
                systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
                generationConfig = GenerationConfig(temperature = 0.6f)
            )

            try {
                val response = callGeminiWithFallback(request)
                val textResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                if (textResponse != null) {
                    val updatedList = _tutorMessages.value.toMutableList()
                    updatedList.add(ChatMessage("AI", textResponse))
                    _tutorMessages.value = updatedList

                    // Optionally save tutor chat sessions to history (one-time or snapshot)
                    repository.insertRecord(
                        StudyRecord(
                            type = "ASSISTANT",
                            inputQuery = "[$tutor]: $text",
                            outputResult = textResponse,
                            additionalInfo = "টিউটর কথোপকথন"
                        )
                    )
                } else {
                    _tutorError.value = "টিউটর প্রসেসর সাড়া দেয়নি।"
                }
            } catch (e: Exception) {
                _tutorError.value = getErrorMessage(e)
            } finally {
                _isTutorLoading.value = false
            }
        }
    }

    // --- Legacy / Double Translate Methods (Translation Tab handles translation card) ---
    fun solveAssistantQuery() {
        val query = _assistantInput.value.trim()
        if (query.isEmpty()) return

        if (!isApiKeyConfigured) {
            _assistantError.value = "Gemini API কী কনফিগার করা নেই! দয়া করে AI Studio-এর Secrets প্যানেল থেকে GEMINI_API_KEY যোগ করুন।"
            return
        }

        viewModelScope.launch {
            _isAssistantLoading.value = true
            _assistantError.value = null
            _assistantResponse.value = ""

            val template = _selectedTemplate.value
            val systemPrompt = when (template) {
                "গণিত সমাধান" -> """
                    আপনি একজন অত্যন্ত অভিজ্ঞ গণিত, বিজ্ঞান এবং হিসাববিজ্ঞান শিক্ষক এবং সমাধানকারী। 
                    ব্যবহারকারীর সমস্যাটির ধাপে ধাপে বিস্তারিত সমাধান বাংলায় দিন। 
                    প্রতিটি ধাপ সুন্দর করে ব্যাখ্যা করুন যেন শিক্ষার্থীরা সহজে বুঝতে পারে। 
                    
                    বিঃদ্রঃ (MANDATORY MATH & FORMATTING RULES): 
                    - সব উত্তর বিশুদ্ধ বাংলায় দেবেন।
                    - সব গাণিতিক সমাধান, সমীকরণ, সূত্র, বীজগণিত বা ক্যালকুলেশন নিখুঁতভাবে দেখাতে অবশ্যই স্ট্যান্ডার্ড LaTeX সিনট্যাক্স ব্যবহার করুন (যেমন inline math-এর জন্য $ এবং display block math-এর জন্য $$...$$)। যেমন: \frac{a}{b}, x^2, \sqrt{y}, \pm, \theta ইত্যাদি।
                    
                    [MANDATORY MATH STYLE & NCTB GUIDELINES]:
                    1. বাংলাদেশের SSC, HSC, এবং NTRCA পরীক্ষার পাঠ্যবই (NCTB সিলেবাস) অনুসরণে স্ট্যান্ডার্ড লেআউটে অত্যন্ত বিশদ ও সুন্দরভাবে ধাপে ধাপে বুঝিয়ে সমাধান করবেন।
                    2. গণিত সমাধান করার সময় প্রতিটি গাণিতিক লাইনে '\implies' বা '\Rightarrow' বা '\quad \text{অথবা}' বা '\quad \text{বা}' বা '\text' ইত্যাদি র কোড কখনো ব্যবহার করবেন না। এগুলো সম্পূর্ণরূপে নিষিদ্ধ।
                    3. লাইনের শুরুতে বা সমীকরণের পরবর্তী ধাপে যাওয়ার জন্য LaTeX এর ভিতরে বা বাইরে বাংলায় "বা," বা "অথবা," শব্দ ব্যবহার করবেন। যেমন:
                       $$2x + 3 = 7$$
                       বা, $$2x = 7 - 3$$
                       বা, $$2x = 4$$
                       বা, $$x = \frac{4}{2}$$
                       সুতরাং, $$x = 2$$
                       এভাবে সুন্দরভাবে লাইনের প্রথমে বাংলা "বা," বা "সুতরাং," বা "অথবা," লিখে নতুন লাইন দিয়ে সমাধান সাজিয়ে দেবেন। সমীকরণের মাঝে বা শেষে কখনো 'implies' ব্যবহার করবেন না।
                    4. প্রশ্নের সমাধান শুরুর সময় 'দেওয়া আছে:' (Given:), 'ধরি:' (Let:), 'আমরা জানি:' (We know:), এবং শেষ করার সময় 'সুতরাং, নির্ণেয় সমাধান:' (Therefore, the required solution is:) ইত্যাদি সুন্দর বাংলা পরিভাষা ব্যবহার করুন।
                    
                    - হিসাববিজ্ঞান (Accounting), ফিন্যান্স (Finance) বা যেকোনো কমার্স বিষয়ের লেনদেনের প্রভাব (যেমন: A = L + OE এর প্রভাব ছক), জাবেদা, খতিয়ান, বিবরণী বা যেকোনো তুলনামূলক তথ্যের ক্ষেত্রে নিখুঁতভাবে উপস্থাপনের জন্য অবশ্যই স্ট্যান্ডার্ড Markdown টেবিল ছক (যেমন | বিবরণ | পরিমাণ |) ব্যবহার করবেন।
                """.trimIndent()
                "বাংলা ব্যাকরণ" -> """
                    আপনি একজন চমৎকার বাংলা ভাষার শিক্ষক এবং ব্যাকরণ বিশারদ। 
                    ব্যবহারকারীর বাংলা বাক্য বা শব্দের ব্যাকরণগত ভুল সংশোধন করুন 
                    এবং সুন্দর করে ব্যাখ্যা দিন। কোনো বাগধারা, সন্ধি বা সমাজ ব্যাখ্যা করতে বললে বিস্তারিত ব্যাখ্যা করুন।
                """.trimIndent()
                "ইংরেজি লার্নিং" -> """
                    আপনি একজন দক্ষ ইংরেজি শিক্ষক। 
                    ব্যবহারকারীকে ইংরেজি গ্রামার, ট্রান্সলেশন স্ট্রাকচার, নতুন শব্দের ভোকাবुलারি বা কথোপকথনের নিয়ম বাংলায় হাসিমুখে শিখিয়ে দিন। 
                    প্রয়োজনীয় উদাহরণ সহ ধাপে ধাপে আলোচনা করুন।
                """.trimIndent()
                "কোড সাহায্যকারী" -> """
                    আপনি একজন প্রফেশনাল সফটওয়্যার ইঞ্জিনিয়ার ও টেকনিক্যাল ইন্সট্রাক্টর। 
                    ব্যবহারকারীর কোডের সমস্যা নিরসন বা কোডিং কনসেপ্ট সহজ উপায়ে বাংলায় ব্যাখ্যা করুন। 
                    কোড সহ সমাধান দেখান এবং প্রতি লাইনের কার্যকারিতা বাংলায় বুঝিয়ে দিন।
                """.trimIndent()
                "বিজ্ঞান ব্যাখ্যা" -> """
                    আপনি একজন বিজ্ঞান বিশেষজ্ঞ এবং বিশ্বকোষ। 
                    পদার্থবিজ্ঞান, রসায়ন, জীববিজ্ঞান বা সাধারণ বিজ্ঞান সংক্রান্ত যে কোনো প্রশ্নের 
                    উত্তর সহজ, বাস্তব সম্মত উদাহরণ এবং সায়েন্টিফিক ট্রুথের মাধ্যমে বাংলায় বুঝিয়ে দিন।
                """.trimIndent()
                "অনুচ্ছেদ সংক্ষেপ" -> """
                    আপনি একজন দ্রুত সারাংশ লেখক। 
                    ব্যবহারকারী যে দীর্ঘ তথ্য বা অনুচ্ছেদটি দেবে, তার মূল সারমর্ম এবং গুরুত্ত্বপূর্ণ 
                    পয়েন্টগুলো পয়েন্ট আকারে অত্যন্ত সহজ ও সাবলীল বাংলায় সংক্ষেপ করে দিন।
                """.trimIndent()
                else -> """
                    আপনি একজন বন্ধুত্বপূর্ণ এআই একাডেমি সহকারী যার নাম 'Nerd AI Bangla Special'। 
                    আপনার মূল লক্ষ্য শিক্ষার্থীদের সাহায্য করা। সর্বদা অত্যন্ত সহজ বাংলা ভাষায় বিস্তারিত এবং শিক্ষণীয়ভাবে উত্তর দিন। 
                    প্রয়োজনে বুলেট পয়েন্ট এবং বোল্ড টেক্সট ব্যবহার করে উত্তর সাজিয়ে তুলুন।
                """.trimIndent()
            }

            val request = GenerateContentRequest(
                contents = listOf(Content(parts = listOf(Part(text = query)))),
                systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
                generationConfig = GenerationConfig(temperature = 0.4f)
            )

            try {
                val response = callGeminiWithFallback(request)
                val textResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                
                if (textResponse != null) {
                    _assistantResponse.value = textResponse
                    
                    repository.insertRecord(
                        StudyRecord(
                            type = "ASSISTANT",
                            inputQuery = query,
                            outputResult = textResponse,
                            additionalInfo = template
                        )
                    )
                } else {
                    _assistantError.value = "সার্ভার থেকে কোনো টেক্সট উত্তর পাওয়া যায়নি।"
                }
            } catch (e: Exception) {
                _assistantError.value = getErrorMessage(e)
            } finally {
                _isAssistantLoading.value = false
            }
        }
    }

    fun translateText() {
        val text = _translationInput.value.trim()
        if (text.isEmpty()) return

        if (!isApiKeyConfigured) {
            _translationError.value = "Gemini API কী কনফিগার করা নেই! Secrets প্যানেল থেকে কী যোগ করুন।"
            return
        }

        viewModelScope.launch {
            _isTranslationLoading.value = true
            _translationError.value = null
            _translationResponse.value = ""

            val src = if (_isEnglishToBangla.value) "English" else "Bengali"
            val dest = if (_isEnglishToBangla.value) "Bengali" else "English"

            val systemPrompt = """
                You are a professional academic translator specializing in $src to $dest translation.
                Translate the input text provided by the user accurately and naturally while maintaining the educational/contextual context.
                Do NOT add any welcoming greetings.
                At the end of your translation, if there are any specific advanced academic or structural words, list them under an optional brief "শব্দার্থ ও ব্যাখ্যা (Vocabulary Info)" section in Bengali to help students learn.
            """.trimIndent()

            val request = GenerateContentRequest(
                contents = listOf(Content(parts = listOf(Part(text = text)))),
                systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
                generationConfig = GenerationConfig(temperature = 0.3f)
            )

            try {
                val response = callGeminiWithFallback(request)
                val textResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                
                if (textResponse != null) {
                    _translationResponse.value = textResponse
                    
                    repository.insertRecord(
                        StudyRecord(
                            type = "TRANSLATION",
                            inputQuery = text,
                            outputResult = textResponse,
                            additionalInfo = if (_isEnglishToBangla.value) "EN ➔ BN" else "BN ➔ EN"
                        )
                    )
                } else {
                    _translationError.value = "অনুবাদ করা সম্ভব হয়নি।"
                }
            } catch (e: Exception) {
                _translationError.value = getErrorMessage(e)
            } finally {
                _isTranslationLoading.value = false
            }
        }
    }

    // --- Clean DB management ---
    fun toggleBookmark(id: Int, isBookmarked: Boolean) {
        viewModelScope.launch {
            repository.updateBookmark(id, isBookmarked)
        }
    }

    fun deleteRecord(id: Int) {
        viewModelScope.launch {
            repository.deleteRecordById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllRecords()
        }
    }

    fun clearHistoryByType(type: String) {
        viewModelScope.launch {
            repository.clearRecordsByType(type)
        }
    }

    private suspend fun callGeminiWithFallback(
        request: GenerateContentRequest,
        primaryModel: String = "gemini-3.5-flash",
        fallbackModel: String = "gemini-2.5-flash"
    ): com.example.api.GenerateContentResponse {
        val apiKey = BuildConfig.GEMINI_API_KEY
        return try {
            RetrofitClient.service.generateContent(primaryModel, apiKey, request)
        } catch (e: retrofit2.HttpException) {
            val code = e.code()
            val errorBody = e.response()?.errorBody()?.string() ?: ""
            android.util.Log.e("NerdAIFallback", "Primary model $primaryModel failed with code $code. Error: $errorBody")
            
            // If the model is not found, or bad request, try fallback
            if (code == 404 || code == 400 || errorBody.contains("not found", ignoreCase = true) || errorBody.contains("model", ignoreCase = true)) {
                android.util.Log.i("NerdAIFallback", "Retrying with fallback model $fallbackModel...")
                try {
                    RetrofitClient.service.generateContent(fallbackModel, apiKey, request)
                } catch (e2: Exception) {
                    throw e2
                }
            } else {
                throw e
            }
        }
    }

    private fun getErrorMessage(e: Exception): String {
        return if (e is retrofit2.HttpException) {
            val errorBody = e.response()?.errorBody()?.string() ?: ""
            android.util.Log.e("NerdAIAPI", "HTTP Error ${e.code()}: $errorBody")
            val cleanMsg = if (errorBody.contains("API_KEY_INVALID") || errorBody.contains("API key not valid", ignoreCase = true)) {
                "সঠিক API কী (API key) দেওয়া হয়নি। AI Studio Secrets প্যানেলে GEMINI_API_KEY বসাতে হবে।"
            } else if (errorBody.contains("not found", ignoreCase = true) || errorBody.contains("model", ignoreCase = true)) {
                "মডেল বা API এন্ডপয়েন্ট খুঁজে পাওয়া যায়নি। অনুগ্রহ করে ডেভেলপার সেটিংস চেক করুন।"
            } else if (errorBody.contains("quota", ignoreCase = true) || errorBody.contains("limit", ignoreCase = true)) {
                "রিকুয়েস্ট লিমিট বা কোটা অতিক্রম হয়েছে। অনুগ্রহ করে একটু পর আবার চেষ্টা করুন।"
            } else {
                if (errorBody.contains("\"message\"")) {
                    errorBody.substringAfter("\"message\": \"").substringBefore("\"").trim()
                } else {
                    errorBody.take(150)
                }
            }
            "সার্ভার ত্রুটি (${e.code()}): ${cleanMsg.ifEmpty { e.localizedMessage }}"
        } else {
            e.localizedMessage ?: "নেটওয়ার্ক কানেকশন ও সার্ভার ত্রুটি!"
        }
    }
}

class NerdAIViewModelFactory(private val repository: StudyRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NerdAIViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return NerdAIViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

data class ScanSpot(
    val title: String,
    val description: String,
    val icon: String,
    val presetQuery: String
)

fun getScanSpotsForCategory(category: String): List<ScanSpot> {
    return when (category) {
        "SSC" -> listOf(
            ScanSpot(
                title = "সাধারণ গণিত",
                description = "বাস্তব সংখ্যা, সেট ও ফাংশন, বীজগাণিতিক রাশি, সূচক ও লগারিদম, জ্যামিতি, ত্রিকোণমিতি, পরিমিতি এবং পরিসংখ্যানসহ পাঠ্যবইয়ের মোট ১৭টি অধ্যায়ের যেকোনো প্রশ্ন।",
                icon = "📐",
                presetQuery = "x^2 + 5x + 6 = 0 গাণিতিক সমীকরণটির বাস্তব সমাধান ও ব্যাখ্যা ধাপে ধাপে দিন।"
            ),
            ScanSpot(
                title = "উচ্চতর গণিত",
                description = "সেট ও ফাংশন, বীজগাণিতিক রাশি, জ্যামিতি, অসমতা, অসীম ধারা, ত্রিকোণমিতি, সূচকীয় ও লগারিদমীয় ফাংশন, দ্বিপদী বিস্তৃতি, স্থানাঙ্ক জ্যামিতি, ভেক্টর ও সম্ভাবনাসহ সব অধ্যায়।",
                icon = "📈",
                presetQuery = "দ্বিপদী বিস্তৃতি ব্যবহার করে (1 + x)^5 এর বিস্তৃতি করুন ও ৩য় পদের সহগ বের করুন।"
            ),
            ScanSpot(
                title = "পদার্থবিজ্ঞান ও রসায়ন",
                description = "পদার্থবিজ্ঞানের (গতি, বল, কাজ-ক্ষমতা-শক্তি, পদার্থের অবস্থা, তরঙ্গ ও শব্দ, আলোর প্রতিফলন-প্রতিসরণ, স্থির ও চলতড়িৎ) এবং রসায়নের (পদার্থের গঠন, পর্যায় সারণি, রাসায়নিক বন্ধন, মোলের ধারণা, রাসায়নিক বিক্রিয়া, এসিড-ক্ষার সমতা, খনিজ সম্পদ) সব চ্যাপ্টারের গাণিতিক ও সৃজনশীল সমাধান।",
                icon = "⚛️",
                presetQuery = "একটি ৫ কেজি ভরের বস্তুকে ১০ মি./সে. বেগে উপরে ছুঁড়লে সর্বোচ্চ কত উচ্চতায় উঠবে এবং এতে কৃতকাজ কত?"
            ),
            ScanSpot(
                title = "হিসাববিজ্ঞান, ফিন্যান্স ও ব্যাংকিং",
                description = "হিসাববিজ্ঞানের (লেনদেন, দুতরফা দাখিলা, জাবেদা, খতিয়ান, রেউমিল, আর্থিক বিবরণী) এবং ফিন্যান্সের (অর্থের সময়মূল্য, ঝুঁকি ও অনিশ্চয়তা, মূলধনী আয়-ব্যয় প্রাক্কলন, মূলধন খরচ, ব্যাংকিং ব্যবসায় ও ধরণ) সম্পূর্ণ বইয়ের সব ম্যাথ ও থিওরি।",
                icon = "💼",
                presetQuery = "১০% সরল সুদে ৫,০০০ টাকার ৫ বছরের সুদাসল কত হবে তা হিসাববিজ্ঞানের নিয়মে বুঝিয়ে দিন।"
            ),
            ScanSpot(
                title = "English Grammar",
                description = "Parts of Speech, Tense, Voice, Narration, Right form of verbs, Transformation of Sentences, Tag Question, Completing Sentence সহ সব গ্রামার আইটেম।",
                icon = "📝",
                presetQuery = "Complete the sentence with appropriate words: 'No sooner had we reached the station...'"
            ),
            ScanSpot(
                title = "অন্যান্য বিষয় / Others",
                description = "বাংলাদেশ ও বিশ্বপরিচয়, আইসিটি, বিজ্ঞান, ইতিহাস, ভূগোল, পৌরনীতি বা যেকোনো সাধারণ বিষয় এর যেকোনো চ্যাপ্টারের থিওরি বা কুইজ সমাধান।",
                icon = "🌍",
                presetQuery = "বাংলাদেশের নদীমাতৃক ভৌগোলিক পরিবেশ আমাদের অর্থনীতিতে কী প্রভাব ফেলে তা ব্যাখ্যা করুন।"
            )
        )
        "HSC" -> listOf(
            ScanSpot(
                title = "উচ্চতর গণিত (১ম ও ২য় পত্র)",
                description = "ম্যাট্রিক্স ও ডিটারমিন্যান্ট, ভেক্টর, সরলরেখা, বৃত্ত, ত্রিকোণমিতি, ডিফারেনশিয়েশন, ইন্টিগ্রেশন, জটিল সংখ্যা, বহুপদী, কনিক্স, স্থিতিবিদ্যা ও গতিবিদ্যার সব চ্যাপ্টার।",
                icon = "📈",
                presetQuery = "ইন্টিগ্রেশন ∫(3x^2 + 2x) dx এর অনির্দিষ্ট মান নির্ণয় করো এবং সূত্র ব্যাখ্যা করো।"
            ),
            ScanSpot(
                title = "পদার্থবিজ্ঞান ১ম ও ২য় পত্র",
                description = "ভেক্টর, গতিবিদ্যা, நியூটনীয় বলবিদ্যা, কাজ-শক্তি-ক্ষমতা, মহাকর্ষ, পর্যায়বৃত্ত গতি, আদর্শ গ্যাস, তাপগতিবিদ্যা, স্থির তড়িৎ, চল তড়িৎ, জ্যামিতিক আলোকবিজ্ঞান এবং আধুনিক পদার্থবিজ্ঞানের সব ম্যাথ।",
                icon = "⚡",
                presetQuery = "একটি তড়িৎ কুণ্ডলীতে ৫ অ্যাম্পিয়ার তড়িৎ প্রবাহিত হলে এর মধ্যকার সৃষ্ট চৌম্বক ক্ষেত্রের মান বের করার তড়িৎ গতিবিদ্যার সূত্র ও সমাধান বলুন।"
            ),
            ScanSpot(
                title = "রসায়ন ১ম ও ২য় পত্র",
                description = "गुणগত রসায়ন, পর্যায়বৃত্ত ধর্ম, রাসায়নিক পরিবর্তন, কর্মমুখী রসায়ন, পরিবেশ রসায়ন, জৈব রসায়ন (Organic Chemistry), পরিমাণগত রসায়ন ও তড়িৎ রসায়নের সব বিক্রিয়া ও গাণিতিক সূত্র।",
                icon = "🧪",
                presetQuery = "ইথানিল ও অম্লের উপস্থিতিতে জৈব এসিডের সংশ্লেষণ বিক্রিয়া (Esters reaction) বুঝিয়ে দিন।"
            ),
            ScanSpot(
                title = "হিসাববিজ্ঞান ও ফিন্যান্স",
                description = "দৃশ্যমান ও অদৃশ্যমান সম্পদের হিসাবরক্ষণ, অংশীদারি কারবার, যৌথ মূলধনী কোম্পানির মূলধন, আর্থিক বিবরণী, উৎপাদন ব্যয় হিসাব এবং ফিন্যান্সের দীর্ঘমেয়াদি অর্থায়ন ও ক্যাপিটাল বাজেটিংয়ের সব ম্যাথ।",
                icon = "📊",
                presetQuery = "যৌথ মূলধনী কোম্পানির শেয়ার ইস্যুর ক্ষেত্রে অধিহার ও অবহার সংক্রান্ত হিসাব কিতাব জাবেদাসহ বুঝিয়ে বলুন।"
            ),
            ScanSpot(
                title = "ICT (তথ্য ও যোগাযোগ প্রযুক্তি)",
                description = "বিশ্ব ও বাংলাদেশ প্রেক্ষিত, কমিউনিকেশন সিস্টেমস ও নেটওয়ার্কিং, সংখ্যা পদ্ধতি ও ডিজিটাল ডিভাইস, HTML ও ওয়েব ডিজাইন, সি-প্রোগ্রামিং (C) এবং ডাটাবেজ ম্যানেজমেন্ট সিস্টেমের সব চ্যাপ্টার।",
                icon = "💻",
                presetQuery = "HTML-এ একটি টেবিল তৈরি করে যার মধ্যে ৩টি রো এবং ২টি কলাম থাকবে এর কোড ও আউটপুট কেমন হবে?"
            ),
            ScanSpot(
                title = "অন্যান্য বিষয় / Others",
                description = "বাংলা সাহিত্য, ইংরেজি ১ম ও ২য় পত্র, অর্থনীতি, পৌরনীতি, ইতিহাস ও যুক্তিশাস্ত্রের সব চ্যাপ্টারের প্রশ্ন বা থিওরি।",
                icon = "📚",
                presetQuery = "মাইকেল মধুসূদন দত্তের বিখ্যাত মেঘনাদবধ কাব্যের প্রথম সর্গের নামকরণের পেছনে মূল ভাবনা সংক্ষেপে আলোচনা করো।"
            )
        )
        else -> listOf( // "Job Seeker"
            ScanSpot(
                title = "প্রিলি গণিত ও মানসিক দক্ষতা",
                description = "পাটিগণিত (বাস্তব সংখ্যা, লসাগু-গসাগু, শতকরা, লাভ-ক্ষতি, সুদকষা, অনুপাত, ঐকিক নিয়ম), বীজগণিত (উৎপাদক, সূচক-লগারিদম, ধারা, সমীকরণ, অসমতা), জ্যামিতি, স্থানাঙ্ক জ্যামিতি, বিন্যাস-সমাবেশ, উপাত্ত বিন্যাস্তকরণ ও মানসিক দক্ষতার সব ট্রিকস।",
                icon = "🎯",
                presetQuery = "চিনির মূল্য ২০% বৃদ্ধি পেলে চিনির ব্যবহার শতকরা কত কমালে খরচের কোনো পরিবর্তন হবে না? শর্টকাট পদ্ধতিতে করুন।"
            ),
            ScanSpot(
                title = "বাংলাদেশ ও আন্তর্জাতিক বিষয়াবলী (GK)",
                description = "প্রাচীনকাল থেকে বর্তমান বাংলাদেশের ইতিহাস, মুক্তিযুদ্ধ, ভৌগোলিক অবস্থান, অর্থনীতি, সংবিধান, রাজনৈতিক ব্যবস্থা, বৈশ্বিক ইতিহাস, আন্তর্জাতিক সংস্থা, চুক্তি, সাম্প্রতিক বিশ্ব এবং সমসাময়িক ঘটনাপ্রবাহের সব টপিক।",
                icon = "🌐",
                presetQuery = "১৭৮৯ সালের ফরাসি বিপ্লবের মূল স্লোগান কী ছিল এবং এর ফলে ইউরোপের রাজনীতিতে কী প্রতিক্রিয়া হয়েছিল?"
            ),
            ScanSpot(
                title = "ইংরেজি সাহিত্য ও ব্যাকরণ",
                description = "English Literature ( Elizabethan, Romantic, Victorian, Modern periods এর কবি ও তাদের উক্তি) এবং English Language (Noun, Pronoun, Verb, Adverb, Adjective, Preposition, Idioms & Phrases, Synonyms, Antonyms, Clause) এর সব নিয়ম।",
                icon = "🇬🇧",
                presetQuery = "Who is the author of 'To Autumn'? Which literary period does this poem belong to? Briefly describe."
            ),
            ScanSpot(
                title = "বাংলা ভাষা ও সাহিত্য",
                description = "বাংলা সাহিত্যের প্রাচীন যুগ (চর্যাপদ), মধ্য যুগ (মঙ্গলকাব্য, বৈষ্ণব পদাবলী, আরাকান রাজসভা) এবং আধুনিক যুগের সব কবি-সাহিত্যিক (রবীন্দ্রনাথ, নজরুল, বঙ্কিম, শরৎচন্দ্র ইত্যাদি) এবং বাংলা ব্যাকরণ (ধ্বনি, বর্ণ, সন্ধি, সমাস, কারক, প্রত্যয়, সমার্থক ও বিপরীত শব্দ)।",
                icon = "✍️",
                presetQuery = "চর্যাপদের মোট পদ সংখ্যা কতটি? নেপালে মহামহোপাধ্যায় হরপ্রসাদ শাস্ত্রী এটি কখন আবিষ্কার করেন?"
            ),
            ScanSpot(
                title = "দৈনন্দিন বিজ্ঞান ও কম্পিউটার",
                description = "ভৌত বিজ্ঞান, জীববিজ্ঞান, আধুনিক বিজ্ঞান, কম্পিউটারের অঙ্গসংগঠন, নেটওয়ার্কিং, ইন্টারনেট, সাইবার নিরাপত্তা এবং তথ্যপ্রযুক্তির সম্পূর্ণ সিলেবাস।",
                icon = "🧬",
                presetQuery = "কম্পিউটারের প্রসেসরের কাজের গতি পরিমাপের একক কী এবং ইন্টারনেটের ডেটা ট্রান্সমিশন ব্যান্ডউইথ কীভাবে কাজ করে?"
            )
        )
    }
}
