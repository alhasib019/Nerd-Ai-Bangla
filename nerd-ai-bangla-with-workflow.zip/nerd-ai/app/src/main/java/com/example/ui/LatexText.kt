package com.example.ui
 
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed class TextSegment {
    data class PlainText(val text: String, val isBold: Boolean = false, val isItalic: Boolean = false) : TextSegment()
    data class InlineMath(val expression: String) : TextSegment()
    data class BlockMath(val expression: String) : TextSegment()
}

sealed class MathNode {
    data class Text(val text: String, val italic: Boolean = true) : MathNode()
    data class Fraction(val numerator: MathNode, val denominator: MathNode) : MathNode()
    data class Power(val base: MathNode, val exponent: MathNode) : MathNode()
    data class Subscript(val base: MathNode, val subscript: MathNode) : MathNode()
    data class Sequence(val nodes: List<MathNode>) : MathNode()
}

fun parseTextSegments(text: String): List<TextSegment> {
    val segments = mutableListOf<TextSegment>()
    var currentIndex = 0
    val length = text.length

    while (currentIndex < length) {
        val nextBlockStart = text.indexOf("$$", currentIndex)
        val nextInlineStart = text.indexOf("$", currentIndex)

        if (nextBlockStart != -1 && (nextInlineStart == -1 || nextBlockStart <= nextInlineStart)) {
            // Found block math
            if (nextBlockStart > currentIndex) {
                segments.add(TextSegment.PlainText(text.substring(currentIndex, nextBlockStart)))
            }
            val blockEnd = text.indexOf("$$", nextBlockStart + 2)
            if (blockEnd != -1) {
                val expr = text.substring(nextBlockStart + 2, blockEnd)
                segments.add(TextSegment.BlockMath(expr))
                currentIndex = blockEnd + 2
            } else {
                segments.add(TextSegment.PlainText(text.substring(nextBlockStart)))
                currentIndex = length
            }
        } else if (nextInlineStart != -1) {
            // Found inline math
            if (nextInlineStart > currentIndex) {
                segments.add(TextSegment.PlainText(text.substring(currentIndex, nextInlineStart)))
            }
            val inlineEnd = text.indexOf("$", nextInlineStart + 1)
            if (inlineEnd != -1) {
                val expr = text.substring(nextInlineStart + 1, inlineEnd)
                segments.add(TextSegment.InlineMath(expr))
                currentIndex = inlineEnd + 1
            } else {
                segments.add(TextSegment.PlainText(text.substring(nextInlineStart)))
                currentIndex = length
            }
        } else {
            segments.add(TextSegment.PlainText(text.substring(currentIndex)))
            currentIndex = length
        }
    }
    return segments
}

fun parseMarkdownFormatting(text: String): List<TextSegment> {
    val result = mutableListOf<TextSegment>()
    var i = 0
    val len = text.length
    var current = java.lang.StringBuilder()
    var isBold = false
    var isItalic = false

    while (i < len) {
        if (text.startsWith("**", i)) {
            if (current.isNotEmpty()) {
                result.add(TextSegment.PlainText(current.toString(), isBold = isBold, isItalic = isItalic))
                current = java.lang.StringBuilder()
            }
            isBold = !isBold
            i += 2
        } else if (text.startsWith("__", i)) {
            if (current.isNotEmpty()) {
                result.add(TextSegment.PlainText(current.toString(), isBold = isBold, isItalic = isItalic))
                current = java.lang.StringBuilder()
            }
            isBold = !isBold
            i += 2
        } else if (text[i] == '*' && (i + 1 == len || text[i + 1] != '*')) {
            if (current.isNotEmpty()) {
                result.add(TextSegment.PlainText(current.toString(), isBold = isBold, isItalic = isItalic))
                current = java.lang.StringBuilder()
            }
            isItalic = !isItalic
            i += 1
        } else if (text[i] == '_' && (i + 1 == len || text[i + 1] != '_')) {
            if (current.isNotEmpty()) {
                result.add(TextSegment.PlainText(current.toString(), isBold = isBold, isItalic = isItalic))
                current = java.lang.StringBuilder()
            }
            isItalic = !isItalic
            i += 1
        } else {
            current.append(text[i])
            i++
        }
    }
    if (current.isNotEmpty()) {
        result.add(TextSegment.PlainText(current.toString(), isBold = isBold, isItalic = isItalic))
    }
    return result
}

fun parseRichTextSegments(text: String): List<TextSegment> {
    val rawSegments = parseTextSegments(text)
    val richSegments = mutableListOf<TextSegment>()

    for (seg in rawSegments) {
        if (seg is TextSegment.PlainText) {
            richSegments.addAll(parseMarkdownFormatting(seg.text))
        } else {
            richSegments.add(seg)
        }
    }
    return richSegments
}

fun parseMathExpression(input: String): MathNode {
    val trimmed = input.trim()
    if (trimmed.isEmpty()) return MathNode.Text("")

    val nodes = mutableListOf<MathNode>()
    var i = 0
    val len = trimmed.length

    while (i < len) {
        val char = trimmed[i]

        if (trimmed.startsWith("\\frac", i)) {
            val numStart = trimmed.indexOf('{', i + 5)
            if (numStart != -1) {
                val numEnd = findMatchingBrace(trimmed, numStart)
                if (numEnd != -1) {
                    val numeratorStr = trimmed.substring(numStart + 1, numEnd)
                    val denomStart = trimmed.indexOf('{', numEnd + 1)
                    if (denomStart != -1) {
                        val denomEnd = findMatchingBrace(trimmed, denomStart)
                        if (denomEnd != -1) {
                            val denominatorStr = trimmed.substring(denomStart + 1, denomEnd)
                            
                            val numNode = parseMathExpression(numeratorStr)
                            val denomNode = parseMathExpression(denominatorStr)
                            
                            nodes.add(MathNode.Fraction(numNode, denomNode))
                            i = denomEnd + 1
                            continue
                        }
                    }
                }
            }
            nodes.add(MathNode.Text("\\frac", italic = false))
            i += 5
        } else if (char == '^') {
            val baseNode = if (nodes.isNotEmpty()) nodes.removeAt(nodes.size - 1) else MathNode.Text("")
            i++
            if (i < len) {
                if (trimmed[i] == '{') {
                    val expEnd = findMatchingBrace(trimmed, i)
                    if (expEnd != -1) {
                        val exponentStr = trimmed.substring(i + 1, expEnd)
                        val expNode = parseMathExpression(exponentStr)
                        nodes.add(MathNode.Power(baseNode, expNode))
                        i = expEnd + 1
                    } else {
                        nodes.add(MathNode.Text("^", italic = false))
                    }
                } else {
                    val expNode = parseMathExpression(trimmed[i].toString())
                    nodes.add(MathNode.Power(baseNode, expNode))
                    i++
                }
            } else {
                nodes.add(MathNode.Text("^", italic = false))
            }
        } else if (char == '_') {
            val baseNode = if (nodes.isNotEmpty()) nodes.removeAt(nodes.size - 1) else MathNode.Text("")
            i++
            if (i < len) {
                if (trimmed[i] == '{') {
                    val subEnd = findMatchingBrace(trimmed, i)
                    if (subEnd != -1) {
                        val subStr = trimmed.substring(i + 1, subEnd)
                        val subNode = parseMathExpression(subStr)
                        nodes.add(MathNode.Subscript(baseNode, subNode))
                        i = subEnd + 1
                    } else {
                        nodes.add(MathNode.Text("_", italic = false))
                    }
                } else {
                    val subNode = parseMathExpression(trimmed[i].toString())
                    nodes.add(MathNode.Subscript(baseNode, subNode))
                    i++
                }
            } else {
                nodes.add(MathNode.Text("_", italic = false))
            }
        } else if (trimmed.startsWith("\\pi", i)) {
            nodes.add(MathNode.Text("π", italic = true))
            i += 3
        } else if (trimmed.startsWith("\\theta", i)) {
            nodes.add(MathNode.Text("θ", italic = true))
            i += 6
        } else if (trimmed.startsWith("\\alpha", i)) {
            nodes.add(MathNode.Text("α", italic = true))
            i += 6
        } else if (trimmed.startsWith("\\beta", i)) {
            nodes.add(MathNode.Text("β", italic = true))
            i += 5
        } else if (trimmed.startsWith("\\gamma", i)) {
            nodes.add(MathNode.Text("γ", italic = true))
            i += 6
        } else if (trimmed.startsWith("\\sqrt", i)) {
            val startBrace = trimmed.indexOf('{', i + 5)
            if (startBrace != -1) {
                val endBrace = findMatchingBrace(trimmed, startBrace)
                if (endBrace != -1) {
                    val innerStr = trimmed.substring(startBrace + 1, endBrace)
                    val innerNode = parseMathExpression(innerStr)
                    nodes.add(MathNode.Sequence(listOf(
                        MathNode.Text("√", italic = false),
                        MathNode.Text("(", italic = false),
                        innerNode,
                        MathNode.Text(")", italic = false)
                    )))
                    i = endBrace + 1
                    continue
                }
            }
            nodes.add(MathNode.Text("√", italic = false))
            i += 5
        } else if (trimmed.startsWith("\\times", i)) {
            nodes.add(MathNode.Text("×", italic = false))
            i += 6
        } else if (trimmed.startsWith("\\div", i)) {
            nodes.add(MathNode.Text("÷", italic = false))
            i += 4
        } else if (trimmed.startsWith("\\pm", i)) {
            nodes.add(MathNode.Text("±", italic = false))
            i += 3
        } else if (trimmed.startsWith("\\implies", i)) {
            nodes.add(MathNode.Text(" ⇒ ", italic = false))
            i += 8
        } else if (trimmed.startsWith("\\Rightarrow", i)) {
            nodes.add(MathNode.Text("⇒", italic = false))
            i += 11
        } else if (trimmed.startsWith("\\therefore", i)) {
            nodes.add(MathNode.Text(" ∴ ", italic = false))
            i += 10
        } else if (trimmed.startsWith("\\because", i)) {
            nodes.add(MathNode.Text(" ∵ ", italic = false))
            i += 8
        } else if (trimmed.startsWith("\\quad", i)) {
            nodes.add(MathNode.Text("  ", italic = false))
            i += 5
        } else if (trimmed.startsWith("\\qquad", i)) {
            nodes.add(MathNode.Text("    ", italic = false))
            i += 6
        } else if (trimmed.startsWith("\\text", i)) {
            val startBrace = trimmed.indexOf('{', i + 5)
            if (startBrace != -1) {
                val endBrace = findMatchingBrace(trimmed, startBrace)
                if (endBrace != -1) {
                    val innerStr = trimmed.substring(startBrace + 1, endBrace)
                    nodes.add(MathNode.Text(innerStr, italic = false))
                    i = endBrace + 1
                    continue
                }
            }
            nodes.add(MathNode.Text("\\text", italic = false))
            i += 5
        } else {
            val nextChar = trimmed[i]
            val isLetter = nextChar.isLetter()
            nodes.add(MathNode.Text(nextChar.toString(), italic = isLetter))
            i++
        }
    }

    return if (nodes.size == 1) nodes[0] else MathNode.Sequence(nodes)
}

fun findMatchingBrace(text: String, startIdx: Int): Int {
    var braceCount = 0
    for (idx in startIdx until text.length) {
        if (text[idx] == '{') braceCount++
        else if (text[idx] == '}') {
            braceCount--
            if (braceCount == 0) {
                return idx
            }
        }
    }
    return -1
}

@Composable
fun RenderMathNode(node: MathNode, modifier: Modifier = Modifier, baseFontSize: TextUnit = 14.sp, color: Color = Color.White) {
    when (node) {
        is MathNode.Text -> {
            Text(
                text = node.text,
                color = color,
                fontSize = baseFontSize,
                fontStyle = if (node.italic) FontStyle.Italic else FontStyle.Normal,
                fontFamily = if (node.italic) FontFamily.Serif else FontFamily.Default,
                modifier = modifier
            )
        }
        is MathNode.Fraction -> {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = modifier.padding(vertical = 4.dp, horizontal = 2.dp)
            ) {
                RenderMathNode(node.numerator, baseFontSize = baseFontSize * 0.85f, color = color)
                Box(
                    modifier = Modifier
                        .widthIn(min = 12.dp)
                        .height(1.5.dp)
                        .background(color.copy(alpha = 0.9f))
                )
                RenderMathNode(node.denominator, baseFontSize = baseFontSize * 0.85f, color = color)
            }
        }
        is MathNode.Power -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = modifier
            ) {
                RenderMathNode(node.base, baseFontSize = baseFontSize, color = color)
                Box(
                    modifier = Modifier.offset(y = (-5).dp)
                ) {
                    RenderMathNode(node.exponent, baseFontSize = baseFontSize * 0.75f, color = color)
                }
            }
        }
        is MathNode.Subscript -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = modifier
            ) {
                RenderMathNode(node.base, baseFontSize = baseFontSize, color = color)
                Box(
                    modifier = Modifier.offset(y = 4.dp)
                ) {
                    RenderMathNode(node.subscript, baseFontSize = baseFontSize * 0.75f, color = color)
                }
            }
        }
        is MathNode.Sequence -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = modifier
            ) {
                node.nodes.forEach { child ->
                    RenderMathNode(child, baseFontSize = baseFontSize, color = color)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ParagraphLayout(segments: List<TextSegment>, baseFontSize: TextUnit = 14.sp, color: Color = Color.White, fontWeight: FontWeight? = null) {
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalArrangement = Arrangement.Center
    ) {
        segments.forEach { segment ->
            when (segment) {
                is TextSegment.PlainText -> {
                    val words = segment.text.split(" ")
                    words.forEachIndexed { index, word ->
                        if (word.isNotEmpty()) {
                            Text(
                                text = word + if (index < words.size - 1) " " else "",
                                fontSize = baseFontSize,
                                color = color,
                                fontWeight = fontWeight ?: if (segment.isBold) FontWeight.Bold else FontWeight.Normal,
                                fontStyle = if (segment.isItalic) FontStyle.Italic else FontStyle.Normal,
                                lineHeight = 20.sp,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        } else if (index < words.size - 1) {
                            Text(
                                text = " ",
                                fontSize = baseFontSize,
                                color = color,
                                fontWeight = fontWeight ?: if (segment.isBold) FontWeight.Bold else FontWeight.Normal,
                                fontStyle = if (segment.isItalic) FontStyle.Italic else FontStyle.Normal,
                                lineHeight = 20.sp,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                }
                is TextSegment.InlineMath -> {
                    val mathNode = parseMathExpression(segment.expression)
                    RenderMathNode(
                        node = mathNode,
                        baseFontSize = baseFontSize,
                        color = color,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
                is TextSegment.BlockMath -> {
                    // Handled as display / block math separately
                }
            }
        }
    }
}

sealed class TextBlock {
    data class Paragraph(val line: String) : TextBlock()
    data class BlockMathExpr(val expression: String) : TextBlock()
    data class TableBlock(val headers: List<String>, val rows: List<List<String>>) : TextBlock()
    data class Header(val level: Int, val text: String) : TextBlock()
    data class ListItem(val isOrdered: Boolean, val indexMarker: String, val text: String) : TextBlock()
    data class CodeBlock(val language: String, val code: String) : TextBlock()
    data class Blockquote(val text: String) : TextBlock()
}

@Composable
fun RenderTable(headers: List<String>, rows: List<List<String>>, baseFontSize: TextUnit, textColor: Color) {
    val colCount = if (headers.isNotEmpty()) headers.size else rows.firstOrNull()?.size ?: 0
    if (colCount == 0) return

    val colMaxLengths = IntArray(colCount) { 2 }
    if (headers.isNotEmpty()) {
        for (c in 0 until minOf(colCount, headers.size)) {
            colMaxLengths[c] = colMaxLengths[c].coerceAtLeast(headers[c].length)
        }
    }
    for (row in rows) {
        for (c in 0 until minOf(colCount, row.size)) {
            colMaxLengths[c] = colMaxLengths[c].coerceAtLeast(row[c].length)
        }
    }

    val totalLength = colMaxLengths.sum().toFloat().coerceAtLeast(1f)
    val colWeights = FloatArray(colCount) { c ->
        (colMaxLengths[c].toFloat() / totalLength).coerceIn(0.12f, 0.75f)
    }
    
    // Normalize weights to sum to 1f
    val sumWeights = colWeights.sum()
    for (c in 0 until colCount) {
        colWeights[c] = colWeights[c] / sumWeights
    }

    val needsScroll = colCount > 3 || totalLength > 25

    val tableContent = @Composable {
        Column(
            modifier = Modifier
                .then(if (needsScroll) Modifier.widthIn(min = maxOf(colCount * 110, 680).dp) else Modifier.fillMaxWidth())
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                .background(Color(0xFF151525).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
        ) {
            // Headers Row
            if (headers.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF2E2E3E), RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        .padding(vertical = 10.dp, horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    headers.forEachIndexed { idx, header ->
                        val weight = colWeights.getOrElse(idx) { 1f / colCount }
                        Box(
                            modifier = Modifier
                                .weight(weight)
                                .padding(horizontal = 4.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            val segments = parseRichTextSegments(header)
                            ParagraphLayout(
                                segments = segments, 
                                baseFontSize = baseFontSize * 0.95f, 
                                color = textColor, 
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                // Border divider
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color.White.copy(alpha = 0.15f))
                )
            }

            // Body Rows
            rows.forEachIndexed { rIdx, row ->
                val isLastRow = rIdx == rows.size - 1
                val rowBg = if (rIdx % 2 == 1) Color.White.copy(alpha = 0.04f) else Color.Transparent
                val rowShape = if (isLastRow && headers.isNotEmpty()) {
                    RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp)
                } else if (headers.isEmpty() && rIdx == 0 && isLastRow) {
                    RoundedCornerShape(8.dp)
                } else if (headers.isEmpty() && rIdx == 0) {
                    RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)
                } else if (isLastRow) {
                    RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp)
                } else {
                    RoundedCornerShape(0.dp)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(rowBg, rowShape)
                        .padding(vertical = 10.dp, horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (c in 0 until colCount) {
                        val weight = colWeights.getOrElse(c) { 1f / colCount }
                        val cellText = row.getOrNull(c) ?: ""
                        Box(
                            modifier = Modifier
                                .weight(weight)
                                .padding(horizontal = 4.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            val segments = parseRichTextSegments(cellText)
                            ParagraphLayout(segments = segments, baseFontSize = baseFontSize * 0.9f, color = textColor)
                        }
                    }
                }

                if (!isLastRow) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(0.5.dp)
                            .background(Color.White.copy(alpha = 0.08f))
                    )
                }
            }
        }
    }

    if (needsScroll) {
        val scrollState = rememberScrollState()
        Column(modifier = Modifier.padding(vertical = 8.dp)) {
            Row(
                modifier = Modifier.padding(bottom = 6.dp, start = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Scroll",
                    tint = Color(0xFF8C52FF),
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "সম্পূর্ণ ছক দেখতে ডানে-বামে স্ক্রোল করুন ➔",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState)
            ) {
                tableContent()
            }
        }
    } else {
        tableContent()
    }
}

fun isListLine(trimmed: String): Boolean {
    if (trimmed.startsWith("- ") || trimmed.startsWith("* ") || trimmed.startsWith("• ")) {
        return true
    }
    val dotIdx = trimmed.indexOf(". ")
    if (dotIdx in 1..4) {
        val numberPart = trimmed.substring(0, dotIdx)
        if (numberPart.all { it.isDigit() }) {
            return true
        }
    }
    return false
}

fun parseListLine(trimmed: String): TextBlock.ListItem {
    if (trimmed.startsWith("- ") || trimmed.startsWith("* ") || trimmed.startsWith("• ")) {
        return TextBlock.ListItem(
            isOrdered = false,
            indexMarker = "•",
            text = trimmed.substring(2).trim()
        )
    }
    val dotIdx = trimmed.indexOf(". ")
    val numberPart = trimmed.substring(0, dotIdx)
    return TextBlock.ListItem(
        isOrdered = true,
        indexMarker = "$numberPart.",
        text = trimmed.substring(dotIdx + 2).trim()
    )
}

@Composable
fun LatexText(text: String, modifier: Modifier = Modifier, baseFontSize: TextUnit = 14.sp, color: Color = Color.White) {
    val rawLines = text.split("\n")
    val blocks = mutableListOf<TextBlock>()
    var i = 0

    while (i < rawLines.size) {
        val line = rawLines[i]
        val trimmed = line.trim()

        if (trimmed.isEmpty()) {
            blocks.add(TextBlock.Paragraph(""))
            i++
        } else if (trimmed.startsWith("```")) {
            val language = trimmed.removePrefix("```").trim()
            val codeLines = mutableListOf<String>()
            i++
            while (i < rawLines.size && !rawLines[i].trim().startsWith("```")) {
                codeLines.add(rawLines[i])
                i++
            }
            if (i < rawLines.size) {
                i++
            }
            blocks.add(TextBlock.CodeBlock(language, codeLines.joinToString("\n")))
        } else if (trimmed.startsWith("$$") && trimmed.endsWith("$$") && trimmed.length > 4) {
            val expression = trimmed.substring(2, trimmed.length - 2)
            blocks.add(TextBlock.BlockMathExpr(expression))
            i++
        } else if (trimmed.startsWith("|") && trimmed.endsWith("|") && trimmed.length > 1) {
            // Read consecutive table rows
            val tableLines = mutableListOf<String>()
            while (i < rawLines.size && rawLines[i].trim().startsWith("|") && rawLines[i].trim().endsWith("|")) {
                tableLines.add(rawLines[i].trim())
                i++
            }

            if (tableLines.isNotEmpty()) {
                var headers = emptyList<String>()
                val rows = mutableListOf<List<String>>()

                val rawHeaderCells = tableLines[0].split("|").map { it.trim() }.filterIndexed { idx, _ ->
                    idx > 0 && idx < tableLines[0].split("|").size - 1
                }

                var separatorIndex = -1
                if (tableLines.size > 1) {
                    val secondLine = tableLines[1]
                    val isSeparator = secondLine.all { it == '|' || it == '-' || it == ':' || it == ' ' }
                    if (isSeparator) {
                        separatorIndex = 1
                        headers = rawHeaderCells
                    }
                }

                val startIndexForRows = if (separatorIndex != -1) 2 else 0
                for (r in startIndexForRows until tableLines.size) {
                    val rLine = tableLines[r]
                    val cells = rLine.split("|").map { it.trim() }
                    val rowCells = cells.filterIndexed { idx, _ ->
                        idx > 0 && idx < cells.size - 1
                    }
                    rows.add(rowCells)
                }

                blocks.add(TextBlock.TableBlock(headers, rows))
            }
        } else if (trimmed.startsWith("#")) {
            var level = 0
            while (level < trimmed.length && trimmed[level] == '#') {
                level++
            }
            val remaining = trimmed.substring(level).trim()
            blocks.add(TextBlock.Header(level, remaining))
            i++
        } else if (trimmed.startsWith(">")) {
            val remaining = trimmed.substring(1).trim()
            blocks.add(TextBlock.Blockquote(remaining))
            i++
        } else if (isListLine(trimmed)) {
            blocks.add(parseListLine(trimmed))
            i++
        } else {
            blocks.add(TextBlock.Paragraph(line))
            i++
        }
    }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        blocks.forEach { block ->
            when (block) {
                is TextBlock.Paragraph -> {
                    if (block.line.isNotEmpty()) {
                        val segments = parseRichTextSegments(block.line)
                        ParagraphLayout(segments = segments, baseFontSize = baseFontSize, color = color)
                    } else {
                        Box(modifier = Modifier.height(4.dp))
                    }
                }
                is TextBlock.BlockMathExpr -> {
                    val mathNode = parseMathExpression(block.expression)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        RenderMathNode(node = mathNode, baseFontSize = baseFontSize * 1.25f, color = color)
                    }
                }
                is TextBlock.TableBlock -> {
                    RenderTable(headers = block.headers, rows = block.rows, baseFontSize = baseFontSize, textColor = color)
                }
                is TextBlock.Header -> {
                    val headerSegments = parseRichTextSegments(block.text)
                    val sizeMultiplier = when (block.level) {
                        1 -> 1.4f
                        2 -> 1.3f
                        3 -> 1.2f
                        else -> 1.1f
                    }
                    val headerColor = when (block.level) {
                        1, 2 -> Color(0xFF8C52FF) // Use a beautiful bright accent purple
                        else -> color
                    }
                    Box(modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)) {
                        ParagraphLayout(
                            segments = headerSegments,
                            baseFontSize = baseFontSize * sizeMultiplier,
                            color = headerColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                is TextBlock.ListItem -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 12.dp, top = 2.dp, bottom = 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        if (block.isOrdered) {
                            Text(
                                text = block.indexMarker,
                                color = Color(0xFF6B4EE6),
                                fontSize = baseFontSize,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(end = 6.dp)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .padding(top = 6.dp, end = 10.dp)
                                    .size(6.dp)
                                    .background(Color(0xFF6B4EE6), CircleShape)
                            )
                        }
                        
                        val itemSegments = parseRichTextSegments(block.text)
                        Box(modifier = Modifier.weight(1f)) {
                            ParagraphLayout(segments = itemSegments, baseFontSize = baseFontSize, color = color)
                        }
                    }
                }
                is TextBlock.CodeBlock -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E1E2E), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        if (block.language.isNotEmpty()) {
                            Text(
                                text = block.language.uppercase(),
                                color = Color.White.copy(alpha = 0.4f),
                                fontSize = baseFontSize * 0.75f,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }
                        Text(
                            text = block.code,
                            color = Color(0xFFE0E0FF),
                            fontSize = baseFontSize * 0.9f,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 18.sp
                        )
                    }
                }
                is TextBlock.Blockquote -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(24.dp)
                                .background(Color(0xFF6B4EE6), RoundedCornerShape(1.5.dp))
                        )
                        Box(modifier = Modifier.width(10.dp))
                        val quoteSegments = parseRichTextSegments(block.text)
                        ParagraphLayout(segments = quoteSegments, baseFontSize = baseFontSize, color = color.copy(alpha = 0.9f))
                    }
                }
            }
        }
    }
}
