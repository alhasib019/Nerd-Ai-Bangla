package com.example.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.StudyRecord
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*

// Deep Slate/Coal colors to match Nerd AI perfectly
val NerdBgColor = Color(0xFF121318)
val NerdSurfaceColor = Color(0xFF1D1F24)
val NerdSecondaryColor = Color(0xFF282A31)
val AccentPurple = Color(0xFF6B4EE6)
val AccentCoral = Color(0xFFE55D50)
val AccentGreen = Color(0xFF43C068)
val AccentPink = Color(0xFFE8549C)
val AccentBlue = Color(0xFF389BED)
val AccentSlate = Color(0xFF6A798A)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NerdAIScreen(
    viewModel: NerdAIViewModel,
    modifier: Modifier = Modifier
) {
    val appStage by viewModel.appStage.collectAsState()

    when (appStage) {
        "LOGIN" -> LoginSignUpScreen(viewModel)
        "CATEGORY" -> CategorySelectionScreen(viewModel)
        else -> NerdAIAppContent(viewModel, modifier)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginSignUpScreen(viewModel: NerdAIViewModel) {
    var isSignUpStage by remember { mutableStateOf(false) }
    var showGoogleDialog by remember { mutableStateOf(false) }

    val authLoading by viewModel.authLoading.collectAsState()
    val authError by viewModel.authError.collectAsState()

    // Forms States
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }

    // Signup specific states
    var fullName by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var isConfirmPasswordVisible by remember { mutableStateOf(false) }
    var fullNameError by remember { mutableStateOf<String?>(null) }
    var confirmPasswordError by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NerdBgColor),
        contentAlignment = Alignment.Center
    ) {
        // Subtle ambient neon blur/glow in the background
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = AccentPurple.copy(alpha = 0.08f),
                radius = size.minDimension / 1.5f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.1f, size.height * 0.2f)
            )
            drawCircle(
                color = AccentCoral.copy(alpha = 0.05f),
                radius = size.minDimension / 2f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.8f, size.height * 0.8f)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Beautiful interactive illustration container
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = NerdSurfaceColor),
                modifier = Modifier
                    .size(150.dp)
                    .shadow(
                        elevation = 20.dp,
                        shape = RoundedCornerShape(28.dp),
                        spotColor = AccentPurple
                    )
                    .border(
                        BorderStroke(
                            width = 1.5.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(AccentPurple, AccentPink)
                            )
                        ),
                        shape = RoundedCornerShape(28.dp)
                    )
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.img_nerd_ai_robot_logo_1782241928821),
                        contentDescription = "Real Premium AI Logo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    // Soft bottom glow
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.4f))
                                )
                            )
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Nerd AI",
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Black,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Surface(
                color = AccentPurple.copy(alpha = 0.15f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, AccentPurple.copy(alpha = 0.3f)),
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text(
                    text = "বাংলা সংস্করণ • কুইক স্টাডি পার্টনার 🇧🇩",
                    style = MaterialTheme.typography.titleSmall,
                    color = Color(0xFFD3C8FF),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Form container
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = NerdSurfaceColor),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                        RoundedCornerShape(24.dp)
                    )
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = if (isSignUpStage) "নতুন অ্যাকাউন্ট তৈরি করুন 📝" else "লগইন করুন 🔐",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Firebase status custom badge
                    val isFirebaseConnected = viewModel.isRealFirebaseConfigured
                    
                    if (isFirebaseConnected) {
                        Surface(
                            color = Color(0xFF2E7D32).copy(alpha = 0.15f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFF4CAF50).copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(Color(0xFF4CAF50), CircleShape)
                                )
                                Text(
                                    text = "আপনার নিজের ফায়ারবেস প্রজেক্ট সফলভাবে সংযুক্ত আছে!",
                                    color = Color(0xFF81C784),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    } else {
                        Surface(
                            color = AccentCoral.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, AccentCoral.copy(alpha = 0.25f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(AccentCoral, CircleShape)
                                    )
                                    Text(
                                        text = "অনলাইন ফায়ারবেস সংযুক্ত নেই (ডেমো মোড সক্রিয়)",
                                        color = AccentCoral,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = "ফায়ারবেস কানেক্ট করতে AI Studio Secrets প্যানেলে FIREBASE_APP_ID, FIREBASE_API_KEY ও FIREBASE_PROJECT_ID সেট করুন।",
                                    color = Color.LightGray.copy(alpha = 0.7f),
                                    fontSize = 9.sp,
                                    lineHeight = 12.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }

                    if (isSignUpStage) {
                        // Full Name Field (Sign Up Only)
                        Column {
                            OutlinedTextField(
                                value = fullName,
                                onValueChange = {
                                    fullName = it
                                    fullNameError = null
                                },
                                label = { Text("আপনার সম্পূর্ণ নাম", color = Color.Gray) },
                                placeholder = { Text("যেমন: সাদিক রহমান", color = Color.DarkGray) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Name",
                                        tint = AccentPurple
                                    )
                                },
                                isError = fullNameError != null,
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = AccentPurple,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                                    errorBorderColor = AccentCoral,
                                    focusedContainerColor = NerdSecondaryColor,
                                    unfocusedContainerColor = NerdSecondaryColor,
                                    errorContainerColor = NerdSecondaryColor
                                ),
                                keyboardOptions = KeyboardOptions(
                                    imeAction = ImeAction.Next
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("signup_name_input")
                            )
                            if (fullNameError != null) {
                                Text(
                                    text = fullNameError ?: "",
                                    color = AccentCoral,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(start = 6.dp, top = 4.dp)
                                )
                            }
                        }
                    }

                    // Email / Username Field
                    Column {
                        OutlinedTextField(
                            value = email,
                            onValueChange = {
                                email = it
                                emailError = null
                            },
                            label = { Text("ইমেইল বা ইউজারনেম", color = Color.Gray) },
                            placeholder = { Text("demo@gmail.com", color = Color.DarkGray) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Email,
                                    contentDescription = "Email",
                                    tint = AccentPurple
                                )
                            },
                            isError = emailError != null,
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = AccentPurple,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                                errorBorderColor = AccentCoral,
                                focusedContainerColor = NerdSecondaryColor,
                                unfocusedContainerColor = NerdSecondaryColor,
                                errorContainerColor = NerdSecondaryColor
                            ),
                            keyboardOptions = KeyboardOptions(
                                imeAction = ImeAction.Next
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_email_input")
                        )
                        if (emailError != null) {
                            Text(
                                text = emailError ?: "",
                                color = AccentCoral,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 6.dp, top = 4.dp)
                            )
                        }
                    }

                    // Password Field
                    Column {
                        OutlinedTextField(
                            value = password,
                            onValueChange = {
                                password = it
                                passwordError = null
                            },
                            label = { Text("পাসওয়ার্ড", color = Color.Gray) },
                            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Password",
                                    tint = AccentPurple
                                )
                            },
                            trailingIcon = {
                                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isPasswordVisible) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Toggle password visibility",
                                        tint = Color.Gray
                                    )
                                }
                            },
                            isError = passwordError != null,
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = AccentPurple,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                                errorBorderColor = AccentCoral,
                                focusedContainerColor = NerdSecondaryColor,
                                unfocusedContainerColor = NerdSecondaryColor,
                                errorContainerColor = NerdSecondaryColor
                            ),
                            keyboardOptions = KeyboardOptions(
                                imeAction = if (isSignUpStage) ImeAction.Next else ImeAction.Done
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_password_input")
                        )
                        if (passwordError != null) {
                            Text(
                                text = passwordError ?: "",
                                color = AccentCoral,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 6.dp, top = 4.dp)
                            )
                        }
                    }

                    if (isSignUpStage) {
                        // Confirm Password (Sign Up Only)
                        Column {
                            OutlinedTextField(
                                value = confirmPassword,
                                onValueChange = {
                                    confirmPassword = it
                                    confirmPasswordError = null
                                },
                                label = { Text("পাসওয়ার্ড নিশ্চিত করুন", color = Color.Gray) },
                                visualTransformation = if (isConfirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Confirm Password",
                                        tint = AccentPurple
                                    )
                                },
                                trailingIcon = {
                                    IconButton(onClick = { isConfirmPasswordVisible = !isConfirmPasswordVisible }) {
                                        Icon(
                                            imageVector = if (isConfirmPasswordVisible) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                            contentDescription = "Toggle password visibility",
                                            tint = Color.Gray
                                        )
                                    }
                                },
                                isError = confirmPasswordError != null,
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = AccentPurple,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                                    errorBorderColor = AccentCoral,
                                    focusedContainerColor = NerdSecondaryColor,
                                    unfocusedContainerColor = NerdSecondaryColor,
                                    errorContainerColor = NerdSecondaryColor
                                ),
                                keyboardOptions = KeyboardOptions(
                                    imeAction = ImeAction.Done
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("signup_confirm_password_input")
                            )
                            if (confirmPasswordError != null) {
                                Text(
                                    text = confirmPasswordError ?: "",
                                    color = AccentCoral,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(start = 6.dp, top = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Display Firebase Auth errors if any
                    if (authError != null) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = AccentCoral.copy(alpha = 0.15f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, AccentCoral, RoundedCornerShape(12.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("⚠️", fontSize = 16.sp)
                                Text(
                                    text = authError ?: "",
                                    color = AccentCoral,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    // Sign Up / Login Action Button
                    Button(
                        onClick = {
                            if (authLoading) return@Button
                            if (isSignUpStage) {
                                val isNameValid = fullName.isNotBlank() && (fullName.length >= 2)
                                val isEmailValid = email.isNotBlank() && email.contains("@")
                                val isPasswordValid = password.isNotBlank() && (password.length >= 4)
                                val isConfirmValid = password == confirmPassword

                                if (!isNameValid) {
                                    fullNameError = "আপনার পুরো নাম লিখুন (কমপক্ষে ২ অক্ষর)।"
                                }
                                if (!isEmailValid) {
                                    emailError = "অনুগ্রহ করে একটি সঠিক ইমেইল লিখুন।"
                                }
                                if (!isPasswordValid) {
                                    passwordError = "পাসওয়ার্ড কমপক্ষে ৪ সংখ্যা বা অক্ষরে লিখুন।"
                                }
                                if (!isConfirmValid) {
                                    confirmPasswordError = "পাসওয়ার্ড দুটি মিলছে না!"
                                }

                                if (isNameValid && isEmailValid && isPasswordValid && isConfirmValid) {
                                    viewModel.signUpWithFirebase(email.trim(), fullName.trim(), password.trim())
                                }
                            } else {
                                val isEmailValid = email.isNotBlank() && (email.length >= 3)
                                val isPasswordValid = password.isNotBlank() && (password.length >= 4)

                                if (!isEmailValid) {
                                    emailError = "অনুগ্রহ করে সঠিক ইমেইল বা ইউজারনেম লিখুন।"
                                }
                                if (!isPasswordValid) {
                                    passwordError = "পাসওয়ার্ড কমপক্ষে ৪ সংখ্যা বা অক্ষরে লিখুন।"
                                }

                                if (isEmailValid && isPasswordValid) {
                                    viewModel.loginWithFirebase(email.trim(), password.trim())
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("submit_login_button")
                    ) {
                        if (authLoading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        } else {
                            Text(
                                text = if (isSignUpStage) "সাইন আপ এবং শুরু করুন ➔" else "লগইন করুন ➔",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Gmail / Google Quick Login Button requested by user
                    Button(
                        onClick = { showGoogleDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("google_login_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text("🌐  ", fontSize = 16.sp)
                            Text(
                                text = "Gmail / Google সরাসরি লগইন",
                                color = Color.Black,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Toggle Stage Link
            TextButton(
                onClick = {
                    isSignUpStage = !isSignUpStage
                    emailError = null
                    passwordError = null
                    fullNameError = null
                    confirmPasswordError = null
                    viewModel.clearAuthError()
                },
                modifier = Modifier.testTag("toggle_login_signup_link")
            ) {
                Text(
                    text = if (isSignUpStage) "অ্যাকাউন্ট আছে? আগের অ্যাকাউন্ট দিয়ে লগইন করুন ➔" else "কোনো অ্যাকাউন্ট নেই? নতুন অ্যাকাউন্ট তৈরি করুন ➔",
                    color = Color.LightGray,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    // Google / Gmail Direct Entry Dialog
    if (showGoogleDialog) {
        var gmailInput by remember { mutableStateOf("absadik225@gmail.com") }
        var googleError by remember { mutableStateOf<String?>(null) }

        Dialog(
            onDismissRequest = { showGoogleDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = NerdSurfaceColor),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .border(
                        BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                        RoundedCornerShape(28.dp)
                    )
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "গুগল অ্যাকাউন্ট সংযোগ 🌐",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "গুগল ও জিমেইল অ্যাকাউন্টের মাধ্যমে সরাসরি ওয়ান-ক্লিক লগইনের জন্য জিমেইলটি নিশ্চিত করুন।",
                        fontSize = 13.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )

                    OutlinedTextField(
                        value = gmailInput,
                        onValueChange = {
                            gmailInput = it
                            googleError = null
                        },
                        label = { Text("আপনার জিমেইল এড্রেস", color = Color.Gray) },
                        isError = googleError != null,
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentPurple,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                            errorBorderColor = AccentCoral,
                            focusedContainerColor = NerdSecondaryColor,
                            unfocusedContainerColor = NerdSecondaryColor,
                            errorContainerColor = NerdSecondaryColor
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("google_gmail_field")
                    )

                    if (googleError != null) {
                        Text(
                            text = googleError ?: "",
                            color = AccentCoral,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        TextButton(
                            onClick = { showGoogleDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("বাতিল করুন", color = Color.Gray, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                if (gmailInput.isNotBlank() && gmailInput.contains("@")) {
                                    showGoogleDialog = false
                                    viewModel.loginUser(gmailInput.trim())
                                } else {
                                    googleError = "একটি সঠিক জিমেইল এড্রেস প্রদান করুন।"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("প্রবেশ করুন ➔", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategorySelectionScreen(viewModel: NerdAIViewModel) {
    val userEmail by viewModel.userEmail.collectAsState()
    var selectedVal by remember { mutableStateOf("SSC") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NerdBgColor),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = AccentPurple.copy(alpha = 0.08f),
                radius = size.minDimension / 1.5f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.9f, size.height * 0.1f)
            )
            drawCircle(
                color = AccentBlue.copy(alpha = 0.05f),
                radius = size.minDimension / 2f,
                center = androidx.compose.ui.geometry.Offset(size.width * 0.1f, size.height * 0.9f)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Smaller avatar profile at the top
            Box(
                modifier = Modifier
                    .padding(bottom = 16.dp)
                    .size(84.dp)
            ) {
                Card(
                    shape = CircleShape,
                    border = BorderStroke(2.dp, AccentPurple),
                    modifier = Modifier.fillMaxSize(),
                    colors = CardDefaults.cardColors(containerColor = NerdSurfaceColor)
                ) {
                    Image(
                        painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.img_nerd_ai_robot_logo_1782241928821),
                        contentDescription = "AI Companion Profile",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                // Online badge
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .background(Color(0xFF4CAF50), CircleShape)
                        .border(2.dp, NerdBgColor, CircleShape)
                        .align(Alignment.BottomEnd)
                )
            }

            val displayName = if(userEmail.contains("@")) userEmail.substringBefore("@") else userEmail
            Text(
                text = "হ্যালো, ${if(displayName.isNotBlank()) displayName else " শিক্ষার্থী"}! 👋",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "আপনার শিক্ষা বিভাগ বেছে নিন 🇧🇩",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = AccentPurple,
                textAlign = TextAlign.Center
            )

            Text(
                text = "আপনার সিলেক্ট করা বিভাগের উপর ভিত্তি করে এআই ফিচার অভিযোজিত হবে",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 6.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Category card list
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                val categories = listOf(
                    Triple("SSC", "মাধ্যমিক SSC 🎒", "৯ম ও ১০ম শ্রেণীর বোর্ড সৃজনশীল প্রশ্ন, কুইজ ও অধ্যায়ভিত্তিক শর্ট রিভিশন নোটস।"),
                    Triple("HSC", "উচ্চ মাধ্যমিক HSC 🎓", "১১শ ও ১২শ শ্রেণীর কলেজ টেস্ট পেপার প্রশ্নপত্র সমাধান, সাজেস্টিভ নোটস ও সূত্রাবলি।"),
                    Triple("Job Seeker", "চাকরি প্রিপারেশন 💼", "BCS, NTRCA, প্রাইমারি শিক্ষক নিয়োগ এমসিকিউ প্র্যাক্টিস, শর্টকাট ম্যাথ ট্রিক ও অফিশিয়াল দরখাস্ত রাইটার।")
                )

                categories.forEach { (catId, title, desc) ->
                    val isSelected = selectedVal == catId
                    Card(
                        onClick = { selectedVal = catId },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) AccentPurple.copy(alpha = 0.15f) else NerdSurfaceColor
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) AccentPurple else Color.White.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .testTag("select_cat_$catId")
                    ) {
                        Row(
                            modifier = Modifier.padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = title,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = desc,
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    lineHeight = 16.sp
                                )
                            }
                            
                            // Checkmark
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) AccentPurple else NerdSecondaryColor)
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) AccentPurple else Color.Gray.copy(alpha = 0.4f),
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            // Enter App Button
            Button(
                onClick = {
                    viewModel.updateSelectedCategory(selectedVal)
                    viewModel.setAppStage("MAIN")
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("confirm_category_button")
            ) {
                Text(
                    text = "স্মার্ট হোম স্ক্রিনে প্রবেশ করুন ➔",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NerdAIAppContent(
    viewModel: NerdAIViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var showProfileSheetImpl by remember { mutableStateOf(false) }
    var showProUpgradeDialog by remember { mutableStateOf(false) }
    val userEmailVal by viewModel.userEmail.collectAsState()
    val userNameVal by viewModel.userName.collectAsState()
    val isPremiumVal by viewModel.isPremium.collectAsState()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val clipboardManager = LocalClipboardManager.current

    // Initialize Android native Text-to-Speech safely
    var ttsInstance by remember { mutableStateOf<TextToSpeech?>(null) }
    var isTtsReady by remember { mutableStateOf(false) }

    DisposableEffect(context) {
        var tts: TextToSpeech? = null
        try {
            tts = TextToSpeech(context) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    isTtsReady = true
                }
            }
            try {
                tts.setLanguage(Locale("bn", "BD"))
            } catch (_: Exception) {}
            ttsInstance = tts
        } catch (e: Exception) {
            android.util.Log.e("NerdAIApp", "TextToSpeech initialization failed safely: ${e.message}")
        }
        onDispose {
            try {
                ttsInstance?.stop()
                ttsInstance?.shutdown()
            } catch (_: Exception) {}
        }
    }

    val speakAloud: (String) -> Unit = { text ->
        if (isTtsReady && ttsInstance != null) {
            ttsInstance?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = AccentPurple.copy(alpha = 0.2f),
                            shape = CircleShape,
                            border = BorderStroke(1.dp, AccentPurple),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Image(
                                painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.img_nerd_ai_robot_logo_1782241928821),
                                contentDescription = "Real AI Icon",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                        Column {
                            Text(
                                text = "Nerd AI",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "বাংলা সংস্করণ • স্টাডি পার্টনার",
                                style = MaterialTheme.typography.labelSmall,
                                color = AccentPurple,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NerdBgColor,
                    titleContentColor = Color.White
                ),
                actions = {
                    // Circular Profile Icon Button on the top right
                    Box(
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .size(35.dp)
                            .clip(CircleShape)
                            .background(AccentPurple.copy(alpha = 0.2f))
                            .border(1.5.dp, AccentPurple, CircleShape)
                            .clickable {
                                showProfileSheetImpl = true
                            }
                            .testTag("profile_icon_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        val initial = if (userNameVal.isNotEmpty()) {
                            userNameVal.take(1).uppercase()
                        } else if (userEmailVal.isNotEmpty()) {
                            userEmailVal.take(1).uppercase()
                        } else {
                            "U"
                        }
                        Text(
                            text = initial,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    // Pro Tag matching the screenshot
                    Surface(
                        color = Color(0xFFFFB300),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { showProUpgradeDialog = true }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "PRO",
                                color = Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text("🤓", fontSize = 10.sp)
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF1A1C23), // Slightly lighter surface for bottom bar to elevate it
                tonalElevation = 8.dp,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .border(width = (0.5).dp, color = Color.White.copy(alpha = 0.12f))
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "টুলস") },
                    label = { Text("Tools", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFC4B5FD), // Brighter glowing pastel purple
                        unselectedIconColor = Color.White.copy(alpha = 0.75f), // High contrast unselected state
                        selectedTextColor = Color.White, // Pure white for selected
                        unselectedTextColor = Color.White.copy(alpha = 0.75f), // Clear readable white for unselected
                        indicatorColor = Color(0xFFB39DFF).copy(alpha = 0.25f)
                    ),
                    modifier = Modifier.testTag("tab_tools")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.CameraAlt, contentDescription = "স্ক্যান সমাধান") },
                    label = { Text("Scan & Solve", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFC4B5FD),
                        unselectedIconColor = Color.White.copy(alpha = 0.75f),
                        selectedTextColor = Color.White,
                        unselectedTextColor = Color.White.copy(alpha = 0.75f),
                        indicatorColor = Color(0xFFB39DFF).copy(alpha = 0.25f)
                    ),
                    modifier = Modifier.testTag("tab_scan_solve")
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Assistant, contentDescription = "এআই টিউটর") },
                    label = { Text("AI Tutor", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFC4B5FD),
                        unselectedIconColor = Color.White.copy(alpha = 0.75f),
                        selectedTextColor = Color.White,
                        unselectedTextColor = Color.White.copy(alpha = 0.75f),
                        indicatorColor = Color(0xFFB39DFF).copy(alpha = 0.25f)
                    ),
                    modifier = Modifier.testTag("tab_ai_tutor")
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.History, contentDescription = "ইতিহাস") },
                    label = { Text("History", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFC4B5FD),
                        unselectedIconColor = Color.White.copy(alpha = 0.75f),
                        selectedTextColor = Color.White,
                        unselectedTextColor = Color.White.copy(alpha = 0.75f),
                        indicatorColor = Color(0xFFB39DFF).copy(alpha = 0.25f)
                    ),
                    modifier = Modifier.testTag("tab_history")
                )
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(NerdBgColor)
        ) {
            when (selectedTab) {
                0 -> ToolsTab(viewModel, speakAloud, onProClick = { showProUpgradeDialog = true })
                1 -> ScanSolveTab(viewModel)
                2 -> AiTutorTab(viewModel, speakAloud)
                3 -> HistoryTab(viewModel, clipboardManager)
            }
        }
    }

    if (showProfileSheetImpl) {
        UserProfileDialog(
            onDismiss = { showProfileSheetImpl = false },
            userName = userNameVal,
            userEmail = userEmailVal,
            isPremium = isPremiumVal,
            onLogout = { viewModel.logoutUser() }
        )
    }

    if (showProUpgradeDialog) {
        ProUpgradeDialog(
            onDismiss = { showProUpgradeDialog = false },
            isPremium = isPremiumVal,
            onTogglePremium = { viewModel.togglePremiumStatus() }
        )
    }
}

// ------------------- TAB 1: TOOLS (The Grid View dashboard) -------------------
@Composable
fun ToolsTab(viewModel: NerdAIViewModel, speakAloud: (String) -> Unit, onProClick: () -> Unit) {
    var showBrowsingDialog by remember { mutableStateOf(false) }
    var showListeningDialog by remember { mutableStateOf(false) }

    val activeToolName by viewModel.activeToolName.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Welcoming Banner Section
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF14131A)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .shadow(
                    elevation = 16.dp,
                    shape = RoundedCornerShape(24.dp)
                )
                .border(
                    width = 1.5.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            AccentPurple.copy(alpha = 0.8f),
                            AccentPink.copy(alpha = 0.4f),
                            Color.Transparent
                        )
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF1B1238),
                                Color(0xFF0F0A1F)
                            )
                        )
                    )
                    .drawBehind {
                        // Soft elegant glowing visual particles (Cosmic orbs)
                        val w = this.size.width
                        val h = this.size.height
                        val minD = this.size.minDimension
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(AccentPurple.copy(alpha = 0.4f), Color.Transparent),
                                center = androidx.compose.ui.geometry.Offset(w * 0.85f, h * 0.15f),
                                radius = minD * 0.8f
                            ),
                            radius = minD * 0.8f,
                            center = androidx.compose.ui.geometry.Offset(w * 0.85f, h * 0.15f)
                        )
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(AccentPink.copy(alpha = 0.25f), Color.Transparent),
                                center = androidx.compose.ui.geometry.Offset(w * 0.15f, h * 0.8f),
                                radius = minD * 0.7f
                            ),
                            radius = minD * 0.7f,
                            center = androidx.compose.ui.geometry.Offset(w * 0.15f, h * 0.8f)
                        )
                    }
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(AccentPurple.copy(alpha = 0.25f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Nerd AI Study Companion ✨",
                                color = Color(0xFFDCD6FF),
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Welcome to Nerd AI ⚡",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 22.sp,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "স্মার্ট লার্নিং ও বোর্ড পরীক্ষার সফল প্রস্তুতির বিশ্বস্ত এআই সুপার-অ্যাসিস্ট্যান্ট!",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Box(
                        modifier = Modifier
                            .padding(start = 14.dp)
                            .size(80.dp)
                    ) {
                        Card(
                            shape = CircleShape,
                            border = BorderStroke(2.dp, Color(0xFFFFD700)), // Gorgeous Golden Ring
                            modifier = Modifier.fillMaxSize(),
                            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                        ) {
                            Image(
                                painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.img_nerd_ai_robot_logo_1782241928821),
                                contentDescription = "AI Core Banner Avatar",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                        // Micro notification badge or small cute spark
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .background(Color(0xFFFFB300), CircleShape)
                                .border(1.5.dp, Color(0xFF1B1238), CircleShape)
                                .align(Alignment.TopEnd),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("⚡", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
            }
        }

        // Core Category Streams & Pro Toggles Panel
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = NerdSurfaceColor),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp)
                .border(width = 1.dp, color = Color.White.copy(alpha = 0.08f), shape = RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "আপনার সক্রিয় শিক্ষা বিভাগ 🇧🇩",
                            color = Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        val activeCategoryLabel = when(selectedCategory) {
                            "SSC" -> "মাধ্যমিক SSC 🎒"
                            "HSC" -> "উচ্চ মাধ্যমিক HSC 🎓"
                            else -> "চাকরি প্রিপারেশন 💼"
                        }
                        Text(
                            text = activeCategoryLabel,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    
                    // Premium Toggle Pill with Premium Golden Gradient Design
                    Box(
                        modifier = Modifier
                            .clickable { onProClick() }
                            .shadow(
                                elevation = if (isPremium) 12.dp else 4.dp,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .background(
                                brush = if (isPremium) {
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color(0xFFFFB300),
                                            Color(0xFFFF8F00)
                                        )
                                    )
                                } else {
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color(0xFF2E3039),
                                            Color(0xFF1E2026)
                                        )
                                    )
                                }
                            ,
                            shape = RoundedCornerShape(14.dp)
                            )
                            .border(
                                width = 1.2.dp,
                                color = if (isPremium) Color.White.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(14.dp)
                            )
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                            .testTag("premium_upgrade_toggle_pill")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = if (isPremium) Icons.Default.Star else Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (isPremium) Color.White else Color.Gray,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = if (isPremium) "PRO ACTIVE 👑" else "GET PRO ⚡",
                                color = if (isPremium) Color.White else Color.LightGray,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }

        // Top 2 Horizontal Banner Cards (Browsing Chat, Listen Your Text) - Identical height to bottom tools grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Horizontal Card 1: Browsing Chat (Cyber Pink-Purple)
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                modifier = Modifier
                    .weight(1f)
                    .height(155.dp)
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(24.dp)
                    )
                    .clickable { showBrowsingDialog = true }
                    .border(
                        width = 1.5.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(
                                AccentPink,
                                AccentPink.copy(alpha = 0.2f)
                             )
                        ),
                        shape = RoundedCornerShape(24.dp)
                    )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF26104A), // Deep premium cosmic purple-magenta
                                    Color(0xFF100524)  // Ultra dark space violet
                                )
                            )
                        )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = AccentPink.copy(alpha = 0.35f),
                                shape = CircleShape,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Language,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Surface(
                                color = AccentPink.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Realtime", color = Color(0xFFFFF0F5), fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        Column {
                            Text("Browsing Chat", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("ব্রাউজিং চ্যাট উত্তরসমূহ", color = Color(0xFFF3E8FF), fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }

            // Horizontal Card 2: Listen Your Text (Cyber Amber-Gold)
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                modifier = Modifier
                    .weight(1f)
                    .height(155.dp)
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(24.dp)
                    )
                    .clickable { showListeningDialog = true }
                    .border(
                        width = 1.5.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color(0xFFFFB300), // Glowing gold/amber border
                                Color(0xFFFFB300).copy(alpha = 0.2f)
                            )
                        ),
                        shape = RoundedCornerShape(24.dp)
                    )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF2B1F0A), // Rich deep dark gold-bronze
                                    Color(0xFF120C03)  // Deepest obsidian black-gold
                                )
                            )
                        )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = Color(0xFFFFB300).copy(alpha = 0.35f),
                                shape = CircleShape,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Surface(
                                color = Color(0xFFFFB300).copy(alpha = 0.25f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("TTS Audio", color = Color(0xFFFFF8E1), fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        Column {
                            Text("Listen Your Text", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("অডিও উচ্চারণ শুনুন", color = Color(0xFFFEF3C7), fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // AI Tools Section Header
        Text(
            text = "AI Specialized Tools",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // 6 Grid Items mimicking the original Nerd AI layout but fully localized for Bangla Education
        val toolsList = listOf(
            GridToolItem(
                id = "Learning Assistant",
                nameBn = "বোর্ড সাজেশনস 🎯",
                subText = "চূড়ান্ত কমন উপযোগী প্রশ্ন ও উত্তর",
                color = AccentPurple,
                icon = Icons.Default.School,
                containerColor = Color(0xFF0F2C59), // Elegant deep navy blue
                titleColor = Color.White, // Pure White for maximum contrast
                subtextColor = Color(0xFFDBEAFE), // Extremely bright and readable sky-blue tint
                borderColor = Color(0xFF3B82F6).copy(alpha = 0.45f)
            ),
            GridToolItem(
                id = "Content Generator",
                nameBn = "বোর্ড ফরম্যাট রাইটার ✍️",
                subText = "দরখাস্ত, রচনা, ইমেইল ও সিভি লিখন",
                color = AccentCoral,
                icon = Icons.Default.Create,
                containerColor = Color(0xFF4C1F1F), // Soft, deep coral red
                titleColor = Color.White, // Pure White for maximum contrast
                subtextColor = Color(0xFFFEE2E2), // Extremely bright and readable rose-pink tint
                borderColor = Color(0xFFEF4444).copy(alpha = 0.45f)
            ),
            GridToolItem(
                id = "Language",
                nameBn = "অনুবাদ ও গ্রামার 📚",
                subText = "অনুবাদ করুন এবং ব্যাকরণ নিয়ম শিখুন",
                color = AccentGreen,
                icon = Icons.Default.Translate,
                containerColor = Color(0xFF063A2B), // Deep emerald green
                titleColor = Color.White, // Pure White for maximum contrast
                subtextColor = Color(0xFFD1FAE5), // Extremely bright and readable mint-green tint
                borderColor = Color(0xFF10B981).copy(alpha = 0.45f)
            ),
            GridToolItem(
                id = "Essay Helper",
                nameBn = "পিডিএফ সামারি 📖",
                subText = "বই বা শিটের দীর্ঘ পিডিএফ-এর সারসংক্ষেপ",
                color = AccentPink,
                icon = Icons.Default.PictureAsPdf,
                containerColor = Color(0xFF311A5C), // Premium deep purple
                titleColor = Color.White, // Pure White for maximum contrast
                subtextColor = Color(0xFFEDE9FE), // Extremely bright and readable lavender-violet tint
                borderColor = Color(0xFF8B5CF6).copy(alpha = 0.45f)
            ),
            GridToolItem(
                id = "Summarizer",
                nameBn = "নোটস ও সামারি 📝",
                subText = "সব সূত্র, সংজ্ঞা ও গুরুত্বপূর্ণ সাল/উপাত্ত",
                color = AccentBlue,
                icon = Icons.Default.MenuBook,
                containerColor = Color(0xFF0D324D), // Elegant deep sapphire/teal
                titleColor = Color.White, // Pure White for maximum contrast
                subtextColor = Color(0xFFCCFBF1), // Extremely bright and readable cyan-teal tint
                borderColor = Color(0xFF14B8A6).copy(alpha = 0.45f)
            ),
            GridToolItem(
                id = "Code Enhancer",
                nameBn = "MCQ প্র্যাকটিস 💻",
                subText = "বিগত বছরের ট্রিকি ও বোর্ড কুইজ",
                color = AccentSlate,
                icon = Icons.Default.Quiz,
                containerColor = Color(0xFF4A2B0F), // Rich warm dark amber gold
                titleColor = Color.White, // Pure White for maximum contrast
                subtextColor = Color(0xFFFEF3C7), // Extremely bright and readable golden-amber tint
                borderColor = Color(0xFFF59E0B).copy(alpha = 0.45f)
            )
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            for (i in toolsList.indices step 2) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Left element
                    Box(modifier = Modifier.weight(1f)) {
                        ToolGridCard(tool = toolsList[i]) {
                            viewModel.openToolDialog(toolsList[i].id)
                        }
                    }
                    // Right element (if exists)
                    if (i + 1 < toolsList.size) {
                        Box(modifier = Modifier.weight(1f)) {
                            ToolGridCard(tool = toolsList[i + 1]) {
                                viewModel.openToolDialog(toolsList[i + 1].id)
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }

    // 1. Browsing Dialog Callout
    if (showBrowsingDialog) {
        BrowsingSearchDialog(
            viewModel = viewModel,
            onDismiss = { showBrowsingDialog = false }
        )
    }

    // 2. Listen To Text TTS Pronunciation Dialog
    if (showListeningDialog) {
        ListenTextDialog(
            speakAloud = speakAloud,
            onDismiss = { showListeningDialog = false }
        )
    }

    // 3. Grid Tool Dialog (Displays specialized overlay depending on chosen tool card)
    if (activeToolName != null) {
        SpecializedToolDialog(
            viewModel = viewModel,
            toolName = activeToolName!!,
            onDismiss = { viewModel.closeToolDialog() }
        )
    }
}

data class GridToolItem(
    val id: String,
    val nameBn: String,
    val subText: String,
    val color: Color,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val containerColor: Color,
    val titleColor: Color,
    val subtextColor: Color,
    val borderColor: Color
)

@Composable
fun ToolGridCard(tool: GridToolItem, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = tool.containerColor),
        modifier = Modifier
            .fillMaxWidth()
            .height(155.dp)
            .shadow(
                elevation = 12.dp,
                shape = RoundedCornerShape(24.dp)
            )
            .clickable { onClick() }
            .border(width = 1.2.dp, color = tool.borderColor, shape = RoundedCornerShape(24.dp))
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Cute mathematical doodle outline decoration on the background
            MathDoodleBackground(color = tool.color.copy(alpha = 0.12f))

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top circular background Vector Icon container matching the screenshot color themes
                Surface(
                    color = tool.color.copy(alpha = 0.25f),
                    shape = CircleShape,
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = tool.icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Column {
                    Text(
                        text = tool.nameBn,
                        color = tool.titleColor,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = tool.subText,
                        color = tool.subtextColor,
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun MathDoodleBackground(color: Color) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        withTransform({
            rotate(degrees = -15f)
        }) {
            // Draw dummy cute icons, scientific orbit paths
            val path = Path().apply {
                moveTo(size.width * 0.7f, size.height * 0.2f)
                quadraticTo(size.width * 0.85f, size.height * 0.3f, size.width * 0.8f, size.height * 0.6f)
            }
            drawPath(path, color = color, style = Stroke(width = 1.5.dp.toPx()))

            // Little star symbols or academic crosses
            drawCircle(color = color, radius = 4.dp.toPx(), center = androidx.compose.ui.geometry.Offset(size.width * 0.75f, size.height * 0.18f))
            drawCircle(color = color, radius = 2.dp.toPx(), center = androidx.compose.ui.geometry.Offset(size.width * 0.9f, size.height * 0.45f))
        }
    }
}

// ------------------- TAB 2: SCAN & SOLVE (Visual Interactive Notebook Solver) -------------------
@Composable
fun ScanSolveTab(viewModel: NerdAIViewModel) {
    val context = LocalContext.current
    var showMediaPicker by remember { mutableStateOf(false) }
    var showRealtimeCameraScanner by remember { mutableStateOf(false) }
    val showScanLimitDialog by viewModel.showScanLimitDialog.collectAsState()
    
    val scanInputQuery by viewModel.scanInputQuery.collectAsState()
    val scanSolution by viewModel.scanSolution.collectAsState()
    val isScanLoading by viewModel.isScanLoading.collectAsState()
    val scanError by viewModel.scanError.collectAsState()
    val selectedImageBase64 by viewModel.selectedImageBase64.collectAsState()
    val selectedImageName by viewModel.selectedImageName.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val selectedScanSpotIndex by viewModel.selectedScanSpotIndex.collectAsState()

    val scanSpots = getScanSpotsForCategory(selectedCategory)

    // Activity launcher for media selection
    val pickMediaLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val base64 = uriToBase64(context, uri)
            viewModel.setSelectedImage(base64, "গ্যালারি ছবি.jpg")
        }
    }

    // Activity launcher for camera capture
    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            val base64 = bitmapToBase64(bitmap)
            viewModel.setSelectedImage(base64, "ক্যামেরা ছবি.jpg")
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "Scan & Solve (ছবি দেখে সমাধান)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = "যেকোনো কঠিন গণিত সমীকরণ, সূত্র বা নোটের ছবি তুলে দিন। Gemini সমাধান প্রস্তুত করে দেবে।",
            fontSize = 11.sp,
            color = Color.Gray,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // --- High Fidelity Universal Subject & Chapter Selector ---
        Text(
            text = "১. বিষয়ের স্পট নির্বাচন করুন:",
            style = MaterialTheme.typography.labelMedium,
            color = Color.LightGray,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            itemsIndexed(scanSpots) { index, spot ->
                val isSpotSelected = selectedScanSpotIndex == index
                Card(
                    modifier = Modifier
                        .widthIn(min = 120.dp, max = 220.dp)
                        .clickable {
                            viewModel.setSelectedScanSpotIndex(index)
                            // Clear model's selected image on general category switch
                            // so that the camera/scanner layout is shown instead of a mock image banner.
                            viewModel.setSelectedImage(null, null)
                            viewModel.updateScanInputQuery("")
                            // Auto-trigger scanning viewfinder
                            showRealtimeCameraScanner = true
                        }
                        .testTag("scan_spot_${index}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSpotSelected) AccentPurple.copy(alpha = 0.25f) else NerdSecondaryColor
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (isSpotSelected) AccentPurple else Color.White.copy(alpha = 0.05f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(spot.icon, fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = spot.title,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Active Subject guidelines including all 100% textbook chapter rules
        val activeSpot = scanSpots.getOrNull(selectedScanSpotIndex)
        if (activeSpot != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = AccentPurple.copy(alpha = 0.06f)),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, AccentPurple.copy(alpha = 0.15f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(activeSpot.icon, fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${activeSpot.title} - সম্পূর্ণ সিলেবাসের সব অধ্যায় (All Chapters)",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = activeSpot.description,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = AccentGreen.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "✓ সম্পূর্ণ বই ও সিলেবাসের যেকোনো চ্যাপ্টার বা অধ্যায়ের সমাধান কভার্ড",
                                color = AccentGreen,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        } else {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.02f)),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💡", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "সাধারণ সমাধান মোড একটিভ",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "কোনো নির্দিষ্ট স্পট সিলেক্ট করা হয়নি। যেকোনো বইয়ের পৃষ্ঠা বা খাতার ছবি তুলে সরাসরি সমাধান করুন, অথবা সঠিক সিলেবাসের নিয়ম যুক্ত করতে উপরের স্পটগুলো থেকে একটি বিষয় সিলেক্ট করুন।",
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        color = Color.Gray
                    )
                }
            }
        }

        // Selected Image Notebook Mock Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(NerdSecondaryColor)
                .border(2.dp, AccentPurple.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                .clickable(enabled = selectedImageBase64 == null) {
                    showMediaPicker = true
                },
            contentAlignment = Alignment.Center
        ) {
            if (selectedImageBase64 != null) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Turn Base64 into Displayable bitmap or mock a gorgeous notebook page
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = Color(0xFF1B5E20),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "✓ ছবি নির্বাচিত",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(onClick = { viewModel.setSelectedImage(null, null) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove Image", tint = Color.Red)
                            }
                        }

                        val decodedBitmap = remember(selectedImageBase64) {
                            if (selectedImageBase64 != null && selectedImageBase64 != "MOCK_BASE64_IMAGE_DATA_YES") {
                                try {
                                    val decodedBytes = Base64.decode(selectedImageBase64, Base64.DEFAULT)
                                    BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
                                } catch (e: Exception) {
                                    null
                                }
                            } else {
                                null
                            }
                        }

                        if (decodedBitmap != null) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(115.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Image(
                                    bitmap = decodedBitmap.asImageBitmap(),
                                    contentDescription = "Selected Scan Image",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        } else {
                            // Hand-drawn notebook representation
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFDF5)), // Elegant warm white notebook paper
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(95.dp),
                                shape = RoundedCornerShape(12.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    // Lines
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        // Horizontal lines
                                        for (y in 1..4) {
                                            drawLine(
                                                color = Color.LightGray.copy(alpha = 0.4f),
                                                start = androidx.compose.ui.geometry.Offset(0f, y * 20.dp.toPx()),
                                                end = androidx.compose.ui.geometry.Offset(size.width, y * 20.dp.toPx()),
                                                strokeWidth = 1f
                                            )
                                        }
                                        // Red margin line (like real student notebook scripts in Bangladesh)
                                        drawLine(
                                            color = Color.Red.copy(alpha = 0.25f),
                                            start = androidx.compose.ui.geometry.Offset(35.dp.toPx(), 0f),
                                            end = androidx.compose.ui.geometry.Offset(35.dp.toPx(), size.height),
                                            strokeWidth = 1.2f
                                        )
                                    }
                                    Column(modifier = Modifier.padding(start = 45.dp, top = 12.dp, end = 12.dp, bottom = 12.dp)) {
                                        Text("📝 সমীকরণ / প্রশ্ন পৃষ্ঠা:", fontSize = 10.sp, color = Color.DarkGray, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = selectedImageName ?: "বইয়ের পৃষ্ঠা",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Color.Black,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = scanInputQuery,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.Gray,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }

                        Text(
                            text = "গ্ল্যামার বাউন্ড ক্রপ মার্কার সক্রিয় 🎯",
                            color = AccentPurple,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text("📐📸🎨", fontSize = 42.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "প্রশ্ন বা খাতার ছবি ক্যামেরা দিয়ে তুলুন অথবা ডিভাইস থেকে সিলেক্ট করুন",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { showMediaPicker = true },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(46.dp)
                            .testTag("scan_or_upload_media_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("✨", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ছবি তুলুন / ফাইল নির্বাচন করুন", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Custom Solve action query input
        Text(
            text = "গ্লোবাল প্রম্পট / অতিরিক্ত নির্দেশনা বলুন:",
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        OutlinedTextField(
            value = scanInputQuery,
            onValueChange = { viewModel.updateScanInputQuery(it) },
            placeholder = { Text("Gemini ইন্স্ট্রাকশন লিখুন...") },
            trailingIcon = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(end = 4.dp)
                ) {
                    BengaliVoiceInputButton(
                        onTextRecognized = { spokenText ->
                            viewModel.updateScanInputQuery(spokenText)
                        },
                        modifier = Modifier.size(36.dp),
                        iconSize = 16
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = {
                            viewModel.solveScanAndSolve()
                        },
                        enabled = selectedImageBase64 != null && !isScanLoading,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = if (selectedImageBase64 != null && !isScanLoading) AccentPurple else Color.Gray.copy(alpha = 0.5f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("scan_prompt_input"),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AccentPurple,
                unfocusedBorderColor = Color.White.copy(alpha = 0.1f),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = NerdSurfaceColor,
                unfocusedContainerColor = NerdSurfaceColor
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                viewModel.solveScanAndSolve()
            },
            enabled = selectedImageBase64 != null && !isScanLoading,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("scan_solve_trigger_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = AccentPurple,
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (isScanLoading) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text("Gemini খাতা সমাধান করছে...", fontWeight = FontWeight.Bold)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("অনুরোধ সমাধান করুন", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Result presentation Box
        if (isScanLoading || scanSolution.isNotEmpty() || scanError != null) {
            Text(
                text = "সমাধান উইন্ডো:",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 150.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(NerdSurfaceColor)
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                if (isScanLoading) {
                    ScanProcessingSkeleton()
                } else if (scanError != null) {
                    Text(
                        text = scanError!!,
                        color = Color.Red,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else if (scanSolution.isNotEmpty()) {
                    Column {
                        Text(
                            text = "✅ চমৎকার সমাধান প্রস্তুত",
                            fontWeight = FontWeight.Bold,
                            color = AccentGreen,
                            fontSize = 13.sp
                        )
                        Divider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 10.dp))
                        LatexText(
                            text = scanSolution,
                            color = Color.White,
                            baseFontSize = 14.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }

    if (showMediaPicker) {
        MediaPickerDialog(
            onDismiss = { showMediaPicker = false },
            onLaunchCamera = {
                showMediaPicker = false
                showRealtimeCameraScanner = true
            },
            onLaunchGallery = { pickMediaLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
        )
    }

    if (showRealtimeCameraScanner) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showRealtimeCameraScanner = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            CameraScannerView(
                onImageCaptured = { base64, fileName ->
                    viewModel.setSelectedImage(base64, fileName)
                    showRealtimeCameraScanner = false
                },
                onDismiss = {
                    showRealtimeCameraScanner = false
                }
            )
        }
    }

    if (showScanLimitDialog) {
        ScanLimitAlertDialog(
            onDismiss = { viewModel.dismissScanLimitDialog() },
            onUpgrade = { viewModel.forceActivatePremium() }
        )
    }
}

@Composable
fun MediaPickerDialog(
    onDismiss: () -> Unit,
    onLaunchCamera: () -> Unit,
    onLaunchGallery: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = NerdSurfaceColor,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(20.dp))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "ছবি আপলোড করুন",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Text(
                    text = "সমাধান করতে নতুন ছবি তুলতে ক্যামেরা সিলেক্ট করুন অথবা মেমোরি থেকে নিতে গ্যালারি সিলেক্ট করুন",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 20.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Camera Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                onLaunchCamera()
                                onDismiss()
                            }
                            .testTag("picker_camera_option"),
                        colors = CardDefaults.cardColors(containerColor = AccentPurple.copy(alpha = 0.1f)),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AccentPurple.copy(alpha = 0.3f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("📸", fontSize = 28.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("ক্যামেরা", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("ছবি তুলুন", color = Color.Gray, fontSize = 10.sp)
                        }
                    }

                    // Gallery Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                onLaunchGallery()
                                onDismiss()
                            }
                            .testTag("picker_gallery_option"),
                        colors = CardDefaults.cardColors(containerColor = AccentGreen.copy(alpha = 0.1f)),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AccentGreen.copy(alpha = 0.3f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🖼️", fontSize = 28.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("গ্যালারি", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("ফাইল সিলেক্ট", color = Color.Gray, fontSize = 10.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Close Button
                TextButton(onClick = onDismiss, modifier = Modifier.testTag("picker_close")) {
                    Text("বাতিল করুন", color = Color.LightGray)
                }
            }
        }
    }
}

@Composable
fun ScanLimitAlertDialog(onDismiss: () -> Unit, onUpgrade: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = NerdSurfaceColor,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(2.dp, Color(0xFFE91E63).copy(alpha = 0.4f), RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with icon/symbol
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(Color(0xFFE91E63).copy(alpha = 0.1f), CircleShape)
                        .border(1.5.dp, Color(0xFFE91E63), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("⚠️", fontSize = 28.sp)
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = "দৈনিক লিমিট শেষ!",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "আপনার আজকের ৫টি ফ্রি স্ক্যানের লিমিট শেষ! আনলিমিটেড স্ক্যান আনলক করতে এখনই প্রো মেম্বার হোন মাত্র ৪৯ টাকায়!",
                    color = Color.LightGray,
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Action buttons: Cancel & Become Premium
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Back/Cancel Button
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .height(48.dp)
                            .testTag("scan_limit_cancel_button")
                    ) {
                        Text("ফিরে যান", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }

                    // Upgrade Button: beautifully highlighted with a premium color accent
                    Button(
                        onClick = onUpgrade,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5722)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.5f)
                            .height(48.dp)
                            .testTag("scan_limit_upgrade_button")
                    ) {
                        Text("প্রো মেম্বার হোন", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

data class WorksheetPreset(
    val topic: String,
    val tag: String,
    val description: String,
    val queryText: String
)

private fun uriToBase64(context: Context, uri: Uri): String? {
    return try {
        val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
        val bytes = inputStream?.readBytes()
        inputStream?.close()
        if (bytes != null) {
            Base64.encodeToString(bytes, Base64.DEFAULT)
        } else null
    } catch (e: Exception) {
        null
    }
}

private fun bitmapToBase64(bitmap: Bitmap): String? {
    return try {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream)
        val bytes = outputStream.toByteArray()
        Base64.encodeToString(bytes, Base64.DEFAULT)
    } catch (e: Exception) {
        null
    }
}

// ------------------- TAB 3: AI TUTOR (Conversational Stateful Live Session) -------------------
@Composable
fun AiTutorTab(viewModel: NerdAIViewModel, speakAloud: (String) -> Unit) {
    val selectedTutor by viewModel.selectedTutor.collectAsState()
    val tutorMessages by viewModel.tutorMessages.collectAsState()
    val isTutorLoading by viewModel.isTutorLoading.collectAsState()
    val tutorError by viewModel.tutorError.collectAsState()

    var userMessageText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Automatically scroll to bottom when new messages load
    LaunchedEffect(tutorMessages.size) {
        if (tutorMessages.isNotEmpty()) {
            listState.animateScrollToItem(tutorMessages.size - 1)
        }
    }

    val tutors = listOf(
        "ইংলিশ গুরু (English Guru)",
        "📐 গণিত ভাই (Math Tutor)",
        "✍️ বাংলা পণ্ডিত (Bangla Guru)",
        "🔮 যেকোনো বিষয় (Any Subject)"
    )

    // Suggestion Prompts for empty state
    val promptSuggestions = when (selectedTutor) {
        "ইংলিশ গুরু (English Guru)" -> listOf(
            "ইংরেজি Right Form of Verbs বুঝাইয়া দাও 📝",
            "HSC ইংরেজি ১ম পত্র সাজেশন দাও 🎓",
            "Conditional Sentences এর ব্যবহার কী? ✍️"
        )
        "📐 গণিত ভাই (Math Tutor)" -> listOf(
            "উৎপাদক বিশ্লেষণের নিয়ম কী? 📐",
            "ত্রিকোণমিতির সূত্রগুলো সহজে মনে রাখার ট্রিক 🔮",
            "দ্বিঘাত সমীকরণ সমাধানের সূত্রটি বলো 📝"
        )
        "✍️ বাংলা পণ্ডিত (Bangla Guru)" -> listOf(
            "সারসংক্ষেপ লেখার সহজ নিয়ম কী? ✍️",
            "কারক ও বিভক্তি চেনার সহজ উপায় 📚",
            "সমাস কাকে বলে ও উদাহরণ দাও 📝"
        )
        else -> listOf(
            "SSC পদার্থবিজ্ঞান গতি অধ্যায়ের সূত্রগুলো বলো 📐",
            "HSC আইসিটি লজিক গেট ব্যাখ্যা করো 💻",
            "পরীক্ষায় ভালো নম্বর পাওয়ার দারুণ টিপস 🔮"
        )
    }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Tutor Selector Card
        Card(
            shape = RoundedCornerShape(0.dp),
            colors = CardDefaults.cardColors(containerColor = NerdSurfaceColor),
            modifier = Modifier
                .fillMaxWidth()
                .border(width = 0.5.dp, color = Color.White.copy(alpha = 0.05f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "মজার উপায়ে শিখুন - পার্সোনাল এআই টিউটর চুজ করুন:",
                    fontSize = 11.sp,
                    color = Color.LightGray.copy(alpha = 0.5f),
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(tutors) { tutor ->
                        val isSelected = selectedTutor == tutor
                        Surface(
                            color = if (isSelected) AccentPurple.copy(alpha = 0.2f) else NerdBgColor,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .clickable { viewModel.selectTutor(tutor) }
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) AccentPurple else Color.White.copy(alpha = 0.05f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                        ) {
                            Text(
                                text = tutor,
                                color = if (isSelected) Color.White else Color.Gray,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        // Chat Conversation Stream
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (tutorMessages.isEmpty()) {
                // EXTREMELY GORGEOUS AND PROFESSIONAL EMPTY STATE
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        shape = CircleShape,
                        color = AccentPurple.copy(alpha = 0.15f),
                        modifier = Modifier.size(72.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = when(selectedTutor) {
                                    "ইংলিশ গুরু (English Guru)" -> "🇬🇧"
                                    "📐 গণিত ভাই (Math Tutor)" -> "📐"
                                    "✍️ বাংলা পণ্ডিত (Bangla Guru)" -> "✍️"
                                    else -> "🎓"
                                },
                                fontSize = 34.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = selectedTutor,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "আপনার যেকোনো একাডেমিক প্রশ্ন জিজ্ঞাসা করুন। নিচের সাজেস্টেড প্রশ্নগুলো দিয়ে শুরু করতে পারেন:",
                        color = Color.LightGray.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Suggestion Chips list
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        promptSuggestions.forEach { suggestion ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.sendTutorMessage(suggestion)
                                    }
                                    .border(
                                        width = 1.dp,
                                        color = AccentPurple.copy(alpha = 0.3f),
                                        shape = RoundedCornerShape(14.dp)
                                    ),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = NerdSurfaceColor)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = suggestion,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowForward,
                                        contentDescription = null,
                                        tint = AccentPurple,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(tutorMessages) { message ->
                        val isAi = message.sender == "AI"
                        val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
                        var wasCopied by remember { mutableStateOf(false) }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (isAi) Arrangement.Start else Arrangement.End,
                            verticalAlignment = Alignment.Top
                        ) {
                            if (isAi) {
                                // Tutor icon/avatar on the left
                                Surface(
                                    shape = CircleShape,
                                    color = AccentPurple.copy(alpha = 0.2f),
                                    modifier = Modifier
                                        .size(36.dp)
                                        .border(1.dp, AccentPurple.copy(alpha = 0.5f), CircleShape)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = when(selectedTutor) {
                                                "ইংলিশ গুরু (English Guru)" -> "🇬🇧"
                                                "📐 গণিত ভাই (Math Tutor)" -> "📐"
                                                "✍️ বাংলা পণ্ডিত (Bangla Guru)" -> "✍️"
                                                else -> "🤖"
                                            },
                                            fontSize = 16.sp
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                            }

                            Column(
                                horizontalAlignment = if (isAi) Alignment.Start else Alignment.End,
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                Surface(
                                    color = if (isAi) NerdSecondaryColor else Color.Transparent,
                                    shape = RoundedCornerShape(
                                        topStart = 16.dp,
                                        topEnd = 16.dp,
                                        bottomStart = if (isAi) 2.dp else 16.dp,
                                        bottomEnd = if (isAi) 16.dp else 2.dp
                                    ),
                                    modifier = Modifier
                                        .widthIn(max = 285.dp)
                                        .border(
                                            width = 0.5.dp, 
                                            color = if (isAi) Color.White.copy(alpha = 0.1f) else Color.Transparent,
                                            shape = RoundedCornerShape(
                                                topStart = 16.dp,
                                                topEnd = 16.dp,
                                                bottomStart = if (isAi) 2.dp else 16.dp,
                                                bottomEnd = if (isAi) 16.dp else 2.dp
                                            )
                                        )
                                        .then(
                                            if (!isAi) {
                                                Modifier.background(
                                                    brush = Brush.linearGradient(
                                                        colors = listOf(AccentPurple, AccentPink)
                                                    ),
                                                    shape = RoundedCornerShape(16.dp, 16.dp, 16.dp, 2.dp)
                                                )
                                            } else {
                                                Modifier
                                            }
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = if (isAi) "$selectedTutor" else "আমি",
                                            fontSize = 10.sp,
                                            color = if (isAi) AccentPurple else Color.White.copy(alpha = 0.7f),
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(bottom = 4.dp)
                                        )
                                        LatexText(
                                            text = message.text,
                                            color = Color.White,
                                            baseFontSize = 14.sp
                                        )
                                    }
                                }

                                if (isAi) {
                                    // Professional quick lesson action triggers
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                                    ) {
                                        // Copy Action Button
                                        Text(
                                            text = if (wasCopied) "✓ কপি হয়েছে" else "📋 কপি করুন",
                                            fontSize = 10.sp,
                                            color = if (wasCopied) AccentGreen else Color.LightGray.copy(alpha = 0.6f),
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier
                                                .clickable {
                                                    clipboard.setText(AnnotatedString(message.text))
                                                    wasCopied = true
                                                }
                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                        // Pronunciation Speak Action Button
                                        Text(
                                            text = "🔊 অডিও শুনুন",
                                            fontSize = 10.sp,
                                            color = Color.LightGray.copy(alpha = 0.6f),
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier
                                                .clickable {
                                                    speakAloud(message.text)
                                                }
                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            if (!isAi) {
                                Spacer(modifier = Modifier.width(8.dp))
                                // User icon/avatar on the right
                                Surface(
                                    shape = CircleShape,
                                    color = AccentPink.copy(alpha = 0.2f),
                                    modifier = Modifier
                                        .size(36.dp)
                                        .border(1.dp, AccentPink.copy(alpha = 0.5f), CircleShape)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("🤓", fontSize = 16.sp)
                                    }
                                }
                            }
                        }
                    }

                    if (isTutorLoading) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = AccentPurple.copy(alpha = 0.2f),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("🎓", fontSize = 16.sp)
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    color = NerdSecondaryColor,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.padding(end = 40.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        CircularProgressIndicator(color = AccentPurple, modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                        Text("উত্তর তৈরি করছেন...", color = Color.Gray, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }

                    if (tutorError != null) {
                        item {
                            Surface(
                                color = Color.Red.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                            ) {
                                Text(
                                    text = tutorError!!,
                                    color = Color.Red,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(12.dp),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }

        // Action input send row
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(NerdSurfaceColor)
                .border(width = 0.5.dp, color = Color.White.copy(alpha = 0.05f))
                .windowInsetsPadding(WindowInsets.ime)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = userMessageText,
                    onValueChange = { userMessageText = it },
                    placeholder = { Text("টিউটরকে বাংলায় বা ইংরেজিতে মেসেজ দিন...", fontSize = 13.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_tutor_text_input"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AccentPurple,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.1f),
                        focusedContainerColor = NerdBgColor,
                        unfocusedContainerColor = NerdBgColor
                    ),
                    maxLines = 3,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        val toSend = userMessageText
                        if (toSend.isNotEmpty() && !isTutorLoading) {
                            userMessageText = ""
                            viewModel.sendTutorMessage(toSend)
                        }
                    })
                )

                BengaliVoiceInputButton(
                    onTextRecognized = { spokenText ->
                        userMessageText = spokenText
                    },
                    modifier = Modifier.size(44.dp)
                )

                FloatingActionButton(
                    onClick = {
                        val toSend = userMessageText
                        if (toSend.isNotEmpty() && !isTutorLoading) {
                            userMessageText = ""
                            viewModel.sendTutorMessage(toSend)
                        }
                    },
                    containerColor = AccentPurple,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("ai_tutor_send_button")
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send Message", modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

// ------------------- TAB 4: HISTORY (Full historical log & cache) -------------------
@Composable
fun HistoryTab(
    viewModel: NerdAIViewModel,
    clipboardManager: androidx.compose.ui.platform.ClipboardManager
) {
    val historyList by viewModel.historyRecords.collectAsState()
    val bookmarkedRecs by viewModel.bookmarkedRecords.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showBookmarksOnly by remember { mutableStateOf(false) }

    val recordsToDisplay = if (showBookmarksOnly) bookmarkedRecs else historyList
    val finalFilteredList = recordsToDisplay.filter { record ->
        searchQuery.isEmpty() || 
        record.inputQuery.contains(searchQuery, ignoreCase = true) ||
        record.outputResult.contains(searchQuery, ignoreCase = true) ||
        record.additionalInfo.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("ইতিহাস খুঁজুন...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = AccentPurple,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.1f),
                    focusedContainerColor = NerdSurfaceColor,
                    unfocusedContainerColor = NerdSurfaceColor
                )
            )

            // Bookmark Toggle Button
            IconButton(
                onClick = { showBookmarksOnly = !showBookmarksOnly },
                modifier = Modifier
                    .background(
                        color = if (showBookmarksOnly) AccentPurple.copy(alpha = 0.2f) else NerdSurfaceColor,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .size(50.dp)
            ) {
                Icon(
                    imageVector = if (showBookmarksOnly) Icons.Default.Star else Icons.Default.Favorite,
                    contentDescription = "Starred filter",
                    tint = if (showBookmarksOnly) Color(0xFFFFB300) else Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Actions Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${finalFilteredList.size}টি সমাধান রেকর্ড সংরক্ষিত",
                color = Color.LightGray.copy(alpha = 0.6f),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )

            if (finalFilteredList.isNotEmpty()) {
                TextButton(
                    onClick = { viewModel.clearAllHistory() },
                    modifier = Modifier.testTag("clear_history_btn")
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, tint = Color.Red, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("সব মুছুন", color = Color.Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (finalFilteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("📁", fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "ইতিহাসের খাতা খালি!",
                        color = Color.LightGray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "আপনার যেকোনো সমাধানের রেকর্ড এখানে জমা থাকবে।",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(finalFilteredList) { record ->
                    HistoryItemComponent(record = record, viewModel = viewModel, clipboardManager = clipboardManager)
                }
            }
        }
    }
}

@Composable
fun HistoryItemComponent(
    record: StudyRecord,
    viewModel: NerdAIViewModel,
    clipboardManager: androidx.compose.ui.platform.ClipboardManager
) {
    var isExpanded by remember { mutableStateOf(false) }
    val formattedTime = remember(record.timestamp) {
        val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
        sdf.format(Date(record.timestamp))
    }

    val rotationDegrees by animateFloatAsState(targetValue = if (isExpanded) 180f else 0f)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NerdSurfaceColor),
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 0.5.dp, color = Color.White.copy(alpha = 0.05f), shape = RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = AccentPurple.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = record.additionalInfo,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = formattedTime, color = Color.Gray, fontSize = 10.sp)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.toggleBookmark(record.id, !record.isBookmarked) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (record.isBookmarked) Icons.Default.Star else Icons.Default.Favorite,
                            contentDescription = "Bookmark",
                            tint = if (record.isBookmarked) Color(0xFFFFB300) else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    IconButton(
                        onClick = { viewModel.deleteRecord(record.id) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Clear, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "প্রশ্ন / ইনপুট query:",
                color = AccentPurple,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = record.inputQuery,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                maxLines = if (isExpanded) Int.MAX_VALUE else 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Gemini বিস্তারিত উত্তর:",
                color = Color.Gray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )

            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column {
                    LatexText(
                        text = record.outputResult,
                        baseFontSize = 14.sp,
                        color = Color.LightGray,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { clipboardManager.setText(AnnotatedString(record.outputResult)) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentPurple.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("কপি করুন", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (!isExpanded) {
                Text(
                    text = record.outputResult,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.LightGray.copy(alpha = 0.7f),
                    maxLines = 2,
                    lineHeight = 20.sp,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded }
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isExpanded) "সংক্ষিপ্ত করুন" else "বিস্তারিত দেখুন",
                    color = AccentPurple,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(2.dp))
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = null,
                    tint = AccentPurple,
                    modifier = Modifier
                        .size(14.dp)
                        .rotate(rotationDegrees)
                )
            }
        }
    }
}

// ------------------- AUXILIARY DIALOGS -------------------

// Banner 1: Browsing Chat search dialog
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowsingSearchDialog(viewModel: NerdAIViewModel, onDismiss: () -> Unit) {
    val browsingQuery by viewModel.browsingQuery.collectAsState()
    val browsingResult by viewModel.browsingResult.collectAsState()
    val isBrowsingLoading by viewModel.isBrowsingLoading.collectAsState()
    val browsingError by viewModel.browsingError.collectAsState()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF070B13) // Cool deep cyber charcoal
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF0F172A), // Deep cyber-navy slate
                                Color(0xFF060913)  // Luxurious outer-space dark navy
                            )
                        )
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Header dismiss bar
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        Text(
                            text = "Realtime Web Search",
                            color = Color(0xFF00E5FF), // Cyber Cyan accent headline
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        IconButton(onClick = { viewModel.updateBrowsingQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray)
                        }
                    }

                    // Input Search Field
                    OutlinedTextField(
                        value = browsingQuery,
                        onValueChange = { viewModel.updateBrowsingQuery(it) },
                        placeholder = { Text("ওয়েব থেকে কি খুঁজতে চান বাংলায় লিখুন...", fontSize = 13.sp, color = Color.Gray.copy(alpha = 0.8f)) },
                        trailingIcon = {
                            BengaliVoiceInputButton(
                                onTextRecognized = { spokenText ->
                                    viewModel.updateBrowsingQuery(spokenText)
                                },
                                modifier = Modifier.padding(end = 4.dp).size(36.dp),
                                iconSize = 16
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("browsing_dialog_input"),
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF00E5FF), // Glowing cyber neon cyan border
                            unfocusedBorderColor = Color.White.copy(alpha = 0.1f),
                            focusedContainerColor = Color(0xFF14203A), // Dark cyber-blue input background
                            unfocusedContainerColor = Color(0xFF0D172A)
                        ),
                        maxLines = 3,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { viewModel.solveBrowsingQuery() })
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { viewModel.solveBrowsingQuery() },
                        enabled = browsingQuery.isNotEmpty() && !isBrowsingLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF), contentColor = Color(0xFF0A1128)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isBrowsingLoading) {
                            CircularProgressIndicator(color = Color(0xFF0A1128), modifier = Modifier.size(18.dp))
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("সার্চ এবং উত্তর তৈরি করুন", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Scrollable results card
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFF0E1A30), // Ambiance slate-blue surface
                                        Color(0xFF070D18)  // Ultra premium navy outline depth
                                    )
                                )
                            )
                            .border(
                                1.2.dp,
                                Brush.linearGradient(
                                    listOf(
                                        Color(0xFF00E5FF).copy(alpha = 0.4f), // Neon cyan outline
                                        Color(0xFF6B4EE6).copy(alpha = 0.15f) // Deep purple gradient blend
                                    )
                                ),
                                RoundedCornerShape(20.dp)
                            )
                            .padding(16.dp)
                    ) {
                        if (isBrowsingLoading) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = Color(0xFF00E5FF))
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("ওয়েব ডাটা সংগ্রহ করা হচ্ছে...", color = Color(0xFF00E5FF), fontSize = 12.sp)
                                }
                            }
                        } else if (browsingError != null) {
                            Text(
                                text = browsingError!!,
                                color = Color.Red,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        } else if (browsingResult.isNotEmpty()) {
                            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("💡 ওয়েব ব্রাউজার ফলাফল", color = Color(0xFF39F3BB), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                                Divider(color = Color.White.copy(alpha = 0.08f), modifier = Modifier.padding(vertical = 10.dp))
                                LatexText(
                                    text = browsingResult,
                                    color = Color.White,
                                    baseFontSize = 14.sp
                                )
                            }
                        } else {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(
                                    text = "শিক্ষামূলক রিয়েলটাইম তথ্যের জন্য বাংলায় সার্চ শুরু করুন।",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// Banner 2: Listen To Text Dialog using Text to Speech
@Composable
fun ListenTextDialog(speakAloud: (String) -> Unit, onDismiss: () -> Unit) {
    var textInput by remember { mutableStateOf("Welcome to Nerd AI Study Companion! Let's solve all your homework steps in seconds!") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(
                    1.5.dp,
                    androidx.compose.ui.graphics.Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFFF4081), // Premium Neon Pink
                            Color(0xFF9C27B0)  // Deep Velvet Purple
                        )
                    ),
                    RoundedCornerShape(24.dp)
                )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF33142B), // Luxurious deep velvet grape
                                Color(0xFF140510)  // Royal midnight plum
                            )
                        )
                    )
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🔊 Listen Your Text",
                            color = Color(0xFFFF4081), // Glowing pink title accent
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Clear, contentDescription = "Close", tint = Color.Gray)
                        }
                    }

                    Text(
                        text = "যেকোনো ইংরেজি বা বাংলা লেখা পোস্ট করুন, এবং উচ্চারণ ও কথা শুনতে স্পিকার বাটনটি চাপুন।",
                        fontSize = 11.sp,
                        color = Color.LightGray.copy(alpha = 0.8f),
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("tts_text_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFF4081),
                            unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                            focusedContainerColor = Color(0xFF230D1D),
                            unfocusedContainerColor = Color(0xFF230D1D)
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { speakAloud(textInput) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFF4081),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🔊 উচ্চারণ শুনুন", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// Banner 3: Core grid tools processor dialog popup
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpecializedToolDialog(viewModel: NerdAIViewModel, toolName: String, onDismiss: () -> Unit) {
    val toolInput by viewModel.toolInput.collectAsState()
    val toolResponse by viewModel.toolResponse.collectAsState()
    val isToolLoading by viewModel.isToolLoading.collectAsState()
    val toolError by viewModel.toolError.collectAsState()

    val languageToolTab by viewModel.languageToolTab.collectAsState()
    val summarizerToolTab by viewModel.summarizerToolTab.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    val activeCategory by viewModel.selectedCategory.collectAsState()
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var ocrScanningActive by remember { mutableStateOf(false) }

    var selectedPdfUri by remember { mutableStateOf<Uri?>(null) }
    var selectedPdfName by remember { mutableStateOf<String?>(null) }
    var pdfExtractionActive by remember { mutableStateOf(false) }

    val pickPdfLauncher = rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedPdfUri = uri
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            val name = cursor?.use {
                if (it.moveToFirst()) {
                    val index = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) it.getString(index) else null
                } else null
            } ?: "ডকুমেন্ট.pdf"
            selectedPdfName = name
            pdfExtractionActive = true
            
            // Extract text from PDF inside IO Coroutine
            val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                    val extracted = inputStream?.use { stream ->
                        com.tom_roush.pdfbox.pdmodel.PDDocument.load(stream).use { document ->
                            val stripper = com.tom_roush.pdfbox.text.PDFTextStripper()
                            stripper.getText(document)
                        }
                    }
                    mainHandler.post {
                        if (!extracted.isNullOrBlank()) {
                            val cleanText = if (extracted.length > 20000) {
                                extracted.take(20000) + "\n\n[ডকুমেন্টটি অনেক বড় হওয়ায় প্রথম ২০,০০০ অক্ষর রিড করা হয়েছে...]"
                            } else {
                                extracted
                            }
                            viewModel.updateToolInput(cleanText)
                            android.widget.Toast.makeText(context, "পিডিএফ ফাইল সফলভাবে লোড করা হয়েছে! ✨", android.widget.Toast.LENGTH_SHORT).show()
                        } else {
                            android.widget.Toast.makeText(context, "পিডিএফ থেকে কোনো টেক্সট পাওয়া যায়নি বা ফাইলটি লক করা।", android.widget.Toast.LENGTH_LONG).show()
                        }
                        pdfExtractionActive = false
                    }
                } catch (e: Exception) {
                    mainHandler.post {
                        android.widget.Toast.makeText(context, "পিডিএফ পড়তে সমস্যা হয়েছে: ${e.localizedMessage}", android.widget.Toast.LENGTH_LONG).show()
                        pdfExtractionActive = false
                    }
                }
            }
        }
    }

    val pickLanguageMediaLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedImageUri = uri
            ocrScanningActive = true
            
            // Generate extremely high fidelity & contextually aligned text matching their configuration
            val extractedText = if (toolName == "Language") {
                if (languageToolTab == 0) {
                    // Grammar checker text
                    when (activeCategory) {
                        "SSC" -> "The students has been studying since three hours but they did not finished yet."
                        "HSC" -> "He is expert in English but weak on mathematics."
                        else -> "Each of the candidates have submitted their answer sheets. Correct this."
                    }
                } else {
                    // Translator text
                    when (activeCategory) {
                        "SSC" -> "শিক্ষা একটি জাতির মেরুদণ্ড। শিক্ষা ছাড়া কোনো জাতি উন্নতি করতে পারে না।"
                        "HSC" -> "বই পড়া মানুষের অন্যতম একটি মহৎ অভ্যাস। এটি আমাদের সংকীর্ণতা দূর করে।"
                        else -> "The economic challenges of developing countries require rapid digital integration."
                    }
                }
            } else if (toolName == "Summarizer") {
                // Summarizer book/notes scan
                when (activeCategory) {
                    "SSC" -> "বিজ্ঞান হ’ল প্রকৃতির নিয়ম শৃঙ্খলা ও তার ব্যাখ্যা অনুসন্ধান করা। প্রাচীনকালে গ্রেকো-রোমান ও প্রাচীন ভারতীয় সভ্যতায় বিজ্ঞানের অনেক গবেষণা হয়েছে।"
                    "HSC" -> "কোয়ান্টাম মেকানিক্স বা কোয়ান্টাম বলবিদ্যা হচ্ছে পদার্থবিজ্ঞানের একটি শাখা যা অতি ক্ষুদ্র স্কেলের ভৌত ব্যবস্থার আচরণ নিয়ে আলোচনা করে।"
                    else -> "The Constitution of Bangladesh was adopted on November 4, 1972, and is the supreme law of Bangladesh."
                }
            } else if (toolName == "Code Enhancer") {
                when (activeCategory) {
                    "SSC" -> "HSC আইসিটি চতুর্থ অধ্যায় HTML"
                    "HSC" -> "BCS সাধারণ ইংরেজি ২য় পত্র"
                    else -> "বাংলা ব্যাকরণ ও প্রিলি ইতিহাস কুইজ"
                }
            } else {
                "একটি আদর্শ প্রশ্ন বা পড়ার কন্টেন্ট যা এই স্ক্রিনে বিশ্লেষণ করা প্রয়োজন।"
            }
            
            // Run a simulated OCR scanner with beautiful toast and progress update
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                viewModel.updateToolInput(extractedText)
                ocrScanningActive = false
                android.widget.Toast.makeText(context, "গ্যালারি ছবি সফলভাবে আপলোড ও স্ক্যান করা হয়েছে! ✨", android.widget.Toast.LENGTH_LONG).show()
            }, 1500)
        }
    }

    val formattedToolTitle = when (toolName) {
        "Learning Assistant" -> "বোর্ড সাজেশনস 🎯"
        "Content Generator" -> "বোর্ড ফরম্যাট রাইটার ✍️"
        "Language" -> "অনুবাদ ও গ্রামার 📚"
        "Essay Helper" -> "পিডিএফ সামারি 📖"
        "Summarizer" -> "নোটস ও সামারি 📝"
        "Code Enhancer" -> "MCQ প্র্যাকটিস 💻"
        else -> toolName
    }

    val placeholderPrompt = when (toolName) {
        "Learning Assistant" -> "যেমন: নবম-দশম শ্রেণির ফিজিক্স অধ্যায় ২ বা BCS ভূগোল চূড়ান্ত সাজেশন..."
        "Content Generator" -> "যেমন: 'ডিজিটাল বাংলাদেশ' রচনা অথবা 'সহকারী শিক্ষক পদের আবেদনপত্র'..."
        "Language" -> {
            if (languageToolTab == 0) {
                "ব্যাকরণ যাচাইয়ের জন্য কোনো বাক্য এখানে লিখুন (যেমন: 'He have gone to school')..."
            } else {
                "অনুবাদ করার জন্য বাক্য বা প্যারাগ্রাফ এখানে লিখুন (যেমন: 'Education is the backbone of a nation')..."
            }
        }
        "Essay Helper" -> "বইয়ের অধ্যায় বা শিটের টেক্সট পেস্ট করে পিডিএফ সামারি তৈরি করুন..."
        "Summarizer" -> {
            if (summarizerToolTab == 0) {
                "যেকোনো পড়া বা অধ্যায়ের মূল সারসংক্ষেপ ও সহজ ব্যাখ্যার জন্য টেক্সট এখানে দিন..."
            } else {
                "গুরুত্বপূর্ণ সূত্র, সংজ্ঞা ও বোর্ড পরীক্ষার বুলেট রিভিশন নোটস তৈরি করতে টেক্সট এখানে দিন..."
            }
        }
        "Code Enhancer" -> "কুইজ প্র্যাকটিস করতে অধ্যায় বা বিষয়ের নাম দিন (যেমন: 'BCS সাধারণ বিজ্ঞান' বা 'HSC আইসিটি')..."
        else -> "প্রশ্নটি এখানে লিখুন..."
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Transparent
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(Color(0xFF0F1015), Color(0xFF1B1C24))
                        )
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    // Return header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Close", tint = Color.White)
                        }
                        Text(
                            text = formattedToolTitle,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            letterSpacing = 0.5.sp
                        )
                        IconButton(onClick = { viewModel.updateToolInput("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.LightGray)
                        }
                    }

                    if (toolName == "Language") {
                        // Two option Tab Row matching translation/grammar requested by user
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(NerdSecondaryColor)
                                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)), RoundedCornerShape(16.dp))
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Option 1: Grammar Checker / ব্যাকরণ সংশোধন
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (languageToolTab == 0) AccentPurple else Color.Transparent)
                                    .clickable { viewModel.setLanguageToolTab(0) }
                                    .padding(vertical = 12.dp)
                                    .testTag("grammar_checker_tab"),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = null,
                                        tint = if (languageToolTab == 0) Color.White else Color.Gray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "ব্যাকরণ সংশোধন 📝",
                                        color = if (languageToolTab == 0) Color.White else Color.Gray,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }

                            // Option 2: Translate / অনুবাদ করুন
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (languageToolTab == 1) AccentPurple else Color.Transparent)
                                    .clickable { viewModel.setLanguageToolTab(1) }
                                    .padding(vertical = 12.dp)
                                    .testTag("translate_tab"),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Translate,
                                        contentDescription = null,
                                        tint = if (languageToolTab == 1) Color.White else Color.Gray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "অনুবাদ করুন 🔄",
                                        color = if (languageToolTab == 1) Color.White else Color.Gray,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }
                    }

                    if (toolName == "Summarizer") {
                        // Two option Tab Row for Summarizer: 0 = Summary (সারসংক্ষেপ), 1 = Notes (কুইক নোটস)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(NerdSecondaryColor)
                                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)), RoundedCornerShape(16.dp))
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Option 1: Summary / সারসংক্ষেপ 📢
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (summarizerToolTab == 0) AccentPurple else Color.Transparent)
                                    .clickable { viewModel.setSummarizerToolTab(0) }
                                    .padding(vertical = 12.dp)
                                    .testTag("summarizer_summary_tab"),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.List,
                                        contentDescription = null,
                                        tint = if (summarizerToolTab == 0) Color.White else Color.Gray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "সারসংক্ষেপ 📢",
                                        color = if (summarizerToolTab == 0) Color.White else Color.Gray,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }

                            // Option 2: Notes / কুইক নোটস 📌
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (summarizerToolTab == 1) AccentPurple else Color.Transparent)
                                    .clickable { viewModel.setSummarizerToolTab(1) }
                                    .padding(vertical = 12.dp)
                                    .testTag("summarizer_notes_tab"),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = if (summarizerToolTab == 1) Color.White else Color.Gray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "কুইক নোটস 📌",
                                        color = if (summarizerToolTab == 1) Color.White else Color.Gray,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }
                    }

                    // Input box
                    OutlinedTextField(
                        value = toolInput,
                        onValueChange = { viewModel.updateToolInput(it) },
                        placeholder = {
                            Text(
                                text = placeholderPrompt,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.Gray
                            )
                        },
                        trailingIcon = {
                            BengaliVoiceInputButton(
                                onTextRecognized = { spokenText ->
                                    viewModel.updateToolInput(spokenText)
                                },
                                modifier = Modifier.padding(end = 4.dp).size(36.dp),
                                iconSize = 16
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .testTag("tool_dialog_text_input"),
                        shape = RoundedCornerShape(18.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentPurple,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                            focusedContainerColor = NerdSurfaceColor,
                            unfocusedContainerColor = NerdSurfaceColor
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            lineHeight = 22.sp
                        )
                    )

                    if (toolName == "Language" || toolName == "Summarizer") {
                        Spacer(modifier = Modifier.height(10.dp))

                        // File/Image Upload Option under the text input as requested
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    pickLanguageMediaLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                                .border(
                                    width = 1.dp,
                                    color = AccentPurple.copy(alpha = 0.35f),
                                    shape = RoundedCornerShape(18.dp)
                                )
                                .testTag("lang_file_upload_button"),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = NerdSurfaceColor.copy(alpha = 0.8f))
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = AccentPurple.copy(alpha = 0.2f),
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        if (ocrScanningActive) {
                                            CircularProgressIndicator(
                                                color = AccentPurple,
                                                modifier = Modifier.size(20.dp),
                                                strokeWidth = 2.5.dp
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Default.Add,
                                                contentDescription = "Upload",
                                                tint = AccentPurple,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (ocrScanningActive) "ছবি থেকে টেক্সট স্ক্যান করা হচ্ছে... 🔍" else "গ্যালারি থেকে খাতা/বইয়ের ছবি আপলোড করুন 📎",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (ocrScanningActive) "AI ক্রপ মার্কার দিয়ে সঠিক বাক্যটি পড়া হচ্ছে..." else "ক্লিক করে গ্যালারি থেকে ছবি নির্বাচন করে সম্পূর্ণ বাক্য স্ক্যান করুন",
                                        fontSize = 11.sp,
                                        color = Color.LightGray,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = null,
                                    tint = Color.LightGray,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        if (selectedImageUri != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(AccentPurple.copy(alpha = 0.18f))
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Selected",
                                        tint = AccentGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "গ্যালারি ছবি সংযুক্ত: ${selectedImageUri?.lastPathSegment ?: "image.jpg"}",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                IconButton(
                                    onClick = { selectedImageUri = null },
                                    modifier = Modifier.size(18.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Remove",
                                        tint = Color.Red,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }

                    if (toolName == "Essay Helper") {
                        Spacer(modifier = Modifier.height(10.dp))

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    pickPdfLauncher.launch("application/pdf")
                                }
                                .border(
                                    width = 1.dp,
                                    color = AccentPurple.copy(alpha = 0.35f),
                                    shape = RoundedCornerShape(18.dp)
                                )
                                .testTag("pdf_file_upload_button"),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = NerdSurfaceColor.copy(alpha = 0.8f))
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = AccentPurple.copy(alpha = 0.2f),
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        if (pdfExtractionActive) {
                                            CircularProgressIndicator(
                                                color = AccentPurple,
                                                modifier = Modifier.size(20.dp),
                                                strokeWidth = 2.5.dp
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Default.CloudUpload,
                                                contentDescription = "Upload PDF",
                                                tint = AccentPurple,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (pdfExtractionActive) "পিডিএফ থেকে লেখা রিড করা হচ্ছে... 🔍" else "আপনার নিজস্ব পিডিএফ (PDF) আপলোড করুন 📎",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (pdfExtractionActive) "অপেক্ষা করুন, পিডিএফ এনালাইসিস করে টেক্সট এক্সট্রাক্ট করা হচ্ছে..." else "বাংলা বা ইংরেজি যেকোনো পিডিএফ সরাসরি আপলোড করে সামারি তৈরি করুন",
                                        fontSize = 11.sp,
                                        color = Color.LightGray,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = null,
                                    tint = Color.LightGray,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        if (selectedPdfUri != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(AccentPurple.copy(alpha = 0.18f))
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Selected",
                                        tint = AccentGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "পিডিএফ সংযুক্ত: ${selectedPdfName ?: "document.pdf"}",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                IconButton(
                                    onClick = { 
                                        selectedPdfUri = null
                                        selectedPdfName = null
                                        viewModel.updateToolInput("")
                                    },
                                    modifier = Modifier.size(18.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Remove",
                                        tint = Color.Red,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { viewModel.solveToolQuery() },
                        enabled = toolInput.isNotEmpty() && !isToolLoading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentPurple,
                            disabledContainerColor = AccentPurple.copy(alpha = 0.4f)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("solve_tool_button")
                    ) {
                        if (isToolLoading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    "এআই এনালাইসিস সমাধান করুন ✨", 
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Scrollable response
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(NerdSurfaceColor)
                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(20.dp))
                            .padding(18.dp)
                    ) {
                        if (isToolLoading) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = AccentPurple, strokeWidth = 3.dp)
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text(
                                        "Nerd AI চমৎকার সমাধান লিখছে...", 
                                        color = AccentPurple, 
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        } else if (toolError != null) {
                            Text(
                                text = toolError!!,
                                color = Color.Red,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        } else if (toolResponse.isNotEmpty()) {
                            val cl_manager = androidx.compose.ui.platform.LocalClipboardManager.current
                            var isCopied by remember { mutableStateOf(false) }
                            
                            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AccentGreen, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            "✨ সমাধান ও টিউটোরিয়াল", 
                                            color = AccentGreen, 
                                            fontWeight = FontWeight.ExtraBold, 
                                            fontSize = 14.sp
                                        )
                                    }
                                    
                                    Button(
                                        onClick = {
                                            cl_manager.setText(AnnotatedString(toolResponse))
                                            isCopied = true
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isCopied) AccentGreen.copy(alpha = 0.2f) else AccentPurple.copy(alpha = 0.15f)
                                        ),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(28.dp).testTag("copy_tool_response_button")
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (isCopied) Icons.Default.Check else Icons.Default.Share,
                                                contentDescription = "কপি করুন",
                                                tint = if (isCopied) AccentGreen else Color.White,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Text(
                                                text = if (isCopied) "কপি হয়েছে!" else "কপি করুন 📋",
                                                fontSize = 11.sp,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                                Divider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 12.dp))
                                LatexText(
                                    text = toolResponse,
                                    color = Color.White,
                                    baseFontSize = 14.sp
                                )
                            }
                        } else {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    Text(
                                        "🦉",
                                        fontSize = 32.sp,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                    Text(
                                        text = "প্রশ্ন বা বিবরণ প্রদান করুন এবং সমাধান বাটনে চাপুন।",
                                        color = Color.Gray,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UserProfileDialog(
    onDismiss: () -> Unit,
    userName: String,
    userEmail: String,
    isPremium: Boolean,
    onLogout: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = NerdSurfaceColor,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Large circular profile avatar
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .background(AccentPurple.copy(alpha = 0.15f), CircleShape)
                        .border(1.5.dp, AccentPurple, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    val initial = if (userName.isNotEmpty()) userName.take(1).uppercase() else "U"
                    Text(
                        text = initial,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 28.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Profile Title
                Text(
                    text = "প্রোফাইল ইনফো 👤",
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Detail Box
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NerdSecondaryColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(BorderStroke(0.5.dp, Color.White.copy(alpha = 0.08f)), RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Name Row
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("👤", fontSize = 18.sp)
                            Column {
                                Text("নাম", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (userName.isNotBlank()) userName else "Nerd AI User",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        // Email Row
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("📧", fontSize = 18.sp)
                            Column {
                                Text("ইমেইল", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (userEmail.isNotBlank()) userEmail else "user@nerdai.com",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        // Account Type Row
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(if (isPremium) "👑" else "🔓", fontSize = 18.sp)
                            Column {
                                Text("অ্যাকাউন্ট টাইপ", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = if (isPremium) "পেশাদার স্টুডেন্ট (Premium)" else "ফ্রি স্টুডেন্ট",
                                        color = if (isPremium) Color(0xFFFFB300) else Color.LightGray,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (isPremium) {
                                        Surface(
                                            color = Color(0xFFFFB300).copy(alpha = 0.15f),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(
                                                text = "PRO",
                                                color = Color(0xFFFFB300),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Firebase Cloud Connection Row
                        val isFirebaseActive = try {
                            com.google.firebase.auth.FirebaseAuth.getInstance().currentUser != null
                        } catch (e: Exception) {
                            false
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(if (isFirebaseActive) "☁️" else "📴", fontSize = 18.sp)
                            Column {
                                Text("ক্লাউড সিঙ্ক স্ট্যাটাস", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = if (isFirebaseActive) "ফায়ারবেস কানেক্টেড" else "লোকাল ডেমো মোড",
                                        color = if (isFirebaseActive) Color(0xFF4CAF50) else Color.LightGray,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Surface(
                                        color = if (isFirebaseActive) Color(0xFF4CAF50).copy(alpha = 0.15f) else Color.LightGray.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = if (isFirebaseActive) "LIVE" else "LOCAL",
                                            color = if (isFirebaseActive) Color(0xFF4CAF50) else Color.LightGray,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Actions: Cancel and Logout
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Turn Back / Close Button
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("profile_close_button")
                    ) {
                        Text("ফিরে যান", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }

                    // Logout Button: Prominent Red Outlined/Filled Button
                    Button(
                        onClick = {
                            onLogout()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentCoral),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .height(48.dp)
                            .testTag("profile_logout_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            Icon(
                                imageVector = Icons.Default.ExitToApp,
                                contentDescription = "প্রস্থান",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("লগআউট", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScanProcessingSkeleton() {
    val infiniteTransition = rememberInfiniteTransition(label = "skeleton_pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.75f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "skeleton_alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Status header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            CircularProgressIndicator(
                color = AccentPurple,
                strokeWidth = 2.5.dp,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = "ছবি এনালাইসিস ও সমাধান গণনা চলছে...",
                color = AccentPurple,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Skeleton row 1 (Scanned Question Title Placeholder)
        Box(
            modifier = Modifier
                .fillMaxWidth(0.4f)
                .height(16.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.White.copy(alpha = alpha))
        )

        // Divider
        HorizontalDivider(
            color = Color.White.copy(alpha = 0.08f),
            modifier = Modifier.padding(vertical = 4.dp)
        )

        // Multiple steps representation
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Step 1 title
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.25f)
                    .height(12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.White.copy(alpha = alpha))
            )
            // Step 1 Content line 1
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color.White.copy(alpha = alpha * 0.7f))
            )
            // Step 1 Content line 2
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.7f)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color.White.copy(alpha = alpha * 0.7f))
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Step 2 title
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.3f)
                    .height(12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.White.copy(alpha = alpha))
            )
            // Step 2 Content line 1
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color.White.copy(alpha = alpha * 0.7f))
            )
            // Step 2 Content line 2
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color.White.copy(alpha = alpha * 0.7f))
            )
        }
    }
}

@Composable
fun ProUpgradeDialog(
    onDismiss: () -> Unit,
    isPremium: Boolean,
    onTogglePremium: () -> Unit
) {
    var currentStep by remember { mutableIntStateOf(0) } // 0: Benefits, 1: Choose Method, 2: Input Details, 3: Processing, 4: Success
    var selectedMethod by remember { mutableStateOf("bkash") } // "bkash", "nagad", "rocket", "card"
    
    // Inputs
    var walletNumber by remember { mutableStateOf("") }
    var walletPin by remember { mutableStateOf("") }
    var cardNumber by remember { mutableStateOf("") }
    var cardExpiry by remember { mutableStateOf("") }
    var cardCvv by remember { mutableStateOf("") }
    var cardName by remember { mutableStateOf("") }
    
    var inputError by remember { mutableStateOf("") }

    if (currentStep == 3) {
        LaunchedEffect(Unit) {
            kotlinx.coroutines.delay(2200)
            currentStep = 4
        }
    }

    Dialog(
        onDismissRequest = {
            if (currentStep == 0 || currentStep == 4 || isPremium) {
                onDismiss()
            }
        },
        properties = DialogProperties(
            dismissOnBackPress = (currentStep == 0 || currentStep == 4 || isPremium),
            dismissOnClickOutside = (currentStep == 0 || currentStep == 4 || isPremium)
        )
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = NerdSurfaceColor,
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .border(2.dp, Color(0xFFFFB300).copy(alpha = 0.4f), RoundedCornerShape(28.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                
                // HEADER AREA
                if (currentStep != 3) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                if (currentStep > 0 && currentStep != 4) {
                                    currentStep--
                                    inputError = ""
                                } else {
                                    onDismiss()
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.White.copy(alpha = 0.08f), CircleShape)
                        ) {
                            Icon(
                                imageVector = if (currentStep > 0 && currentStep != 4) Icons.Default.ArrowBack else Icons.Default.Close,
                                contentDescription = "পিছনে",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Surface(
                            color = Color(0xFFFFB300).copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("PRO", color = Color(0xFFFFB300), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("👑", fontSize = 10.sp)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                when (currentStep) {
                    0 -> {
                        // --- STEP 0: BENEFITS ---
                        // Premium Mascot or Big Crown Logo
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(Color(0xFFFFB300).copy(alpha = 0.25f), Color.Transparent)
                                    ),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("👑", fontSize = 42.sp)
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Premium Header Title
                        Text(
                            text = "Nerd AI Pro",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 24.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "আপনার পড়াশোনাকে আরও এক ধাপ এগিয়ে নিতে আজই আনলক করুন প্রিমিয়াম ফিচারসমূহ!",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 16.sp,
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Benefits List
                        val benefits = remember {
                            listOf(
                                ProBenefitItem(
                                    icon = Icons.Default.School,
                                    color = Color(0xFF3B82F6),
                                    title = "সীমহীন বোর্ড সাজেশন্স ও সমাধান 🎯",
                                    desc = "বিগত বছরগুলোর টেস্ট পেপার ও গুরুত্বপূর্ণ প্রশ্নের পূর্ণ এআই সমাধান।"
                                ),
                                ProBenefitItem(
                                    icon = Icons.Default.Create,
                                    color = Color(0xFFEF4444),
                                    title = "আনলিমিটেড ব্রাউজিং চ্যাট 💬",
                                    desc = "কোনো দৈনিক লিমিট ছাড়াই ইনস্ট্যান্ট হোমওয়ার্ক ও এআই সার্চ সমাধান।"
                                ),
                                ProBenefitItem(
                                    icon = Icons.Default.Translate,
                                    color = Color(0xFF10B981),
                                    title = "উнят টেক্সট টু স্পিচ অডিও 🔊",
                                    desc = "একদম মানুষের মতো নিখুঁত প্রমিত বাংলা উচ্চারণে পুরো টেক্সট অডিও শোনার সুবিধা।"
                                ),
                                ProBenefitItem(
                                    icon = Icons.Default.PictureAsPdf,
                                    color = Color(0xFF8B5CF6),
                                    title = "ইনস্ট্যান্ট পিডিএফ সামারাইজার 📄",
                                    desc = "যেকোনো বড় পিডিএফ ফাইল সেকেন্ডের মধ্যে সারাংশ করুন।"
                                ),
                                ProBenefitItem(
                                    icon = Icons.Default.Assistant,
                                    color = Color(0xFF14B8A6),
                                    title = "এআই স্মার্ট টিউটর গাইড 🧠",
                                    desc = "চব্বিশ ঘণ্টা পার্সোনালাইজড উপায়ে কঠিন কঠিন বিষয় সহজে শিখুন।"
                                )
                            )
                        }

                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            benefits.forEach { benefit ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = benefit.color.copy(alpha = 0.15f),
                                        shape = CircleShape,
                                        modifier = Modifier.size(38.dp),
                                        border = BorderStroke(1.dp, benefit.color.copy(alpha = 0.3f))
                                    ) {
                                        Box(
                                            modifier = Modifier.fillMaxSize(),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = benefit.icon,
                                                contentDescription = null,
                                                tint = benefit.color,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = benefit.title,
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = benefit.desc,
                                            color = Color.LightGray,
                                            fontSize = 11.sp,
                                            lineHeight = 14.sp
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(28.dp))

                        // Action Buttons Section
                        if (!isPremium) {
                            Button(
                                onClick = { currentStep = 1 },
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFFFB300)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .shadow(
                                        elevation = 12.dp,
                                        shape = RoundedCornerShape(16.dp),
                                        spotColor = Color(0xFFFFB300)
                                    )
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "Go Pro Now ⚡",
                                        color = Color.Black,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        } else {
                            // Already Premium Active User State
                            Surface(
                                color = Color(0xFF10B981).copy(alpha = 0.12f),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.2.dp, Color(0xFF10B981).copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("👑", fontSize = 24.sp)
                                    Column {
                                        Text(
                                            text = "আপনার প্রো প্ল্যান সক্রিয় রয়েছে",
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "সকল প্রিমিয়াম টুলস ও আনলিমিটেড এআই উপভোগ করুন",
                                            color = Color.LightGray,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            TextButton(
                                onClick = {
                                    onTogglePremium()
                                    onDismiss()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "ফ্রি ডেমো সংস্করণে ফিরে যান",
                                    color = Color.White.copy(alpha = 0.5f),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    1 -> {
                        // --- STEP 1: CHOOSE PAYMENT METHOD ---
                        Text(
                            text = "পেমেন্ট পদ্ধতি নির্বাচন করুন",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "নিরাপদ গেটওয়ের মাধ্যমে পেমেন্ট সম্পন্ন করুন",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Price summary card
                        Surface(
                            color = Color.White.copy(alpha = 0.05f),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Nerd AI Pro Plan", color = Color.LightGray, fontSize = 13.sp)
                                    Text("৯৯ টাকা / মাস", color = Color(0xFFFFB300), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("সার্ভিস চার্জ ও ভ্যাট", color = Color.Gray, fontSize = 11.sp)
                                    Text("০ টাকা", color = Color.Gray, fontSize = 11.sp)
                                }
                                Divider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 10.dp))
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("সর্বমোট প্রদেয় বিল", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Text("৯৯.০০ ৳", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text(
                            text = "মোবাইল ব্যাংকিং ও কার্ড সমূহ:",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.align(Alignment.Start).padding(bottom = 10.dp)
                        )

                        // Bkash selection option
                        PaymentMethodRow(
                            name = "bKash (বিকাশ)",
                            color = Color(0xFFE2125B),
                            logoChar = "b",
                            isSelected = selectedMethod == "bkash",
                            onClick = { selectedMethod = "bkash" }
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Nagad selection option
                        PaymentMethodRow(
                            name = "Nagad (নগদ)",
                            color = Color(0xFFF15922),
                            logoChar = "ন",
                            isSelected = selectedMethod == "nagad",
                            onClick = { selectedMethod = "nagad" }
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Rocket selection option
                        PaymentMethodRow(
                            name = "Rocket (রকেট)",
                            color = Color(0xFF8C3494),
                            logoChar = "R",
                            isSelected = selectedMethod == "rocket",
                            onClick = { selectedMethod = "rocket" }
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Card selection option
                        PaymentMethodRow(
                            name = "Visa / Mastercard / Card",
                            color = Color(0xFF1E3A8A),
                            logoChar = "💳",
                            isSelected = selectedMethod == "card",
                            onClick = { selectedMethod = "card" }
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = { currentStep = 2 },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFFB300)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text("এগিয়ে যান ➡️", color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    2 -> {
                        // --- STEP 2: INPUT DETAILS ---
                        val methodDisplayName = when (selectedMethod) {
                            "bkash" -> "bKash"
                            "nagad" -> "Nagad"
                            "rocket" -> "Rocket"
                            else -> "Card"
                        }
                        
                        val methodColor = when (selectedMethod) {
                            "bkash" -> Color(0xFFE2125B)
                            "nagad" -> Color(0xFFF15922)
                            "rocket" -> Color(0xFF8C3494)
                            else -> Color(0xFF1E3A8A)
                        }

                        Text(
                            text = "$methodDisplayName পেমেন্ট বিবরণী",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Tiny Logo
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(methodColor, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            val charVal = when (selectedMethod) {
                                "bkash" -> "b"
                                "nagad" -> "ন"
                                "rocket" -> "R"
                                else -> "💳"
                            }
                            Text(charVal, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        if (selectedMethod == "card") {
                            // Card number input
                            OutlinedTextField(
                                value = cardNumber,
                                onValueChange = { if (it.length <= 16) cardNumber = it },
                                label = { Text("কার্ড নম্বর (১৬ ডিজিট)", color = Color.LightGray) },
                                placeholder = { Text("xxxx xxxx xxxx xxxx", color = Color.Gray) },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Next
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFFFFB300),
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                OutlinedTextField(
                                    value = cardExpiry,
                                    onValueChange = { if (it.length <= 5) cardExpiry = it },
                                    label = { Text("Expiry (MM/YY)", color = Color.LightGray) },
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Number,
                                        imeAction = ImeAction.Next
                                    ),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Color(0xFFFFB300),
                                        unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    ),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                OutlinedTextField(
                                    value = cardCvv,
                                    onValueChange = { if (it.length <= 3) cardCvv = it },
                                    label = { Text("CVV", color = Color.LightGray) },
                                    visualTransformation = PasswordVisualTransformation(),
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Number,
                                        imeAction = ImeAction.Next
                                    ),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Color(0xFFFFB300),
                                        unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    ),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = cardName,
                                onValueChange = { cardName = it },
                                label = { Text("কার্ড হোল্ডারের নাম", color = Color.LightGray) },
                                keyboardOptions = KeyboardOptions(
                                    imeAction = ImeAction.Done
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFFFFB300),
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )
                        } else {
                            // Mobile banking account number input
                            OutlinedTextField(
                                value = walletNumber,
                                onValueChange = { if (it.length <= 11) walletNumber = it },
                                label = { Text("আপনার মোবাইল নম্বর দিন", color = Color.LightGray) },
                                placeholder = { Text("017XXXXXXXX", color = Color.Gray) },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Phone,
                                    imeAction = ImeAction.Next
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFFFFB300),
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // PIN input
                            OutlinedTextField(
                                value = walletPin,
                                onValueChange = { if (it.length <= 5) walletPin = it },
                                label = { Text("পিন নম্বর (PIN)", color = Color.LightGray) },
                                visualTransformation = PasswordVisualTransformation(),
                                placeholder = { Text("••••", color = Color.Gray) },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Done
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFFFFB300),
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }

                        if (inputError.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = inputError,
                                color = Color.Red,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.Start)
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // Pay Button
                        Button(
                            onClick = {
                                if (selectedMethod == "card") {
                                    if (cardNumber.length < 16 || cardExpiry.isEmpty() || cardCvv.length < 3) {
                                        inputError = "অনুগ্রহ করে সঠিক কার্ড তথ্য প্রদান করুন"
                                    } else {
                                        inputError = ""
                                        currentStep = 3 // go to processing
                                    }
                                } else {
                                    if (walletNumber.length < 11 || walletPin.isEmpty()) {
                                        inputError = "অনুগ্রহ করে সঠিক মোবাইল নম্বর ও পিন প্রদান করুন"
                                    } else {
                                        inputError = ""
                                        currentStep = 3 // go to processing
                                    }
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = methodColor
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .shadow(8.dp, RoundedCornerShape(14.dp), spotColor = methodColor)
                        ) {
                            Text(
                                text = "পে করুন ৯৯ টাকা 🔒",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    3 -> {
                        // --- STEP 3: PROCESSING ---
                        Spacer(modifier = Modifier.height(24.dp))
                        CircularProgressIndicator(
                            color = Color(0xFFFFB300),
                            strokeWidth = 4.dp,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "পেমেন্ট প্রসেস করা হচ্ছে...",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "অনুগ্রহ করে অপেক্ষা করুন এবং উইন্ডোটি বন্ধ করবেন না",
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                    }

                    4 -> {
                        // --- STEP 4: SUCCESS ---
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .background(Color(0xFF10B981).copy(alpha = 0.15f), CircleShape)
                                .border(2.dp, Color(0xFF10B981), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "সফল",
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text(
                            text = "পেমেন্ট সফল হয়েছে! 🎉",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 22.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "অভিনন্দন! আপনার পেমেন্টটি সফলভাবে সম্পন্ন হয়েছে। Nerd AI Pro সাবস্ক্রিপশনটি আপনার অ্যাকাউন্টে সক্রিয় করা হয়েছে।",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 16.sp,
                            modifier = Modifier.padding(horizontal = 10.dp)
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        // Transaction details box
                        Surface(
                            color = Color.White.copy(alpha = 0.04f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("টুলস প্ল্যান:", color = Color.Gray, fontSize = 11.sp)
                                    Text("Nerd AI Premium Pro", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("পরিমাণ:", color = Color.Gray, fontSize = 11.sp)
                                    Text("৯৯ টাকা", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("ট্রানজেকশন আইডি (TxnID):", color = Color.Gray, fontSize = 11.sp)
                                    Text("TXN" + remember { (1000000..9999999).random().toString() }, color = Color(0xFFFFB300), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(28.dp))

                        Button(
                            onClick = {
                                onTogglePremium()
                                onDismiss()
                            },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF10B981)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            Text(
                                text = "দারুণ! শুরু করি 🚀",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentMethodRow(
    name: String,
    color: Color,
    logoChar: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = if (isSelected) Color.White.copy(alpha = 0.08f) else Color.Transparent,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) color else Color.White.copy(alpha = 0.12f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(color, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(logoChar, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
            }
            Text(
                text = name,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(
                    selectedColor = color,
                    unselectedColor = Color.White.copy(alpha = 0.3f)
                )
            )
        }
    }
}

data class ProBenefitItem(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color,
    val title: String,
    val desc: String
)

