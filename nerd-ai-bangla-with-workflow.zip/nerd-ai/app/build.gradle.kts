plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.roborazzi)
  alias(libs.plugins.secrets)
  alias(libs.plugins.google.services)
}

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.nerdaibangla.app"
    minSdk = 24
    targetSdk = 36
    versionCode = 1
    versionName = "1.0"

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

    // Determine Firebase configurations dynamically
    var firebaseAppId = System.getenv("FIREBASE_APP_ID") ?: ""
    var firebaseApiKey = System.getenv("FIREBASE_API_KEY") ?: ""
    var firebaseProjectId = System.getenv("FIREBASE_PROJECT_ID") ?: ""

    // Also check root .env file if it exists
    try {
        val envFile = rootProject.file(".env")
        if (envFile.exists()) {
            envFile.forEachLine { line ->
                val parts = line.split("=", limit = 2)
                if (parts.size == 2) {
                    val key = parts[0].trim()
                    val value = parts[1].trim()
                    if (key == "FIREBASE_APP_ID" && value.isNotBlank() && value != "PLACEHOLDER") {
                        firebaseAppId = value
                    } else if (key == "FIREBASE_API_KEY" && value.isNotBlank() && value != "PLACEHOLDER") {
                        firebaseApiKey = value
                    } else if (key == "FIREBASE_PROJECT_ID" && value.isNotBlank() && value != "PLACEHOLDER") {
                        firebaseProjectId = value
                    }
                }
            }
        }
    } catch (e: Exception) {
        // ignore
    }

    // If still blank/placeholder, parse google-services.json
    if (firebaseAppId.isBlank() || firebaseAppId == "PLACEHOLDER") {
        try {
            val gsFile = file("google-services.json")
            if (gsFile.exists()) {
                val content = gsFile.readText()
                val match = Regex("\"mobilesdk_app_id\"\\s*:\\s*\"([^\"]+)\"").find(content)
                if (match != null) {
                    firebaseAppId = match.groupValues[1]
                }
            }
        } catch (e: Exception) {
            // ignore
        }
    }
    if (firebaseApiKey.isBlank() || firebaseApiKey == "PLACEHOLDER") {
        try {
            val gsFile = file("google-services.json")
            if (gsFile.exists()) {
                val content = gsFile.readText()
                val match = Regex("\"current_key\"\\s*:\\s*\"([^\"]+)\"").find(content)
                if (match != null) {
                    firebaseApiKey = match.groupValues[1]
                }
            }
        } catch (e: Exception) {
            // ignore
        }
    }
    if (firebaseProjectId.isBlank() || firebaseProjectId == "PLACEHOLDER") {
        try {
            val gsFile = file("google-services.json")
            if (gsFile.exists()) {
                val content = gsFile.readText()
                val match = Regex("\"project_id\"\\s*:\\s*\"([^\"]+)\"").find(content)
                if (match != null) {
                    firebaseProjectId = match.groupValues[1]
                }
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    // Fallback to defaults if still empty
    if (firebaseAppId.isBlank()) firebaseAppId = "PLACEHOLDER"
    if (firebaseApiKey.isBlank()) firebaseApiKey = "PLACEHOLDER"
    if (firebaseProjectId.isBlank()) firebaseProjectId = "PLACEHOLDER"

    buildConfigField("String", "FIREBASE_APP_ID", "\"$firebaseAppId\"")
    buildConfigField("String", "FIREBASE_API_KEY", "\"$firebaseApiKey\"")
    buildConfigField("String", "FIREBASE_PROJECT_ID", "\"$firebaseProjectId\"")
  }

  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
    }
    debug {
      signingConfig = signingConfigs.getByName("debugConfig")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
}

// Some unused dependencies are commented out below instead of being removed.
// This makes it easy to add them back in the future if needed.
dependencies {
  implementation(platform(libs.androidx.compose.bom))
  implementation(platform(libs.firebase.bom))
  // implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  implementation(libs.androidx.camera.camera2)
  implementation(libs.androidx.camera.core)
  implementation(libs.androidx.camera.lifecycle)
  implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation("com.tom-roush:pdfbox-android:2.0.27.0")
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  // implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  // implementation(libs.androidx.navigation.compose)
  implementation(libs.androidx.room.ktx)
  implementation(libs.androidx.room.runtime)
  // implementation(libs.coil.compose)
  implementation(libs.converter.moshi)
  implementation(libs.firebase.auth)
  // implementation(libs.firebase.ai)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.logging.interceptor)
  implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  // implementation(libs.play.services.location)
  implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  testImplementation(libs.roborazzi)
  testImplementation(libs.roborazzi.compose)
  testImplementation(libs.roborazzi.junit.rule)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  "ksp"(libs.androidx.room.compiler)
  "ksp"(libs.moshi.kotlin.codegen)
}
